# -*- coding: utf-8 -*-
"""Generator for custom calibration maps.

WHY THEY EXIST: the 22 official levels do not yield samples of the physics
constants. Measured (2026-08-17, equivalent to py/sample_count): across the 22
verified solutions there are ONLY 5 slope-exit launches in total, each of them a
one-off. There are 0 launches for ball/robot/spider/UFO, and 0 for a
forward-moving cube at |m|=2. So when two constants "each measured at one point"
disagree, the corpus holds nothing to settle it (see how the m=2 anchor of
cubeExit turned into a per-mode split). A calibration map is A MEASURING RIG FOR
PRODUCING THOSE SAMPLES, not a level to be beaten (the official 22 stay as they
are, as the regression corpus).

The output is GD's level string in RAW (uncompressed) form. Compression is left
to GD's own ZipUtils on the MOD side (so the encoding is never guessed).

Take the objects you may place from the measured table in py/objpalette.py. All
the id/type pairs written here were confirmed against dumps of the 22 levels:

  id 1    type 0   30x30    basic block
  id 8    type 2   6x12     spike
  id 10   type 4   25x75    gravity portal (blue = flipped)
  id 11   type 3   25x75    gravity portal (yellow = normal)
  id 12   type 6   34x86    cube portal
  id 13   type 5   34x86    ship portal
  id 47   type 16  34x86    ball portal
  id 111  type 19  34x86    UFO portal
  id 660  type 26  34x86    wave portal
  id 745  type 27  34x86    robot portal
  id 1331 type 33  34x86    spider portal
  id 1933 type 41  33.5x85  swing portal
  id 45   type 14  44x92    size (mini)
  id 46   type 15  44x92    size (normal)
  id 1743 type 25  30x30    slope (|m|=1)
  id 1744 type 25  30x60    slope (|m|=2 / 0.5; the orientation depends on rot)
  id 1746 type 25  30x60    slope (same as above, another variant)
  id 1338 type 25  30x30    slope (the 30x30 one from lv21)

A SLOPE'S m AND sdir ARE FUNCTIONS OF rot/flip -- NEVER GUESS THE VALUES.
Load a single palette_probe map, have GD report them, and build the real
calibration rig from that table (this round trip doubles as a check on the
generator itself).

    python py/mklevel.py probe  --out data/rigs/calib_probe.lvl
    python py/mklevel.py slopes --out data/rigs/calib_slopes.lvl
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

# ---- Object IDs (all from the measured table in objpalette.py) ----
BLOCK = 1
SPIKE = 8
# id 10 = NORMAL GRAVITY / id 11 = FLIPPED, exactly as leveldp's Obj::id note
# says; it was written the other way round at first. The symptom looked like
# this: right after unit 0 of the orb rig the player flipped and ran along the
# ceiling, passed straight through the floor-side portals (mode/size) of every
# later unit, and the fire value came out as "a flipped cube's jump, -11.180"
# for every orb.
GRAV_NORM, GRAV_FLIP = 10, 11
P_CUBE, P_SHIP, P_BALL, P_UFO = 12, 13, 47, 111
P_WAVE, P_ROBOT, P_SPIDER, P_SWING = 660, 745, 1331, 1933
# The size portals are TYPE 17 = NORMAL / 18 = MINI (leveldp's m_mini test).
# id 45/46 (type 14/15) are a different 44x92 object; placing them did not
# change the size at all.
SIZE_MINI, SIZE_NORM = 101, 99
SLOPE30, SLOPE60A, SLOPE60B, SLOPE30B = 1743, 1744, 1746, 1338

MODE_PORTAL = {"cube": P_CUBE, "ship": P_SHIP, "ball": P_BALL, "ufo": P_UFO,
               "wave": P_WAVE, "robot": P_ROBOT, "spider": P_SPIDER,
               "swing": P_SWING}

GRID = 30.0          # one GD block cell
# THE y IN THE LEVEL STRING IS world y - 90. Measured 2026-08-17 (this rig was
# loaded into GD and reported back via objrects): a block written as 75 in the
# string was reported by GD as cy=165, and a ramp written as 105 was reported as
# 195. That is,
#   world = string + 90
# The player stands at world y=105, and the ground (world 90) is solid across
# the whole level. This was the cause of the first instant deaths: a floor laid
# at string y=15 spans world 90..120 and blocked THE PLAYER'S SPAWN POSITION
# ITSELF. Conversely "laying it at y=75 clears the rig" was not a success
# either -- the run simply never touched that mid-air floor at world 150..180.
# From here on WRITE EVERYTHING IN world COORDINATES; obj() subtracts the offset
# as it writes.
Y_OFFSET = 90.0
GROUND_TOP = 90.0    # top of the ground = the surface the player stands on (world)
GROUND_Y = GROUND_TOP - GRID / 2   # centre for placing a floor block at that height


# The unit table. Filled in on every generation and written out to a
# .units.json alongside the .lvl. SO THE EXTRACTOR NEVER HAS TO GUESS "what
# condition does this x band represent".
UNITS: list[dict] = []
# The press windows. A rig THAT NEEDS TAPS, such as an orb rig, pushes
# (tick, 0|1) here and it is written to the .plan.txt (the rig and the plan must
# be generated together or the windows drift apart).
PLAN: list[tuple[int, int]] = []
# --ka39: write kA39,1 into the header. THE ONE SANCTIONED EXCEPTION to the
# "stop at kA11" rule below: lv22 is the only official level with kA39=1
# (fixRadiusCollision), and its circle-hazard branch (branch A + rotated-OBB
# skip) can only be measured on a rig that sets the same flag. Off by default,
# so every existing rig is byte-identical; a rig generated with it must record
# WHICH flag world it measured (the sawcal history is all kA39=0).
KA39 = False


def obj(oid: int, x: float, y: float, rot: float = 0.0,
        flip_x: bool = False, flip_y: bool = False,
        scale: float = 0.0, extra: dict[int, str] | None = None) -> str:
    """One object. The keys follow GD's level-string spec:
    1=id, 2=x, 3=y, 4=flipX, 5=flipY, 6=rotation, 32=scale.
    """
    # y arrives in world coordinates; subtract Y_OFFSET when writing (see note above)
    p = [f"1,{oid}", f"2,{x:g}", f"3,{y - Y_OFFSET:g}"]
    if flip_x:
        p.append("4,1")
    if flip_y:
        p.append("5,1")
    if rot:
        p.append(f"6,{rot:g}")
    if scale:
        p.append(f"32,{scale:g}")
    for k, v in (extra or {}).items():
        p.append(f"{k},{v}")
    return ",".join(p)


def header(start_mode: str = "cube", mini: bool = False, speed: int = 0,
           dual: bool = False) -> str:
    """The level's leading segment. THE STARTING STATE IS DECIDED HERE.

    kA2 = starting game mode (0 cube / 1 ship / 2 ball / 3 UFO / 4 wave /
    5 robot / 6 spider / 7 swing), kA3 = mini, kA4 = starting speed
    (0=1x, 1=0.5x, 2=2x, 3=3x, 4=4x), kA8 = dual, kA10 = 2player.
    kA6/kA7 are the background/ground texture numbers (cosmetic only).
    """
    m = {"cube": 0, "ship": 1, "ball": 2, "ufo": 3, "wave": 4, "robot": 5,
         "spider": 6, "swing": 7}[start_mode]
    h = (f"kS38,1_40_2_125_3_255_11_255_12_255_13_255_4_-1_6_1000_7_1_15_1"
         f"_18_0_8_1|1_0_2_102_3_255_11_255_12_255_13_255_4_-1_6_1001_7_1"
         f"_15_1_18_0_8_1"
         f",kA13,0,kA15,0,kA16,0,kA14,,kA6,1,kA7,1,kA17,0,kA18,0"
         f",kA2,{m},kA3,{1 if mini else 0},kA4,{speed}"
         f",kA8,{1 if dual else 0},kA10,0,kA9,0,kA11,0")
    if KA39:
        h += ",kA39,1"
    return h
# [2026-08-20] DO NOT WRITE kA22-kA45 (sole exception: the opt-in --ka39, see
# the KA39 note above). THE RIG HEADER MUST STOP AT kA11: an
# official level's header (expanded from Resources/levels/7.txt) ends at kA11
# and has not a single key from kA22 on. The kA31..kA45 (mostly 1) that only the
# rig spelled out are the 2.2 compatibility flags, and THEY WERE CHANGING THE
# PHYSICS BETWEEN THE RIG AND THE OFFICIAL LEVELS:
#   rig ceilramp t=143..  flipped ship, no input = a constant +0.069/tick
#   lv7 t=5,793..         same conditions        = a constant +0.103/tick
# (both at sp0.9, vsize=1, gravityMod=1, dual=0 -- a different constant from
#  start to finish, not a vy threshold and not a frame effect).
# levelVersion/gameVersion were 1/0 for both the rig and the official levels, so
# the difference can only be in the level string's header.


# [2026-08-20] How far the run-up is paved. DO NOT RUN ON THE IMPLICIT WORLD
# GROUND. GD's world ground (top=90) is not treated like a solid block: when the
# player grows via a size portal while grounded, on top of a block it RESEATS ON
# THE SAME TICK (5 cases in the corpus), whereas on the world ground it happens
# THE NEXT TICK (same-tick reseating is a "push out of the penetration" action,
# so it cannot happen with nothing to push against).
# The "+6.000px for 1 tick" that always showed up in the rig's divergences was
# this, not a physics bug.
# cy=75 (top=90) is flush with the world ground, so paving it blocks no path.
PAVE_X = 60000.0


def floor_run(x0: float, x1: float, y: float = GROUND_Y,
              step: float = GRID) -> list[str]:
    """A floor filling [x0, x1]. GD'S GROUND (the y=0 surface) DOES HAVE A
    HITBOX, BUT A CALIBRATION RIG LAYS ITS OWN FLOOR AND PICKS ITS OWN HEIGHT."""
    out, x = [], x0
    while x <= x1:
        out.append(obj(BLOCK, x, y))
        x += step
    return out


def build_probe() -> str:
    """The palette verification map.

    IT MEASURES NO PHYSICS. Its purpose is to settle, in a single load, "if I
    place this id at this rot/flip, what type / w,h / m / slopeDir does GD
    report". It also checks the generator itself (are the coordinates what we
    intended) at the same time.

    Layout: one object every 30px, with a different row of y per kind. The
    player is never run (we only take the objrects dump), so collisions do not
    matter.
    """
    objs: list[str] = []
    objs += floor_run(0, 300)

    x = 400.0
    # Slopes: every combination of id x (rot, flipX, flipY). THIS IS THE MAIN
    # EVENT -- it is what fills in the m and slopeDir table.
    for oid in (SLOPE30, SLOPE30B, SLOPE60A, SLOPE60B):
        for rot in (0, 90, 180, 270):
            for fx, fy in ((False, False), (True, False), (False, True),
                           (True, True)):
                objs.append(obj(oid, x, 315.0, rot=rot, flip_x=fx, flip_y=fy))
                x += 90.0
    # Mode/size/gravity portals: check the reported type and box
    x2 = 400.0
    for oid in (P_CUBE, P_SHIP, P_BALL, P_UFO, P_WAVE, P_ROBOT, P_SPIDER,
                P_SWING, SIZE_MINI, SIZE_NORM, GRAV_FLIP, GRAV_NORM):
        objs.append(obj(oid, x2, 615.0))
        x2 += 90.0
    # Block and spike (the reference)
    x3 = 400.0
    for oid in (BLOCK, SPIKE):
        for rot in (0, 90, 180, 270):
            objs.append(obj(oid, x3, 915.0, rot=rot))
            x3 += 90.0
    return header() + ";" + ";".join(objs) + ";"


def build_slopes() -> str:
    """Slope calibration rig (v1: geometry only; per-mode sections wait until
    the probe table exists).

    Structure: flat run-up -> one slope -> flat landing area is one unit, laid
    out side by side. Units are 12 cells apart so one unit's launch cannot carry
    into the next.
    """
    objs: list[str] = []
    x = 0.0
    objs += floor_run(x, x + 300)
    x += 360
    for oid in (SLOPE30, SLOPE60A):
        for rot in (0, 90, 180, 270):
            # 4 cells of run-up
            objs += floor_run(x, x + 3 * GRID)
            x += 4 * GRID
            # The slope, sitting on the floor (30x30 centres at 45, 30x60 at 60)
            h = 60.0 if oid in (SLOPE60A, SLOPE60B) else 30.0
            objs.append(obj(oid, x, GROUND_Y + GRID / 2 + h / 2, rot=rot))
            objs.append(obj(BLOCK, x, GROUND_Y))
            x += GRID
            # 8 cells of landing area
            objs += floor_run(x, x + 7 * GRID)
            x += 12 * GRID
    return header() + ";" + ";".join(objs) + ";"


# ---- Placements settled by having GD report on the probe map (2026-08-17) ----
# The combinations that give "uphill with the solid side below" (= a floor ramp
# you can walk on). slopeIsCeiling treats {1,3,5,6} as ceiling, so sdir 0 and 7
# are floor.
#   |m|=0.5 : id1744 rot=0            -> w60 h30, sy cy-15 -> cy+15, sdir 0
#   |m|=1.0 : id1743 rot=0            -> w30 h30, sy cy-15 -> cy+15, sdir 0
#   |m|=2.0 : id1744 rot=90 + flipY   -> w30 h60, sy cy-30 -> cy+30, sdir 7
# The low end is aligned with the top of the floor, so cy is "floor top + half
# the height".
RAMP = {0.5: (SLOPE60A, 0.0, False, False, 60.0, 30.0),
        1.0: (SLOPE30, 0.0, False, False, 30.0, 30.0),
        2.0: (SLOPE60A, 90.0, False, True, 30.0, 60.0)}


def ramp_unit(x: float, mode: str, m: float, mini: bool, n_ramps: int,
              bury: float, floor_top: float = GROUND_TOP
              ) -> tuple[list[str], float]:
    """One unit of a calibration rig. SHAPED SO IT CAN BE CLEARED WITH ZERO INPUT.

    [mode/size portal][run-up][n ramps][plateau][gap], and the launch happens on
    the tick the player leaves the top of the ramp. The launch value can be read
    off the free flight over the plateau.

    `bury`: how many px of the ramp's low end are filled in from above with
    blocks. This shortens the ride so the ramp factor (a ramp-up that saturates
    in 0.1 s) can be isolated. 0 means the full length.
    Returns (list of objects, x of the next unit).
    """
    oid, rot, fx, fy, w, h = RAMP[m]
    objs: list[str] = []
    # Portals: place them at a height that overlaps the player's box (world 90..120)
    objs.append(obj(MODE_PORTAL[mode], x, floor_top + 15.0))
    objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID,
                    floor_top + 15.0))
    # The run-up needs no blocks -- THE GROUND (world 90) IS SOLID ACROSS THE
    # WHOLE LEVEL. Laying a floor here would only block the player's path (see
    # the Y_OFFSET note above).
    run0 = 8
    xr = x + run0 * GRID
    # Climb n ramps joined end to end (GD only starts the ride timer on an
    # air->slope transition, so a contiguous chain accumulates ride ticks)
    bottom = floor_top
    for i in range(n_ramps):
        cy = bottom + h / 2.0
        # The ramp's box is w wide about cx. Align its low end with bottom.
        objs.append(obj(oid, xr + w / 2.0, cy, rot=rot,
                        flip_x=fx, flip_y=fy))
        # From the second ramp on there is a cavity underneath, so fill it
        # (to stop the player falling through)
        yy = floor_top + GRID / 2
        while yy < cy - h / 2.0 + 1.0:
            for k in range(int(w / GRID)):
                objs.append(obj(BLOCK, xr + GRID / 2 + k * GRID, yy))
            yy += GRID
        bottom += h
        xr += w
    # ALWAYS LEAVE THE SPACE BEYOND THE TOP END EMPTY. The launch rule fires on
    # the tick the player "leaves the top of the ramp", so joining a plateau at
    # the same height with no gap just lets the player walk across and no launch
    # ever happens (measured 2026-08-17: the plateau version cleared all 48
    # units with 0 launches). With a gap the player lands back on the ground, so
    # the arc can be measured.
    return objs, xr + 26 * GRID


def rampseam_unit(x: float, mode: str, m: float, mini: bool, ledge: int,
                  floor_top: float = GROUND_TOP) -> tuple[list[str], float]:
    """`ramp_unit` with a FLAT LEDGE butted against the ramp's top instead of a gap.

    The one thing `ramps` cannot see. Its ramps end in empty space, and there GD
    releases the ride's seat on the launch tick -- y takes the free step and the
    seat is thrown away (47/47 on that rig; the model does the same, and the
    lv19 t=254 measurement in step.hpp's launch branch is the same reading).

    lv16 t=13,264 disagrees: p2 launches (vy 0 -> 7.680, onGround 1 -> 0) and GD
    KEEPS THE SEAT, y = 457.150 = the ramp's surface at that x plus 9*sqrt(2).
    The only thing different about that site is what is beyond the ramp: a plain
    30x30 block whose top is exactly the ramp's top, so the surface continues.
    `ledge` is how many such blocks to lay (0 reproduces `ramps`).

    Zero input, like its sibling: the player rides up, and either walks onto the
    ledge or launches off it, and both are readable from the dump.
    """
    oid, rot, fx, fy, w, h = RAMP[m]
    objs: list[str] = []
    objs.append(obj(MODE_PORTAL[mode], x, floor_top + 15.0))
    objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID,
                    floor_top + 15.0))
    xr = x + 8 * GRID
    # One ramp, its low end on the floor. Long enough to saturate the ride
    # counter (the factor is 1.0 past 24 ticks) so the launch VALUE is not the
    # variable under test here -- only what happens to y.
    cy = floor_top + h / 2.0
    objs.append(obj(oid, xr + w / 2.0, cy, rot=rot, flip_x=fx, flip_y=fy))
    top = floor_top + h            # the ramp's high edge
    xr += w
    # The ledge: blocks whose TOP FACE IS THE RAMP'S TOP, butted against it.
    for k in range(ledge):
        objs.append(obj(BLOCK, xr + GRID / 2 + k * GRID, top - GRID / 2))
    xr += ledge * GRID
    # ...and then empty space, so whatever happened is visible as free flight.
    return objs, xr + 26 * GRID


def build_rampseam() -> str:
    """Does a flat ledge past the ramp's top keep the ride's seat on the launch tick?

    4 ground modes x 3 gradients x normal/mini x ledge 0/1/3 = 72 units. Ledge 0
    is the `ramps` geometry and is the control: if it does not reproduce that
    rig's answer, the rig is wrong and not the model.
    """
    objs: list[str] = []
    x = 90.0
    for mode in ("cube", "ball", "robot", "spider"):
        for m in (1.0, 0.5, 2.0):
            for mini in (False, True):
                for ledge in (0, 1, 3):
                    x0 = x
                    u, x = rampseam_unit(x, mode, m, mini, ledge)
                    objs += u
                    UNITS.append({"x0": x0, "x1": x, "mode": mode, "m": m,
                                  "mini": int(mini), "ledge": ledge})
    objs += floor_run(0, PAVE_X)
    return header() + ";" + ";".join(objs) + ";"


def wavein_unit(x: float, mode: str, mini: bool, n: int = 4,
                floor_top: float = GROUND_TOP) -> tuple[list[str], float]:
    u"""Cross a WAVE PORTAL while GROUNDED, and come out the other side alive.

    lv20 t=17,116 is the corpus' one sample of this and it costs the level eight
    rounds: a UFO resting on the floor (onGround 1, vy 0) crosses a wave portal,
    and on that tick GD moves it by +0.029 and sets vy := -2.762, while the model
    moves it a full wave step (-1.613 = -dx) straight away. 1.643 px, and it never
    comes back. The sample cannot say whether that is about being grounded or
    about being the second body of a pair, because the first body was airborne.

    Building it on flat ground does not work: THE WAVE DESCENDS AS FAST AS IT
    ADVANCES, so a body that becomes a wave at floor+15 has thirteen pixels of
    headroom and is in the floor within a dozen ticks -- and one death ends the
    session. So the unit gives it a surface that falls away at the wave's own
    angle:

        [portals][run-up][n ramps up][flat top + WAVE PORTAL][n ramps down]

    The player climbs grounded, meets the portal standing on the flat top, and
    the descent that follows is a |m|=1 ramp -- exactly the wave's 45 degrees --
    so it flies just clear of it instead of into it. Zero input throughout.
    """
    oid, rot, fx, fy, w, h = RAMP[1.0]
    doid, drot, dfx, dfy, dw, dh = DOWNRAMP[1.0]
    objs: list[str] = []
    objs.append(obj(MODE_PORTAL[mode], x, floor_top + 15.0))
    objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID,
                    floor_top + 15.0))
    xr = x + 8 * GRID
    bottom = floor_top
    for i in range(n):                       # climb
        objs.append(obj(oid, xr + w / 2.0, bottom + h / 2.0,
                        rot=rot, flip_x=fx, flip_y=fy))
        yy = floor_top + GRID / 2
        while yy < bottom + 1.0:
            for k in range(int(w / GRID)):
                objs.append(obj(BLOCK, xr + GRID / 2 + k * GRID, yy))
            yy += GRID
        bottom += h
        xr += w
    # NO FLAT TOP. One was tried and it is what breaks the rig: GD supports on
    # box overlap, so a half-15 body is still held up 15 px past the last block,
    # and it then free-falls while the descent runs away from it at 45 degrees.
    # Measured on that cut: the body leaves the top at x=555 and is STILL
    # AIRBORNE at the portal 33 px later (onGround 0, vy -5.4) -- the one thing
    # the rig exists to avoid. Crest straight from the climb into the descent
    # and the ride carries across the seam instead.
    top = bottom
    x_down = xr
    for i in range(n + 3):                   # and back down at the wave's angle
        bottom -= dh
        objs.append(obj(doid, xr + dw / 2.0, bottom + dh / 2.0,
                        rot=drot, flip_x=dfx, flip_y=dfy))
        yy = floor_top + GRID / 2
        while yy < bottom + 1.0:
            for k in range(int(dw / GRID)):
                objs.append(obj(BLOCK, xr + GRID / 2 + k * GRID, yy))
            yy += GRID
        xr += dw
        if bottom <= floor_top:
            break
    # THE PORTAL GOES OVER THE DESCENT, not over the flat top. A portal fires
    # when the boxes overlap, so it catches the player about 30 px before its
    # own centre -- and a body that becomes a wave has only 13.5 px of headroom
    # over whatever it was standing on (half 15 -> half 1.5). On the flat top
    # those 30 px of run are 30 px of descent into the blocks, every time; over
    # a |m|=1 descent the surface drops with it and the wave stays clear.
    # And well down it. Leaving the flat top the player FLOATS for half its own
    # width first -- GD supports on box overlap, so a half-15 body is still held
    # up 15 px past the last block -- and then falls until it catches the ramp.
    # Measured on the first cut of this rig: the top ends at x=540, the body
    # leaves it at 555 and is still airborne at 560. A portal one and a half
    # ramps in fired mid-fall and measured nothing. Two and a half is past the
    # re-acquisition and still 45 px short of the ground.
    objs.append(obj(P_WAVE, x_down + 2.5 * dw, top - 2.5 * dh + 15.0))
    return objs, xr + 20 * GRID


def build_wavein() -> str:
    u"""Crossing a wave portal off a ramp. 6 modes x normal/mini = 12 units.

    **IT DOES NOT YET MEASURE WHAT IT WAS BUILT FOR.** The target is a body that
    is GROUNDED on the tick a wave portal fires (lv20 t=17,116), and every unit
    here enters AIRBORNE -- the crest launches it, so it meets the portal at
    vy -9.0 with onGround 0. That is still a useful control (it is lv20's first
    body, which the model already matches), and the run is clean end to end, so
    it is kept rather than deleted.

    Two geometries were tried and both are recorded above, because between them
    they say why this is hard:

      * a flat top before the descent -- GD supports on box overlap, so the body
        floats 15 px past the last block and then free-falls while the descent
        runs away at 45 degrees. Airborne at the portal.
      * crest straight from climb to descent -- the ride's exit launch fires.
        Airborne again, and faster.

    Underneath both is one constraint: A WAVE DESCENDS AS FAST AS IT ADVANCES,
    and a body that becomes one keeps its position, so a half-15 body has 13.5 px
    of headroom over whatever it was standing on. The portal fires on box
    overlap, i.e. about 30 px before its own centre. So a flat surface under a
    wave portal is 30 px of run against 13.5 px of clearance -- the body is
    always inside the floor, and one death ends the session.

    What lv20 has and this does not is the DUAL GROUND LAYER: the second body
    stands on it with open space below, so it can become a wave and simply
    leave. The next cut should build the grounded side out of a dual band rather
    than out of blocks.
    """
    objs: list[str] = []
    x = 90.0
    for mode in ("cube", "ball", "robot", "spider", "ufo", "ship"):
        for mini in (False, True):
            x0 = x
            u, x = wavein_unit(x, mode, mini)
            objs += u
            UNITS.append({"x0": x0, "x1": x, "mode": mode, "mini": int(mini)})
    objs += floor_run(0, PAVE_X)
    return header() + ";" + ";".join(objs) + ";"


DUAL_CEIL = 380.0        # one continuous ceiling for every unit (see below)


def ceil_unit_dual(x: float, mode: str, m: float, mini: bool
                   ) -> tuple[list[str], float]:
    u"""A ceiling-ramp unit for THE SECOND BODY of a dual.

    `ceil_unit`'s sibling, and the differences are all forced by the pair:
      * NO GRAVITY PORTALS. In a dual the second body is already flipped, and it
        has to STAY flipped from one unit to the next -- `ceil_unit` flips and
        restores per unit because it drives a single player.
      * THE MODE/SIZE PORTALS SIT AT THE CEILING, not at the floor. A portal at
        floor height is taken by the first body and never reached by the second
        (measured on `dualmode`: 3,471 consecutive ticks with the halves in
        different modes), so putting them up here is what addresses the second.
      * ONE CEILING HEIGHT FOR EVERY UNIT. `ceil_y_for` raises it with the
        gradient, which is fine when each unit re-sticks its player; here the
        second body flies between units and would meet a different ceiling each
        time. 380 clears the deepest chain (|m|=2 over three ramps drops 180,
        ending at 200, well above the floor).
    """
    oid, rot, fx, fy, w, h = CEIL_RAMP[m]
    objs: list[str] = []
    ceil = DUAL_CEIL
    objs.append(obj(MODE_PORTAL[mode], x, ceil - 15.0))
    objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID, ceil - 15.0))
    n_ramps = 3
    x_ramp = x + 20 * GRID
    xx = x + 4 * GRID + GRID / 2
    while xx < x_ramp:
        objs.append(obj(BLOCK, xx, ceil + GRID / 2))
        xx += GRID
    for i in range(n_ramps):
        cy = ceil - h / 2.0 - i * h
        objs.append(obj(oid, x_ramp + i * w + w / 2.0, cy,
                        rot=rot, flip_x=fx, flip_y=fy))
        yy = cy + h / 2.0 + GRID / 2
        while yy <= ceil + GRID / 2 + 1.0:
            for k in range(int(w / GRID)):
                objs.append(obj(BLOCK, x_ramp + i * w + GRID / 2 + k * GRID, yy))
            yy += GRID
    # Back to the flat ceiling at the original height (the `ceil_unit` trap: a
    # ceiling matching the ramp's far end crushes the player against the line).
    x_flat = x_ramp + n_ramps * w
    x_end = x_flat + 16 * GRID
    xx = x_flat + GRID / 2
    while xx < x_end:
        objs.append(obj(BLOCK, xx, ceil + GRID / 2))
        xx += GRID
    return objs, x_end + 14 * GRID


def build_ceilrampdual() -> str:
    u"""Does the SECOND BODY release the ride's seat on a ramp exit?

    The last thing lv16 t=13,264 can be. 95 launches across `ramps` and
    `rampseam` say the seat is released and y takes the free step, which is what
    the model does; `rampseamdual` then showed that being half of a pair changes
    nothing for the FIRST body (47 exits, identical tick for tick). What is left
    is the second body itself, and this puts it on the ramps.

    The first body walks the floor underneath and rides nothing, so its own
    column in the dump stays a control for the run's timing.

    Compare against `ceilramp`, which is the same geometry driven by a single
    flipped player.
    """
    objs: list[str] = []
    x = 90.0
    for mode in ("cube", "ball"):
        for m in (1.0, 0.5, 2.0):
            for mini in (False, True):
                x0 = x
                u, x = ceil_unit_dual(x, mode, m, mini)
                objs += u
                UNITS.append({"x0": x0, "x1": x, "mode": mode, "m": m,
                              "mini": int(mini)})
    objs += floor_run(0, PAVE_X)
    return header(dual=True) + ";" + ";".join(objs) + ";"


def build_rampseamdual() -> str:
    """`rampseam` again, with the level STARTED IN DUAL. Halves the question.

    lv16 t=13,264 is the one ramp exit in the corpus where GD keeps the ride's
    seat, and 95 launches across `ramps` and `rampseam` say it should not. What
    that site has and those rigs do not is that the rider is HALF OF A PAIR --
    so ask whether that alone changes anything, before building the harder rig
    where the SECOND body is the one on the ramp.

    Only the header differs. The first body still rides every ramp exactly as it
    does in `rampseam` (the portals sit at floor height, so in a dual the first
    body takes them and the second never reaches them -- measured on `dualmode`).
    The second body flips away upward and is held by the band, out of the way.

    So: p1's exits here against p1's exits there is a clean one-variable A/B.
      * they differ  -> being in a dual is what does it, and the second body is
                        a red herring
      * they match   -> it is the second body specifically, and the next rig has
                        to put IT on the ramp
    """
    objs: list[str] = []
    x = 90.0
    for mode in ("cube", "ball", "robot", "spider"):
        for m in (1.0, 0.5, 2.0):
            for mini in (False, True):
                for ledge in (0, 1, 3):
                    x0 = x
                    u, x = rampseam_unit(x, mode, m, mini, ledge)
                    objs += u
                    UNITS.append({"x0": x0, "x1": x, "mode": mode, "m": m,
                                  "mini": int(mini), "ledge": ledge})
    objs += floor_run(0, PAVE_X)
    return header(dual=True) + ";" + ";".join(objs) + ";"


def build_ramps() -> str:
    """Calibration rig for slope-exit launches. CLEARS EVERY UNIT WITH ZERO INPUT.

    The 22 official solutions yield 5 launch samples in total (each a one-off,
    0 for ball/robot/spider, and 0 for a forward-moving cube at |m|=2). This rig
    is 4 ground modes x 3 values of |m| x normal/mini x 2 ride lengths = 48
    units, producing 48 samples from a single run.
    The flight modes (ship/UFO/wave) need input, so they get their own rig.
    """
    objs: list[str] = []
    x = 90.0
    for mode in ("cube", "ball", "robot", "spider"):
        for m in (1.0, 0.5, 2.0):
            for mini in (False, True):
                for n, bury in ((3, 0.0), (1, 0.0)):
                    x0 = x
                    u, x = ramp_unit(x, mode, m, mini, n, bury)
                    objs += u
                    UNITS.append({"x0": x0, "x1": x, "mode": mode, "m": m,
                                  "mini": int(mini), "ramps": n,
                                  "bury": bury})
    # [2026-08-20] Lay the floor LAST = give it a larger uid than the portals.
    # GD's collision pass runs in uid order, and only a solid processed AFTER
    # the size portal sees the "grown box" and pushes the player out on the same
    # tick. Placing the floor first makes the reseat happen the next tick, which
    # disagrees with the corpus (lv12/lv15/lv19/lv22 are all same-tick). In the
    # official levels the floor has a later uid than the player's path.
    objs += floor_run(0, PAVE_X)
    return header() + ";" + ";".join(objs) + ";"


# ---- Orbs / pads (from the measured table in objpalette.py) ----
ORB = {"yellow": (36, 11), "pink": (141, 12), "blue": (84, 13),
       "green": (1022, 29), "red": (1333, 35), "black": (1330, 32),
       "dash": (1704, 37), "gravdash": (1751, 38), "spider": (3004, 43)}
PAD = {"yellow": (35, 8), "pink": (140, 9), "blue": (67, 10)}

DX_1X = 1.29825044   # x increment at 1x speed (measured)


# The (tick, x) correspondence table built from a measured dump passed via
# --xmap. THIS IS THE ONE THAT MATTERS.
# The naive formula x(t) = dx*(t-1) drifts on a long rig: measured (orbedge rig,
# 105,592 ticks / x=136,000) the average was 1.288/tick, 104px BEHIND the
# prediction (836 ticks do not advance x at all = a few ticks per unit). On a
# rig whose press windows are specified in ticks, that lag translates directly
# into "the press did not happen at the intended x".
# Procedure: run it once, take the dump, and regenerate passing that dump to
# --xmap.
XMAP: list[tuple[int, float]] = []
# (tick, x, mode_before, mode_after) for every tick a --xmap dump changed mode.
# A portal's own tick has to be MEASURED, not derived from its x -- see
# load_xmap.
MODEMAP: list[tuple[int, float, str, str]] = []


def tick_at(x: float, dx: float = DX_1X) -> int:
    """The tick at which the player reaches that x.

    If XMAP exists, look it up FROM THE MEASUREMENT (the first tick at or past
    x). Otherwise fall back on the approximation x(t) = dx*(t-1) (good enough on
    a short rig).
    """
    if XMAP:
        lo, hi = 0, len(XMAP) - 1
        while lo < hi:
            mid = (lo + hi) // 2
            if XMAP[mid][1] < x:
                lo = mid + 1
            else:
                hi = mid
        return XMAP[lo][0]
    return int(x / dx) + 1


def load_xmap(dump: Path) -> None:
    """Load (tick, x) from a dump.csv (x is monotonic, so bisection works).

    Also records where the MODE actually changed. A portal's tick is not
    `tick_at(its x)`: its box is 34x86 and the player's overlaps it about 25
    ticks before the player's centre arrives. calib_portalpress was built on
    that assumption once and every one of its twenty-one cells landed AFTER the
    portal, so the sweep's seven offsets measured one thing seven times.
    """
    import csv as _csv
    prev = None
    with dump.open(newline="", encoding="utf-8-sig", errors="replace") as f:
        for r in _csv.DictReader(f):
            try:
                t, x = int(r["tick"]), float(r["x"])
            except (ValueError, KeyError):
                continue
            XMAP.append((t, x))
            m = r.get("mode")
            if prev is not None and m != prev:
                MODEMAP.append((t, x, prev, m))
            prev = m
    XMAP.sort()
    MODEMAP.sort()


def mode_change_near(x: float, lo: float = 80.0, hi: float = 40.0) -> int:
    """The measured tick of the mode change closest to x, or -1 if none.

    Window is asymmetric because a portal fires EARLY -- the player's box
    reaches it first.
    """
    best, bestd = -1, None
    for t, mx, _a, _b in MODEMAP:
        if not (x - lo <= mx <= x + hi):
            continue
        d = abs(mx - x)
        if bestd is None or d < bestd:
            best, bestd = t, d
    return best


def orb_unit(x: float, kind: str, mode: str, mini: bool, drop: float
             ) -> tuple[list[str], list[tuple[int, int]], float]:
    """A calibration unit for a single orb. MAKE THE TAP HAPPEN WHILE FALLING.

    Pressing while grounded fires the mode's own action first (a jump, for a
    cube), so the shape has the player step off a high platform and touch the
    orb IN MID-AIR. That way the press can only mean the orb firing, and the vy
    at contact can also be chosen via the platform height.

    Returns (list of objects, press window [(tick, 0|1)], next x).
    """
    oid, _ = ORB[kind]
    objs: list[str] = []
    # PLACE IT AT GROUND LEVEL. The first design was "step off a high platform
    # and tap in mid-air", but the platform became a floating island out of
    # reach of the ground (world 90); the player ran underneath it, never
    # touched the portal or the orb, and the press became A PLAIN JUMP (all 72
    # units read incoming -10.852 -> 0 = a landing).
    # Even when tapping on the ground, an overlapping orb takes priority and
    # fires, so this measures the raw value at incoming vy=0. Varying the
    # incoming vy is the job of a separate rig.
    y = GROUND_TOP + 15.0
    ceil = GROUND_TOP + 210.0            # the landing surface when flipped (world)
    objs.append(obj(MODE_PORTAL[mode], x, y))
    objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID, y))
    x_orb = x + 8 * GRID
    objs.append(obj(oid, x_orb, y))
    x_next = x_orb + 40 * GRID
    # PUT A CEILING UP. The blue orb and the gravity dash flip gravity, so
    # without a ceiling the player "falls" upward and dies off-screen (measured:
    # the run ended on the blue mini unit).
    xx = x - GRID
    while xx <= x_next:
        objs.append(obj(BLOCK, xx, ceil + GRID / 2))
        xx += GRID
    # Restore normal gravity at the end of the unit. They go on both the floor
    # side and the ceiling side so a player still flipped and running along the
    # ceiling passes through one for certain.
    objs.append(obj(GRAV_NORM, x_next - 4 * GRID, y))
    objs.append(obj(GRAV_NORM, x_next - 4 * GRID, ceil - 15.0))
    # The press window opens ONLY ONCE THE BOXES OVERLAP. Pressing before that
    # produces the mode's own jump, so it starts at the x where the orb (36x36)
    # and the player (half-width 15) overlap.
    # THE WINDOW MUST START AFTER THE OVERLAP BEGINS FOR BOTH SIZES. At -28 it
    # is inside for normal (half-width 15, overlap starts at -33) but 1px early
    # for mini (half-width 9, -27), and the press on that tick became THE MINI'S
    # OWN JUMP, 8.944, instead of the orb (measured: the blue/green/red/black
    # mini units all came out 8.944 flip0). -20 is inside for both.
    t_press = tick_at(x_orb - 20.0)
    t_rel = tick_at(x_orb + 10.0)
    return objs, [(t_press, 1), (t_rel, 0)], x_next, t_press, t_rel


# ---- Placements for ceiling ramps (solid above the line). Read off the 64
# ---- combinations of the probe rig.
# DOWNHILL ceiling ramps (the line descends as x advances = same shape as lv18
# uid1807). The line runs from cy+h/2 at the left edge to cy-h/2 at the right.
# For sdir, {1,3,5,6} are ceiling.
#   |m|=0.5 : id1744 rot=0  flipY        -> w60 h30, sdir 1
#   |m|=1.0 : id1743 rot=0  flipY        -> w30 h30, sdir 1
#   |m|=2.0 : id1744 rot=90 flipX+flipY  -> w30 h60, sdir 5
CEIL_RAMP = {0.5: (SLOPE60A, 0.0, False, True, 60.0, 30.0),
             1.0: (SLOPE30, 0.0, False, True, 30.0, 30.0),
             2.0: (SLOPE60A, 90.0, True, True, 30.0, 60.0)}

# Underside of the flat ceiling (world). RAISE IT BY THE RAMP'S TOTAL DROP -- a
# 3-ramp chain at |m|=2 descends 180px, so a fixed 255 would put the far end
# through the ground (90) and kill the player.
def ceil_y_for(h: float, n: int = 3) -> float:
    return 200.0 + n * h


def ceil_unit(x: float, mode: str, m: float, mini: bool
              ) -> tuple[list[str], float]:
    u"""One ceiling-ramp unit. Clears with ZERO INPUT.

    [mode/size portal][gravity flip][flat ceiling][downhill ramp][flat ceiling]
    [gravity restore]

    Flipping gravity sticks every mode to the ceiling with no input (ship/UFO
    accelerate into it; cube/ball/robot "land" on it). Sliding along the ramp's
    underside from there is the same shape as lv18 t=3,007. What is measured is
    the CONTACT OFFSET (line - player y) and the velocity on leaving the ramp.
    """
    oid, rot, fx, fy, w, h = CEIL_RAMP[m]
    objs: list[str] = []
    objs.append(obj(MODE_PORTAL[mode], x, GROUND_TOP + 15.0))
    objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID,
                    GROUND_TOP + 15.0))
    objs.append(obj(GRAV_FLIP, x + 4 * GRID, GROUND_TOP + 15.0))
    n_ramps = 3
    ceil = ceil_y_for(h, n_ramps)
    # Flat ceiling (underside at ceil). The run-up must be long enough for the
    # ship/wave to finish climbing
    x_ramp = x + 20 * GRID
    xx = x + 4 * GRID + GRID / 2
    while xx < x_ramp:
        objs.append(obj(BLOCK, xx, ceil + GRID / 2))
        xx += GRID
    # Descend n_ramps ramps joined end to end (buy ride ticks so the ramp
    # factor saturates)
    for i in range(n_ramps):
        cy = ceil - h / 2.0 - i * h
        objs.append(obj(oid, x_ramp + i * w + w / 2.0, cy,
                        rot=rot, flip_x=fx, flip_y=fy))
        # Fill from the top of the ramp box up to the ceiling so the solid connects
        yy = cy + h / 2.0 + GRID / 2
        while yy <= ceil + GRID / 2 + 1.0:
            for k in range(int(w / GRID)):
                objs.append(obj(BLOCK, x_ramp + i * w + GRID / 2 + k * GRID, yy))
            yy += GRID
    # Past the ramp, GO BACK TO A FLAT CEILING AT THE ORIGINAL HEIGHT.
    # A trap stepped on twice: put a low ceiling matching the line at the ramp's
    # far end, and the top edge of the descending player's box
    # (line - offset + pH) is still above that ceiling, so the player is crushed
    # between the line and the ceiling and dies instantly. After leaving the
    # ramp the player climbs again under flipped gravity, so THE CEILING SHOULD
    # SIMPLY CONTINUE AT THE ORIGINAL HEIGHT (aligning the block's left edge
    # with the ramp's right edge is also mandatory -- aligning centres sticks
    # out 15px too early).
    x_flat = x_ramp + n_ramps * w
    x_end = x_flat + 16 * GRID
    xx = x_flat + GRID / 2
    while xx < x_end:
        objs.append(obj(BLOCK, xx, ceil + GRID / 2))
        xx += GRID
    # Restore gravity (at a height that hits the player re-stuck to the
    # original ceiling)
    objs.append(obj(GRAV_NORM, x_flat + 12 * GRID, ceil - 15.0))
    return objs, x_end + 14 * GRID


def build_ceilramp() -> str:
    u"""Calibration rig for ceiling ramps. CLEARS EVERY UNIT WITH ZERO INPUT.

    Across the 22 official levels there is exactly one sample of "a flipped
    flying body riding a ceiling ramp", lv18 t=3,007, and it is a single point
    at |m|=1. It shows the contact offset is off (GD 12.728 vs model 18), but
    the gradient dependence cannot be separated out of it.

    5 modes x 3 values of |m| x normal/mini = 30 units from a single run.

    [2026-08-21] robot/spider/swing added AT THE END (8 modes x 3 x 2 = 48
    units). The hanging-side contact-point rule (sampleAt's split between
    centre/contactPt/box edge) had only ever been measured on this rig's
    ship/cube/ball/UFO, so measure it across the whole surface before the
    whitelist grows one more mode at a time. They go last so that if a new mode
    dies the existing 30 survive.
    """
    objs: list[str] = []
    x = 90.0
    # WAVE GOES LAST (measured 2026-08-21: wave takes GD itself down on its own
    # units of this rig -- in the original order the run stopped at unit 24 and
    # nothing from 25 on was ever measured)
    for mode in ("ship", "cube", "ball", "ufo",
                 "robot", "spider", "swing", "wave"):
        for m in (1.0, 0.5, 2.0):
            for mini in (False, True):
                x0 = x
                u, x = ceil_unit(x, mode, m, mini)
                objs += u
                UNITS.append({"x0": x0, "x1": x, "mode": mode, "m": m,
                              "mini": int(mini),
                              "x_ramp": x0 + 20 * GRID,
                              "ramp_w": CEIL_RAMP[m][4],
                              "ramps": 3,
                              "ceil_y": ceil_y_for(CEIL_RAMP[m][5], 3)})
    # Floor LAST = a larger uid than the portals (the lesson of build_ramps
    # L305). Laying it first makes the mini->normal reseat happen the next tick
    # (GD's collision pass runs in uid order), producing a fake 6.000px x 1 tick
    # divergence against the model's same-tick reseat at every unit boundary
    objs += floor_run(0, PAVE_X)
    return header() + ";" + ";".join(objs) + ";"


def ridemode_unit(x: float, mode: str, target: str, m: float, mini: bool,
                  ceiling: bool, ride_ticks: float | None = None
                  ) -> tuple[list[str], float, dict]:
    u"""A MODE PORTAL PLACED MID-RIDE, on a floor ramp or on a ceiling one.

    lv20's most expensive wall (8 of 40 rounds) is one tick: the second body
    rides a 45-degree slope upside-down, meets the wave portal, and GD steps it
    +0.029 while the model steps it -1.614 -- the ride's own step, m*dx. The
    model has the free-step release for two cases only, both written from a
    single site:

        oldMode == 7 && s.onSlope                 (a swing leaving a ride)
        oldMode != wantMode && s.ceilT > 0 && !s.onSlope   (a ceiling press)

    and this body is neither. Widening the second gate to cover it looked
    obvious until the corpus was asked: of the three ticks in the 22 solutions
    where a mode portal fires with the ride running, ALL THREE HAVE GD TAKING
    THE RIDE'S STEP (lv16 t=9,879 / t=15,537, lv18 t=9,295 -- ship to cube on a
    floor ramp, |dy - m*dx| <= 0.001). Three samples that say the opposite of
    the one site is not a rule either way, and they differ in more than one
    thing at once, so this rig moves ONE: the side the ramp carries from.

        floor   [mode][size][run-up][3 ramps up ....P.... ][gap]
        ceiling [mode][size][flip][flat ceiling][3 ramps down ....P....][flat]

    P is a portal to `target`, placed 2.5 ramps in so it fires with the ride
    long since saturated, at the height the ride itself puts the body
    (`ride_seat`). Both sides clear with zero input, which is what makes the
    tick readable: whatever y moves by on the portal tick is the rule, not the
    plan.
    """
    oid, rot, fx, fy, w, h = (CEIL_RAMP if ceiling else RAMP)[m]
    objs: list[str] = []
    # EACH HEAD PORTAL IS LAID TWICE, at 105 and at 195. A unit that keeps the
    # player high for a long stretch leaves the CAMERA BAND raised behind it:
    # measured on cut 3, after the ceiling unit at x=39,000 the band floor was
    # pmin=150, so the body came down onto the INVISIBLE FLOOR at y=165 and
    # every later unit's portal -- sitting at 105, below the band -- was out of
    # reach. Six units in a row then measured nothing at all while the run still
    # looked clean. A portal at 195 catches the body in that state; one at 105
    # catches it in the ordinary one.
    for py in (GROUND_TOP + 15.0, GROUND_TOP + 105.0):
        objs.append(obj(MODE_PORTAL[mode], x, py))
        objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID, py))
    if ceiling:
        objs.append(obj(GRAV_FLIP, x + 4 * GRID, GROUND_TOP + 15.0))
    n_ramps = 3
    ceil = ceil_y_for(h, n_ramps)
    x_ramp = x + (20 if ceiling else 8) * GRID
    if ceiling:
        xx = x + 4 * GRID + GRID / 2
        while xx < x_ramp:
            objs.append(obj(BLOCK, xx, ceil + GRID / 2))
            xx += GRID
    for i in range(n_ramps):
        if ceiling:
            cy = ceil - h / 2.0 - i * h
            objs.append(obj(oid, x_ramp + i * w + w / 2.0, cy,
                            rot=rot, flip_x=fx, flip_y=fy))
            yy = cy + h / 2.0 + GRID / 2
            while yy <= ceil + GRID / 2 + 1.0:
                for k in range(int(w / GRID)):
                    objs.append(obj(BLOCK,
                                    x_ramp + i * w + GRID / 2 + k * GRID, yy))
                yy += GRID
        else:
            cy = GROUND_TOP + i * h + h / 2.0
            objs.append(obj(oid, x_ramp + i * w + w / 2.0, cy,
                            rot=rot, flip_x=fx, flip_y=fy))
            yy = GROUND_TOP + GRID / 2
            while yy < cy - h / 2.0 + 1.0:
                for k in range(int(w / GRID)):
                    objs.append(obj(BLOCK,
                                    x_ramp + i * w + GRID / 2 + k * GRID, yy))
                yy += GRID
    # THE PORTAL FIRES ABOUT 32 px BEFORE ITS OWN CENTRE (box overlap: the mode
    # portal's own half-width 17 plus the player's 15), so the height has to be
    # the seat AT THE FIRING POINT, not under the centre -- on a 45-degree ramp
    # those are 32 px apart, more than the portal's own half-height.
    #
    # `ride_ticks` places it by HOW OLD THE RIDE IS instead, which is the whole
    # point of the third cut. The ride's own start is measured, not assumed: on
    # the ceiling side the body leaves the flat ceiling at x_ramp - 5.9 (rig
    # pass 2, unit 28, t=30,385) -- GD samples the line 6.2 px AHEAD of the
    # centre, so the descent begins before the ramp's own left edge.
    if ride_ticks is None:
        port_cx = x_ramp + 2.5 * w
    else:
        port_cx = x_ramp - 5.9 + ride_ticks * DX_1X + 32.0
    travel = max(0.0, port_cx - 32.0 + 6.2 - x_ramp)
    i_at = min(n_ramps - 1, int(travel / w))
    surf = (ceil - i_at * h - (travel - i_at * w) * (h / w)) if ceiling else \
           (GROUND_TOP + i_at * h + (travel - i_at * w) * (h / w))
    # The seat is the line at that sample point minus the player's own half --
    # NOT half*sqrt(1+m^2). Measured on this rig (unit 28, a flipped UFO on the
    # |m|=1 ceiling chain): line 241.66 - 15 = 226.66, GD's row to the digit,
    # and the same formula lands lv20's p2 at 295.76 exactly.
    port_cy = surf - (9.0 if mini else 15.0) if ceiling else \
              surf + (9.0 if mini else 15.0)
    objs.append(obj(MODE_PORTAL[target], port_cx, port_cy))
    x_flat = x_ramp + n_ramps * w
    if ceiling:
        # Back to the flat ceiling at the ORIGINAL height -- a ceiling matching
        # the ramp's far end crushes the player against the line (`ceil_unit`'s
        # trap, stepped on twice).
        x_end = x_flat + 16 * GRID
        xx = x_flat + GRID / 2
        while xx < x_end:
            objs.append(obj(BLOCK, xx, ceil + GRID / 2))
            xx += GRID
        objs.append(obj(GRAV_NORM, x_flat + 12 * GRID, ceil - 15.0))
        nxt = x_end + 14 * GRID
    else:
        # Nothing past the top end: the launch needs somewhere to land.
        nxt = x_flat + 26 * GRID
    return objs, nxt, {"x_ramp": x_ramp, "ramp_w": w, "ramp_h": h,
                       "port_cx": port_cx, "port_cy": port_cy,
                       "ceil_y": ceil if ceiling else 0.0}


def build_ridemode() -> str:
    u"""Does a mode portal end a ramp ride on its own tick? One variable: which
    side the ramp carries from.

    Floor units go FIRST and use the four ground modes only -- a flight mode
    needs input to stay on a climbing ramp, which is why `ramps` has never had
    one. The ceiling side sticks every mode to the underside with a gravity
    flip and no input at all (`ceilramp`'s whole point), so the flight modes are
    measurable there, and that is where lv20's own body is: a UFO pressed along
    a descending ramp, upside down.

    `wave` and `swing` are left out on purpose. The wave takes GD itself down
    on `ceilramp`'s own units (2026-08-21), and the swing is the one case the
    model already has a measured rule for.

    |m| = 1 throughout: lv20's ramp is 45 degrees and the question is the side,
    not the gradient. If the side turns out to matter, the gradient is the next
    rig, not another axis of this one.

    [2026-08-29, second cut] THE SIDE DOES NOT MATTER: all 20 units of the first
    cut take the ride's step, floor and ceiling alike, every mode, both sizes.
    So the model is right about lv20's tick as far as this rig can see, and what
    is left of the difference is the ONE thing every unit above holds fixed --
    THE NEW MODE'S BOX IS THE SAME SIZE AS THE OLD ONE. lv20's portal is a wave
    portal: half 15 becomes half 5, and a body that was pressed against a
    surface is suddenly 10 px clear of it with nothing to ride.

    The model has the other direction of exactly this (a mode portal whose half
    GROWS re-seats the player on the same tick, measured on lv22's spider pairs)
    and nothing at all for the shrink, on the stated grounds that "shrinking has
    nothing to push against" -- true of the position, silent about the contact.

    So this cut adds two arms:
      * target `spider` -- 15 to 13.5, the smallest shrink there is, and safe
        on a ramp. On a 45-degree ramp 1.5 px of half is 2.1 px of seat, so the
        ride step (1.27) and a free one are still far apart.
      * one `ufo -> wave` unit, ceiling, LAST -- lv20's own shape (a flipped
        flight body riding a descending ramp into a wave portal) and the biggest
        shrink available. It cannot survive: a flipped wave with no input flies
        into the ceiling it just left, ~3 ticks after the portal. That is why it
        is last -- ONE DEATH ENDS THE RUN, and everything after it is lost.
    """
    objs: list[str] = []
    x = 90.0
    m = 1.0
    # (ceiling, from, to, sizes)
    plan: list[tuple[bool, str, str, tuple[bool, ...]]] = []
    both = (False, True)
    # (a) the half does not change -- the control
    for mode, target in (("cube", "ball"), ("ball", "cube"),
                         ("robot", "cube"), ("spider", "cube")):
        plan.append((False, mode, target, both))
    for mode, target in (("ship", "ball"), ("cube", "ball"), ("ball", "cube"),
                         ("ufo", "ball"), ("robot", "cube"),
                         ("spider", "cube")):
        plan.append((True, mode, target, both))
    # (b) the half shrinks 15 -> 13.5
    for mode in ("cube", "ball"):
        plan.append((False, mode, "spider", both))
    for mode in ("ball", "ufo"):
        plan.append((True, mode, "spider", both))
    # (c) HOW OLD THE RIDE IS when the portal fires. Everything above meets it
    # with the ride saturated (38 ticks, measured), and lv20's second body meets
    # it ONE TICK after landing on the ramp -- which is the only difference left
    # between GD's two answers. `ball` keeps the half unchanged, so these live.
    ages: tuple[float, ...] = (1.0, 2.0, 3.0, 5.0, 9.0, 15.0)
    # (d) ...and 15 -> 5, which is lv20's, and which dies. LAST.
    for ceiling, mode, target, sizes in plan:
        for mini in sizes:
            x0 = x
            u, x, info = ridemode_unit(x, mode, target, m, mini, ceiling)
            objs += u
            UNITS.append({"x0": x0, "x1": x, "mode": mode, "target": target,
                          "m": m, "mini": int(mini), "ceiling": int(ceiling),
                          "age": -1, **info})
    for age in ages:
        x0 = x
        u, x, info = ridemode_unit(x, "ufo", "ball", m, False, True,
                                   ride_ticks=age)
        objs += u
        UNITS.append({"x0": x0, "x1": x, "mode": "ufo", "target": "ball",
                      "m": m, "mini": 0, "ceiling": 1, "age": age, **info})
    x0 = x
    u, x, info = ridemode_unit(x, "ufo", "wave", m, False, True)
    objs += u
    UNITS.append({"x0": x0, "x1": x, "mode": "ufo", "target": "wave",
                  "m": m, "mini": 0, "ceiling": 1, "age": -1, **info})
    # Floor LAST = a larger uid than the portals (build_ramps L305).
    objs += floor_run(0, PAVE_X)
    return header() + ";" + ";".join(objs) + ";"


def ridedrop_unit(x: float, mode: str, target: str, mini: bool,
                  port_x: float | None = None, n_ramps: int = 6,
                  top: float = 375.0) -> tuple[list[str], float, dict]:
    u"""ARRIVE AT THE RAMP BY PENETRATING IT, not by sliding onto it.

    `ridemode` asked GD 39 times whether a mode portal ends a ramp ride and got
    "no" every time, across the ramp's side, six modes, both sizes, a box that
    stays the same or shrinks to a fifth, a ride 0 to 40 ticks old, and both
    halves of a dual. lv20 t=17,117 still does the opposite. The one thing all
    39 hold fixed is HOW THE BODY GOT ONTO THE RAMP: every one of them slides on,
    following the surface down, and its first contact tick moves LESS than a full
    ride step (-0.354 measured). lv20's second body is born inside the ramp by
    the dual portal and pushed out of it -- its first contact tick moves -2.583,
    MORE than the ride step.

    So this unit arrives the other way. A gravity flip under an open sky lets the
    body fall upward for ~95 ticks while a ceiling ramp descends to meet it, and
    they close at about 4 px/tick -- the same order as lv20's 2.583. The body
    cannot follow that surface onto itself; it goes through and is pushed back.

        [mode][size][flip]......(open, the body accelerates upward)......
                          [6 ceiling ramps descending from `top`][flat][restore]

    `port_x` is the mid-ride mode portal. It is left off on the first pass --
    where the body meets the ramp is a measurement, not a calculation -- and
    placed on the second from the contact tick the dump reports.
    """
    oid, rot, fx, fy, w, h = CEIL_RAMP[1.0]
    objs: list[str] = []
    for py in (GROUND_TOP + 15.0, GROUND_TOP + 105.0):
        objs.append(obj(MODE_PORTAL[mode], x, py))
        objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID, py))
    objs.append(obj(GRAV_FLIP, x + 6 * GRID, GROUND_TOP + 15.0))
    x_ramp = x + 8 * GRID
    for i in range(n_ramps):
        cy = top - h / 2.0 - i * h
        objs.append(obj(oid, x_ramp + i * w + w / 2.0, cy,
                        rot=rot, flip_x=fx, flip_y=fy))
        # Fill ABOVE the diagonal only. The body comes up from underneath, so
        # the diagonal has to be the lowest solid thing it can meet.
        yy = cy + h / 2.0 + GRID / 2
        while yy <= top + GRID / 2 + 1.0:
            for k in range(int(w / GRID)):
                objs.append(obj(BLOCK, x_ramp + i * w + GRID / 2 + k * GRID, yy))
            yy += GRID
    x_flat = x_ramp + n_ramps * w
    low = top - n_ramps * h
    x_end = x_flat + 16 * GRID
    xx = x_flat + GRID / 2
    while xx < x_end:
        objs.append(obj(BLOCK, xx, low + GRID / 2))
        xx += GRID
    port_cy = 0.0
    if port_x is not None:
        # The seat is line(centre + 6.21) - half (measured on `ridemode`), and
        # the portal fires ~32 px before its own centre.
        s = port_x - 32.0 + 6.21
        line = top - max(0.0, min(s - x_ramp, n_ramps * h))
        port_cy = line - (9.0 if mini else 15.0)
        objs.append(obj(MODE_PORTAL[target], port_x, port_cy))
    objs.append(obj(GRAV_NORM, x_flat + 12 * GRID, low - 15.0))
    return objs, x_end + 14 * GRID, {"x_ramp": x_ramp, "ramp_w": w,
                                     "ramp_h": h, "top": top,
                                     "port_cx": port_x or 0.0,
                                     "port_cy": port_cy, "ceil_y": low}


# WHERE EACH MODE FIRST TOUCHES THE RAMP, relative to the unit's own x0, and
# what its arrival looks like. Measured on the first pass (the same geometry
# with no mid portal), which is the only honest way to place a portal by tick:
#
#   ufo    +333.13   dy +0.53 against a free +1.44   (both ufo units agree
#                                                     to 0.19 px)
#   cube   +279.02   dy +1.28 against a free +3.38
#   ball   +301.47   dy +0.37 against a free +3.28
#
# Every one is CLAMPED SHORT on the contact tick -- the body would have gone
# 1 to 3 px further into the ramp and GD stops it at the seat. That is the
# arrival lv20's second body has (its own tick moves -2.583 against a velocity
# of +2.86) and the one `ridemode` never produced: there the body slides on and
# the first tick moves -0.354, LESS than a full ride step and in the same
# direction it was already going.
RIDEDROP_CONTACT = {"ufo": 333.13, "cube": 279.02, "ball": 301.47}


def build_ridedrop() -> str:
    u"""Does contact ACQUIRED BY A CLAMP start a ride? lv20's last difference.

    Pass 1 is this same file with `RIDEDROP_CONTACT` empty: build the drop
    geometry, let the run say where each mode meets the ramp, and read it back
    with `grabcontact`. Pass 2 places the mid portal 0, 1 and 2 ticks after that
    contact -- lv20's is 1 -- so the answer does not hang on a single placement
    being right to the tick.

    The `wave` unit is LAST and dies: it is lv20's own target, and one death
    ends the run.
    """
    objs: list[str] = []
    x = 90.0
    plan = [(mode, target, k)
            for mode, target in (("ufo", "ball"), ("cube", "ball"),
                                 ("ball", "cube"))
            for k in (0, 1, 2)]
    plan.append(("ufo", "wave", 1))
    for mode, target, k in plan:
        x0 = x
        port = None
        if mode in RIDEDROP_CONTACT:
            port = x0 + RIDEDROP_CONTACT[mode] + k * DX_1X + 32.0
        u, x, info = ridedrop_unit(x, mode, target, False, port)
        objs += u
        UNITS.append({"x0": x0, "x1": x, "mode": mode, "target": target,
                      "m": 1.0, "mini": 0, "ceiling": 1, "age": k, **info})
    objs += floor_run(0, PAVE_X)
    return header() + ";" + ";".join(objs) + ";"


# THE CEILING HAS TO SIT UNDER THE BAND, and 380 does not. `ceil_unit_dual`
# picked DUAL_CEIL = 380 to clear the deepest |m|=2 chain; measured on the first
# cut of this rig, a `header(dual=True)` level reports pmax = 360, so the second
# body is held by the INVISIBLE CEILING at 345 and never reaches a ceiling laid
# at 380 -- it ran the whole level as a cube, and not one head portal fired.
# 330 leaves the band alone: the body hangs at 315 and the three |m|=1 ramps
# bottom out at 240.
RIDEDUAL_CEIL = 330.0


def ridemodedual_unit(x: float, mode: str, target: str, m: float, mini: bool
                      ) -> tuple[list[str], float, dict]:
    u"""`ridemode`, but THE SECOND BODY of a dual is the one on the ramp.

    `ceil_unit_dual` with a mode portal added mid-ride, and it inherits that
    unit's three rules unchanged, all of them forced by the pair: no gravity
    portals (the second body is already inverted and has to stay that way from
    one unit to the next), the head portals AT THE CEILING (a floor-height
    portal is taken by the first body and never reached by the second --
    measured on `dualmode`, 3,471 consecutive ticks with the halves in different
    modes), and ONE ceiling height for every unit, since the second body flies
    between them.

    Why this rig exists: three cuts of `ridemode` have now failed to reproduce
    lv20 t=17,117. GD takes the ride's own step through a mode portal on a floor
    ramp and on a ceiling one, in every mode, at both sizes, with the box the
    same size or shrinking to a fifth, and with the ride anything from ONE tick
    to forty ticks old -- 29 of 29, and then 1 of 1 at age 0. lv20's body does
    none of that: it steps +0.029, the free step, and takes the ramp exit's
    -2.762 on the portal tick itself.

    Everything that rig can vary has been varied. What is left is the thing it
    cannot: THE BODY IS THE SECOND HALF OF A DUAL. The first body agrees with
    the model tick for tick through the whole site, so if being the second half
    is what does it, that is the last place it can be hiding.
    """
    oid, rot, fx, fy, w, h = CEIL_RAMP[m]
    objs: list[str] = []
    ceil = RIDEDUAL_CEIL
    objs.append(obj(MODE_PORTAL[mode], x, ceil - 15.0))
    objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID, ceil - 15.0))
    n_ramps = 3
    x_ramp = x + 20 * GRID
    # NO PER-UNIT FLAT CEILING: `build_ridemodedual` lays one continuous run
    # from x=0, because the second body is launched upward at the level's start
    # and clears 435 before the first unit's ceiling would have begun -- measured
    # on cut 2 of this rig, where it then sat above the ceiling for the whole
    # level and not one mid-ramp portal fired.
    for i in range(n_ramps):
        cy = ceil - h / 2.0 - i * h
        objs.append(obj(oid, x_ramp + i * w + w / 2.0, cy,
                        rot=rot, flip_x=fx, flip_y=fy))
        yy = cy + h / 2.0 + GRID / 2
        while yy <= ceil + GRID / 2 + 1.0:
            for k in range(int(w / GRID)):
                objs.append(obj(BLOCK, x_ramp + i * w + GRID / 2 + k * GRID, yy))
            yy += GRID
    port_cx = x_ramp + 2.5 * w
    travel = max(0.0, port_cx - 32.0 + 6.2 - x_ramp)
    i_at = min(n_ramps - 1, int(travel / w))
    surf = ceil - i_at * h - (travel - i_at * w) * (h / w)
    port_cy = surf - (9.0 if mini else 15.0)
    objs.append(obj(MODE_PORTAL[target], port_cx, port_cy))
    x_flat = x_ramp + n_ramps * w
    x_end = x_flat + 16 * GRID
    return objs, x_end + 14 * GRID, {"x_ramp": x_ramp, "ramp_w": w,
                                     "ramp_h": h, "port_cx": port_cx,
                                     "port_cy": port_cy, "ceil_y": ceil}


def build_ridemodedual() -> str:
    u"""The second body of a dual meets a mode portal mid-ride. lv20's own shape.

    The `wave` unit is LAST and cannot survive: a flipped wave with no input
    flies straight back into the ceiling it just left. A p2 death ends the run
    ("dual: booked a p2 death as the run end"), so everything after it would be
    lost -- and it is the one unit that matters most, so it also gets the
    cheapest possible approach to it.
    """
    objs: list[str] = []
    x = 90.0
    m = 1.0
    for mode, target in (("ufo", "ball"), ("ball", "cube"), ("ufo", "spider"),
                         ("ufo", "wave")):
        x0 = x
        u, x, info = ridemodedual_unit(x, mode, target, m, False)
        objs += u
        UNITS.append({"x0": x0, "x1": x, "mode": mode, "target": target,
                      "m": m, "mini": 0, "ceiling": 1, "dual": 1, **info})
    # One ceiling for the whole level, laid last so its uid is above the ramps'
    # (build_ramps L305). The ramps hang BELOW it, so where they exist they are
    # the surface the second body meets and this row is inert.
    xx = GRID / 2
    while xx <= x + 20 * GRID:
        objs.append(obj(BLOCK, xx, RIDEDUAL_CEIL + GRID / 2))
        xx += GRID
    objs += floor_run(0, PAVE_X)
    return header(dual=True) + ";" + ";".join(objs) + ";"


def build_ceilhold() -> str:
    u"""Rig that HOLDS THE BUTTON DOWN while riding a ceiling ramp (the pressed
    version of ceilramp).

    The corpus' last ceiling family, lv18@3,010 (mini ship, m=-1, in=1), has the
    shape "GD writes vy=-2.000 ONLY ON THE TICK THE BUTTON IS PRESSED WHILE
    RIDING THE HANGING SIDE" (y matches bit for bit on every tick; the only
    thing that splits is vy, on a single tick):

        t=3,007..3,009 in=0  GD vy=0.000 (model 0.000 too)
        t=3,010        in=1  GD vy=-2.000 / model -0.101
        t=3,011        in=0  GD vy=0.000 (model 0.000 too)

    The floor side got the same rule in r39a (`c.mode==1 && input` -> 2.000*dir
    on attachment, then +kShipRampG*dir). THE HANGING-SIDE BRANCH (flipped,
    sliding along the underside of a ceiling ramp) DOES NOT HAVE IT -- that side
    only has the `if vy>0 then 0` whitelist. The r39 note saying "the downhill
    (dir=-1) ladder is unmeasured" was about exactly this.

    Same geometry as ceilramp (which passes 43/43) with a single press window
    added. The window is 35%-75% of the ramp chain -- the middle, which fouls
    neither the attachment nor the launch -- and lasts 10-30 ticks, so a single
    run settles "is it written once or every tick" and "does the ladder build
    up" as well.

    MODE ORDER: modes that leave the surface when pressed (wave takes GD down on
    its own units of ceilramp; spider warps to the opposite surface) GO LAST
    (the rig's rule).
    """
    objs: list[str] = []
    x = 90.0
    # [2026-08-21 measured] WAVE GOES LAST. It took GD itself down at unit36
    # (wave's first), leaving all 6 spider units EMPTY (same as ceilramp).
    for mode in ("ship", "ufo", "cube", "ball", "robot", "swing",
                 "spider", "wave"):
        for m in (1.0, 0.5, 2.0):
            for mini in (False, True):
                x0 = x
                u, x = ceil_unit(x0, mode, m, mini)
                objs += u
                w, h = CEIL_RAMP[m][4], CEIL_RAMP[m][5]
                x_ramp = x0 + 20 * GRID
                chain = 3 * w
                xp0 = x_ramp + 0.35 * chain
                xp1 = x_ramp + 0.75 * chain
                t_press, t_rel = tick_at(xp0), tick_at(xp1)
                PLAN.append((t_press, 1))
                PLAN.append((t_rel, 0))
                UNITS.append({"x0": x0, "x1": x, "mode": mode, "m": m,
                              "mini": int(mini),
                              "x_ramp": x_ramp, "ramp_w": w, "ramps": 3,
                              "ceil_y": ceil_y_for(h, 3),
                              "hold_x0": round(xp0, 2),
                              "hold_x1": round(xp1, 2),
                              "t_press": t_press, "t_rel": t_rel})
    objs += floor_run(0, PAVE_X)
    return header() + ";" + ";".join(objs) + ";"


def build_portrot() -> str:
    u"""Rig for measuring THE HITBOX OF A ROTATED PORTAL. Zero input.

    On lv21 uid24194 (id111 UFO portal, rot=43, raw size 34x86, bounding box
    167x172) GD fires at a point 54.07px in x from the centre. That is neither
    the bounding box's 83.5 nor the ~41.7 of "a 34x86 box rotated by 43
    degrees". Sweep the angle to recover the shape of the half-width.

    One unit = [cube portal (reset, rot 0)][run-up][UFO portal (rot theta)].
    The player runs as a normal-size cube, and the x of the tick where mode
    changes to ufo gives the effective half-width
    = portal_cx - x_fire + 15. With no input a UFO just falls and slides along
    the ground, so the next unit's cube portal can reset it.
    """
    objs: list[str] = []
    x = 90.0
    objs += floor_run(0, PAVE_X)
    for rot in (0, 10, 20, 30, 40, 43, 45, 50, 60, 70, 80, 90):
        x0 = x
        objs.append(obj(P_CUBE, x, GROUND_TOP + 15.0))
        x_port = x + 10 * GRID
        objs.append(obj(P_UFO, x_port, GROUND_TOP + 15.0, rot=float(rot)))
        x = x_port + 20 * GRID
        UNITS.append({"x0": x0, "x1": x, "rot": rot, "x_port": x_port,
                      "mode": "ufo", "m": 0, "mini": 0, "player": "cube"})
    return header() + ";" + ";".join(objs) + ";"


def build_portwave() -> str:
    u"""The portrot rig with THE PLAYER AS A MINI WAVE. Zero input.

    Working back from lv21 t=18,087 says "a mini wave's portal contact half-size
    is 15.9-16.8", yet the model's kWaveContactHalfMini is 3.0 (fitted to the
    lv20 symptom). SINCE EVERY PORTAL ON lv20 IS rot=0 AND lv21's IS 43 DEGREES,
    measuring both the axis-aligned case (the boundary is a + w0/2, so the x
    half-size a acts directly) and the rotated case (what binds is the box's u
    axis, a mix of a and the y half-size b) separates a from b.

    With no input a wave travels diagonally downward, so it slides along the
    ground. The portals are placed at a height that overlaps the player's path
    (just above the ground).
    """
    objs: list[str] = []
    x = 90.0
    objs += floor_run(0, PAVE_X)
    for rot in (0, 20, 43, 60, 90):
        x0 = x
        # Reset to cube every time, then go mini wave (the size is rebuilt too)
        objs.append(obj(P_CUBE, x, GROUND_TOP + 15.0))
        objs.append(obj(SIZE_MINI, x + 2 * GRID, GROUND_TOP + 15.0))
        objs.append(obj(P_WAVE, x + 4 * GRID, GROUND_TOP + 15.0))
        x_port = x + 14 * GRID
        objs.append(obj(P_UFO, x_port, GROUND_TOP + 15.0, rot=float(rot)))
        # Back to normal size for the next unit
        objs.append(obj(SIZE_NORM, x_port + 10 * GRID, GROUND_TOP + 15.0))
        x = x_port + 24 * GRID
        UNITS.append({"x0": x0, "x1": x, "rot": rot, "x_port": x_port,
                      "mode": "ufo", "m": 0, "mini": 1, "player": "wave"})
    return header() + ";" + ";".join(objs) + ";"


def build_rampjump() -> str:
    u"""Rig for measuring the bonus added when JUMPING WHILE STILL ON A RAMP.

    `ramps` is a zero-input rig measuring the launch on "leaving the top of the
    ramp", so it never yields the value for a press INSIDE the ramp window. GD
    adds the ride contribution to the plain jump there (updateJump 0x38bc77,
    gated on this+0xb58). The 22 official levels only sample this 3 times, all
    at |m|=0.5, so the gradient dependence cannot be separated.

    The shape is the same as ramp_unit, with one press placed PARTWAY through
    the n ramps.
    - The press x is at 70% of the ramp band (well into the ride, but before the
      top end)
    - n=3 exceeds a 24-tick ride, so the ramp factor saturates at 1.0
    - cube and robot only (a ball's tap flips gravity, a spider teleports)
    - Do not hold (press -> release 3 ticks later), so a held re-jump does not
      leak into the next unit

    BUILD IT IN TWO PASSES: run it once without --xmap, take the dump, and
    regenerate passing that dump to --xmap (the x prediction of the press tick
    drifts on a long rig).
    """
    objs: list[str] = []
    x = 90.0
    objs += floor_run(0, PAVE_X)
    for mode in ("cube", "robot"):
        for m in (1.0, 0.5, 2.0):
            for mini in (False, True):
                x0 = x
                _oid, _rot, _fx, _fy, w, _h = RAMP[m]
                # Breakdown of ramp_unit: 2 portals -> 8 cells of run-up -> 3 ramps
                x_ramp0 = x + 8 * GRID
                x_press = x_ramp0 + 3 * w * 0.70
                u, x = ramp_unit(x, mode, m, mini, 3, 0.0)
                objs += u
                t = tick_at(x_press)
                PLAN.append((t, 1))
                PLAN.append((t + 3, 0))
                UNITS.append({"x0": x0, "x1": x, "mode": mode, "m": m,
                              "mini": int(mini), "ramps": 3, "bury": 0.0,
                              "press_x": x_press, "press_t": t})
    return header() + ";" + ";".join(objs) + ";"


def build_ufojump(speed: int = 0) -> str:
    u"""Rig for the bonus a UFO gets when it flaps WHILE STILL ON A FLOOR RAMP.

    build_rampjump above says "cube and robot only", and gives reasons for the
    ball and the spider -- but not for the UFO, which was simply never added.
    The consequence is recorded at step.hpp:7814-7825: the UFO's "plain jump,
    no launch" was measured on the ceilhold rig, whose 4 UFO cells all press
    while HUNG FLIPPED FROM A CEILING ramp. The floor side has never been swept
    for a UFO, and the model's on-ramp bonus (kSlopeJumpBonus) never fires for
    one -- all 47 firings in lv19 are cube or robot.

    The corpus has exactly ONE instance, lv19 t=14,620, where GD gives 8.000
    against the model's plain 6.871. One instance cannot choose between

        no bonus      6.871 everywhere                (what the model does)
        cube row      0.25 * slopeExitVy(|m|, cube) * rampFactor, cap 0.4x
        UFO row       the same with the UFO's own exit row
        assignment    8.000 regardless of anything

    so it is deliberately NOT part of this rig. The rig decides the law; 14,620
    is then out-of-sample verification. Folding it in would put us back on the
    single fitted point.

    Cells:
      2 CONTROLS -- press on the flat run-up, before the ramps. These must come
        back 6.871 (normal) and 6.648 (mini), the values ceilhold and lv12
        already pin. If they do not, nothing else in the rig is usable.
      12 SWEEP -- |m| in {1, 0.5, 2} x {normal, mini} x {1 ramp, 3 ramps}.
        The gradient separates the two "row" hypotheses from each other and
        from the assignment; the ramp count varies the ride time, and so the
        ramp factor, which only the two row hypotheses depend on (3 ramps
        saturate it at 1.0, 1 ramp does not).

    Press and release 3 ticks later, as rampjump does, so a held re-flap cannot
    leak into the next unit -- and a UFO in particular flaps once per EDGE.
    Two passes, like rampjump: build, dump, rebuild with --xmap.
    """
    objs: list[str] = []
    x = 90.0
    objs += floor_run(0, PAVE_X)
    for mini in (False, True):
        x0 = x
        # the press lands on the flat run-up: 8 cells of it precede the ramps
        x_press = x + 4 * GRID
        u, x = ramp_unit(x, "ufo", 1.0, mini, 3, 0.0)
        objs += u
        t = tick_at(x_press)
        PLAN.append((t, 1))
        PLAN.append((t + 3, 0))
        UNITS.append({"x0": x0, "x1": x, "mode": "ufo", "m": 1.0,
                      "mini": int(mini), "ramps": 3, "bury": 0.0,
                      "press_x": x_press, "press_t": t, "cell": "control"})
    for m in (1.0, 0.5, 2.0):
        for mini in (False, True):
            for n_ramps in (1, 3):
                x0 = x
                _oid, _rot, _fx, _fy, w, _h = RAMP[m]
                x_ramp0 = x + 8 * GRID
                x_press = x_ramp0 + n_ramps * w * 0.70
                u, x = ramp_unit(x, "ufo", m, mini, n_ramps, 0.0)
                objs += u
                t = tick_at(x_press)
                PLAN.append((t, 1))
                PLAN.append((t + 3, 0))
                UNITS.append({"x0": x0, "x1": x, "mode": "ufo", "m": m,
                              "mini": int(mini), "ramps": n_ramps,
                              "bury": 0.0, "press_x": x_press,
                              "press_t": t, "cell": "sweep",
                              "speed": speed})
    # The whole rig runs at one speed (kA4 is a level setting), so the speed
    # axis is a second BUILD rather than more cells. lv19 t=14,620's own speed
    # is 1.1 = kA4 2, and without a cell there the 8.722-vs-8.000 gap is
    # confounded: "the law is wrong" and "the conditions differ" cannot be told
    # apart. `ufojump` is the default speed, `ufojump_sp` matches lv19.
    return header(speed=speed) + ";" + ";".join(objs) + ";"


def build_robotjump_sp() -> str:
    u"""A mini robot's press on a flat run-up and on an |m|=2 ramp, at speed 1.1.

    lv22 t=18,567 presses a mini robot riding an |m|=2 ramp at speed 1.1, and
    GD does not jump: replayed with a 1-tick press, a 3-tick hold and no press
    at all, x, y and yvel come out identical. rampjump already has GD jumping
    in the same mode, size and gradient -- but at the default speed and moving
    forward. This rig changes one of those two, the speed, and keeps a flat
    control in the same run, so that "the rig did not produce the state"
    cannot pass for an answer. lv22 rides that stretch in -x; nothing here can
    build a reverse ride, so direction is not a cell.

    Cells (mini robot, kA4 2 = 1.1, press then release 3 ticks later):
      control -- press on the flat run-up, as ufojump's controls do
      sweep   -- |m|=2 x 3 ramps, press at 70% of the ramp band, as rampjump
    Two passes, like rampjump: build, dump, rebuild with --xmap.
    """
    objs: list[str] = []
    x = 90.0
    objs += floor_run(0, PAVE_X)
    x0 = x
    x_press = x + 4 * GRID
    u, x = ramp_unit(x, "robot", 2.0, True, 3, 0.0)
    objs += u
    t = tick_at(x_press)
    PLAN.append((t, 1))
    PLAN.append((t + 3, 0))
    UNITS.append({"x0": x0, "x1": x, "mode": "robot", "m": 2.0, "mini": 1,
                  "ramps": 3, "bury": 0.0, "press_x": x_press, "press_t": t,
                  "cell": "control", "speed": 2})
    x0 = x
    _oid, _rot, _fx, _fy, w, _h = RAMP[2.0]
    x_ramp0 = x + 8 * GRID
    x_press = x_ramp0 + 3 * w * 0.70
    u, x = ramp_unit(x, "robot", 2.0, True, 3, 0.0)
    objs += u
    t = tick_at(x_press)
    PLAN.append((t, 1))
    PLAN.append((t + 3, 0))
    UNITS.append({"x0": x0, "x1": x, "mode": "robot", "m": 2.0, "mini": 1,
                  "ramps": 3, "bury": 0.0, "press_x": x_press, "press_t": t,
                  "cell": "sweep", "speed": 2})
    return header(speed=2) + ";" + ";".join(objs) + ";"


def build_ufoexit() -> str:
    u"""Does a UFO get a slope-exit launch on the FLOOR side? Rig says yes/no.

    build_ramps is the exit-launch rig and its own note says why the UFO is not
    in it: "The flight modes (ship/UFO/wave) need input, so they get their own
    rig." That rig was never written. So the UFO's exit has no measurement on
    the floor side, exactly as its on-ramp flap had none until `calib_ufojump`.

    lv19 t=14,643 is the corpus' single witness and it says GD does not launch:
    the model ends the ride and overwrites vy 5.162 -> 2.877, while GD takes one
    plain gravity step, 5.162 - 0.129 = 5.033, and flies on. The -2.156 then
    persists exactly, which is the signature of one velocity overwrite and not
    of a continuing mechanism.

    THIS RIG MEASURES AN ABSENCE, so it carries two separate proofs:
      * the two CUBE control cells prove the rig can see an exit at all. Their
        expected value is computed from slopeExitVy with this rig's own inputs,
        NOT recalled from calib_ramps -- that rig's geometry is not this one, and
        a remembered number would let "roughly right" pass.
      * a cube riding proves nothing about a UFO riding: hitboxes and seating
        conditions differ per mode. So each UFO cell must show the riding
        signature in its own right for the ticks before the exit -- onGround
        held, y following the line, vy stepping -0.129 (mini -0.152). A cell
        without that signature is a cell where the UFO never sat down, and its
        silence means nothing; it gets thrown away, not read as "no launch".

    Zero input throughout, like build_ramps, so there are no press ticks to
    drift and no two-pass rebuild. ramps=3 only: `calib_ufojump` established that
    ride time does not enter the UFO's on-ramp value at all (factor 0.674 against
    1.000, same result), so a second ride length would cost cells and decide
    nothing.
    """
    objs: list[str] = []
    x = 90.0
    for mini in (False, True):
        x0 = x
        u, x = ramp_unit(x, "cube", 1.0, mini, 3, 0.0)
        objs += u
        UNITS.append({"x0": x0, "x1": x, "mode": "cube", "m": 1.0,
                      "mini": int(mini), "ramps": 3, "bury": 0.0,
                      "cell": "control"})
    for m in (1.0, 0.5, 2.0):
        for mini in (False, True):
            x0 = x
            u, x = ramp_unit(x, "ufo", m, mini, 3, 0.0)
            objs += u
            UNITS.append({"x0": x0, "x1": x, "mode": "ufo", "m": m,
                          "mini": int(mini), "ramps": 3, "bury": 0.0,
                          "cell": "sweep"})
    objs += floor_run(0, PAVE_X)
    return header() + ";" + ";".join(objs) + ";"


def build_orbs() -> str:
    """Orb calibration rig. Ground modes x orb kinds x normal/mini.

    On the 22 official levels, orbs are the family that mass-produces
    contact-boundary (+/-1 tick) fixups (12 orbnear on lv10, the kills on
    lv19/lv21, etc.), and the per-mode ratios only ever existed as "measured
    individually". This measures them all at once.
    """
    objs: list[str] = []
    x = 90.0
    for mode in ("cube", "ball", "robot", "spider"):
        for kind in ("yellow", "pink", "blue", "green", "red", "black",
                     "dash", "gravdash", "spider"):
            for mini in (False, True):
                x0 = x
                u, pl, x, tp, tr = orb_unit(x, kind, mode, mini, 60.0)
                objs += u
                PLAN.extend(pl)
                # PUT THE PRESS WINDOW IN THE TABLE. If the extractor takes "the
                # first spike inside the unit", it misreads the landing of the
                # previous unit's arc as a fire (measured: every mini unit was
                # filled with the previous unit's landing). Look only inside the
                # window.
                UNITS.append({"x0": x0, "x1": x, "mode": mode, "orb": kind,
                              "mini": int(mini), "t_press": tp, "t_rel": tr})
    return header() + ";" + ";".join(objs) + ";"


def orbair_unit(x: float, kind: str, mode: str, mini: bool, off: float,
                early: bool = False
                ) -> tuple[list[str], list[tuple[int, int]], float, int, int]:
    """An orb unit that MAKES THE TAP HAPPEN IN MID-AIR (a curtain of orbs).

    On the ground-tap rig, robot/spider produced the mode's own action
    (5.590 / 1.000+flip) and the orb's value could not be obtained. In mid-air
    there is no grounded action, so the press can only mean the orb firing.

    The launch uses the ALREADY-MEASURED slope-exit launch (|m|=1, saturated
    with 3 ramps). The arc is only about 30px tall, so stacking the same orb
    vertically into a "curtain" guarantees that any trajectory touches one of
    them -- no need to predict the arc (the launch value and the gravity both
    differ per mode, so predicting would make the rig mode-dependent).
    `off` is the x offset from the top end; sweeping it sweeps THE INCOMING vy
    (small = still rising, large = already falling).
    """
    oid, _ = ORB[kind]
    ramp_id, rot, fx, fy, w, h = RAMP[1.0]
    objs: list[str] = []
    y0 = GROUND_TOP + 15.0
    objs.append(obj(MODE_PORTAL[mode], x, y0))
    objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID, y0))
    # 3 ramps climb from world 90 to 180, with the launch at the top end
    xr = x + 8 * GRID
    bottom = GROUND_TOP
    for i in range(3):
        objs.append(obj(ramp_id, xr + w / 2.0, bottom + h / 2.0,
                        rot=rot, flip_x=fx, flip_y=fy))
        yy = GROUND_TOP + GRID / 2
        while yy < bottom:
            objs.append(obj(BLOCK, xr + GRID / 2, yy))
            yy += GRID
        bottom += h
        xr += w
    x_top = xr                      # the launch is on the tick that leaves here
    # The curtain: a vertical column covering the arc's height (90px above and
    # below the top end)
    x_orb = x_top + off
    yy = bottom - 60.0
    while yy <= bottom + 90.0:
        objs.append(obj(oid, x_orb, yy))
        yy += GRID
    # The press window opens WELL AFTER THE LAUNCH. At +12px the launch tick
    # falls inside the window for some modes, and the extractor misread the
    # launch (incoming vy=0 -> 7.405) as the orb (every robot/spider unit was
    # filled with that). The player's half-width differs per mode, so the x at
    # which it leaves the top end differs too -- leaving margin is the right
    # answer.
    # [2026-08-22] `early`: arrive WITH THE BUTTON HELD FROM LONG BEFORE. In the
    # corpus, lv21@7,217 touches the black orb after 117 TICKS OF HOLDING (GD's
    # `orb:` line, press=7098 lag=117), and only there does the terminal clamp
    # come 1 tick late. The rig's default (45px past the launch = a lag of a few
    # ticks) shows no such delay, so this sweeps whether the press length is the
    # discriminator.
    # early starts pressing RIGHT AFTER THE LAUNCH (in mid-air). Pressing on the
    # ground consumes the press on the player's own jump and the orb never fires
    # (the v3 failure: all 8 units `no drop`). Start at +2px, which does not
    # straddle the launch tick.
    t_press = tick_at(x_top + 2.0) if early else tick_at(x_top + 45.0)
    t_rel = tick_at(x_orb + 24.0)
    x_next = x_orb + 40 * GRID
    # A ceiling for the kinds that flip gravity (blue/green/gravity dash), plus
    # a gravity reset at the end of the unit. Without them the player "falls"
    # upward and dies off-screen (the same trap as the orb rig).
    ceil = GROUND_TOP + 330.0
    xx = x - GRID
    while xx <= x_next:
        objs.append(obj(BLOCK, xx, ceil + GRID / 2))
        xx += GRID
    objs.append(obj(GRAV_NORM, x_next - 4 * GRID, y0))
    objs.append(obj(GRAV_NORM, x_next - 4 * GRID, ceil - 15.0))
    return objs, [(t_press, 1), (t_rel, 0)], x_next, t_press, t_rel


def build_orbair() -> str:
    """Mid-air-tap orb rig. 4 orb kinds x 4 ground modes x 4 incoming points
    (normal size).

    Two things are wanted: (1) can the orb's value be obtained on robot/spider,
    (2) DOES THE FIRE VALUE DEPEND ON THE INCOMING vy (if it does not, it is an
    assignment, and the orbnear fixups are a problem of the contact tick rather
    than of the value).
    """
    objs: list[str] = []
    x = 90.0
    for mode in ("cube", "ball", "robot", "spider"):
        for kind in ("yellow", "pink", "blue", "red"):
            for off in (60.0, 90.0, 120.0, 150.0):
                x0 = x
                u, pl, x, tp, tr = orbair_unit(x, kind, mode, False, off)
                objs += u
                PLAN.extend(pl)
                UNITS.append({"x0": x0, "x1": x, "mode": mode, "orb": kind,
                              "mini": 0, "off": off,
                              "t_press": tp, "t_rel": tr})
    return header() + ";" + ";".join(objs) + ";"


def dualport_unit(x: float, kind: str, mode: str
                  ) -> tuple[list[str], float, dict]:
    u"""One portal unit inside a dual. ZERO INPUT.

    The corpus' lv16@13,496 is "a same-mode ship portal and a normal-gravity
    portal take effect on the same tick, GD applies x1/4, and upsideDown does
    not move", and that single sample admits at least three readings (2 ship
    fly-ends + gravity passing through / 1 ship fly-end + gravity halving
    without a flip / ...). MEASURING THE SITUATIONS ONE AT A TIME is what this
    rig is for.

    kind:
      same   only a same-mode mode portal (ship->ship)
      gnorm  only a normal-gravity portal (id10)
      ginv   only an inverting gravity portal (id11)
      both   same + gnorm overlaid (reproduces lv16)
      othr   only a different-mode portal (ship->UFO) = the control for two fly-ends
      size   only a size portal (a control that does not halve)

    The portals are STRETCHED VERTICALLY WITH scale SO THEY HIT BOTH PLAYERS
    (a dual's two players stick to the top and bottom of the band, so a raw
    34x86 only hits one of them).
    """
    objs: list[str] = []
    # The track is A NARROW 60px CORRIDOR. A dual's two players stick to the top
    # and bottom of the band, so without a narrow corridor the lv16 situation of
    # "one portal hitting both players" cannot be created. A raw portal (34x86)
    # centred in the corridor covers both.
    # Stretching with scale STRETCHES IT HORIZONTALLY TOO AND OVERLAPS THE
    # NEIGHBOURING UNIT (the v1 failure: scale 4 made it 136px wide and both the
    # mode and the size leaked in from the previous unit).
    #
    # [v3] WIDEN THE CORRIDOR JUST BEFORE THE PORTAL. In v2 both players passed
    # through at rest on a surface with vy=0, so THE HALVING WAS IN PRINCIPLE
    # INVISIBLE (the coefficient on vy is exactly what we want). Raising the
    # floor to 200 and the ceiling to 260, then opening the floor to 170 and the
    # ceiling to 290 25px before the portal, gives both players 30px of free
    # flight so they enter the portal at |vy|~2.
    # [v4] The floor STAYS AS THE WORLD GROUND and the ceiling is fixed 150px up
    # (240).
    #   v3  = stacked a floor -> the spawn position was inside a solid and the
    #         whole rig died instantly
    #   v3b = opened the ceiling partway -> the two players never returned to the
    #         corridor, and later units' mode/size portals only hit one of them
    # v4 LAUNCHES THE LOWER PLAYER (p1) WITH A YELLOW PAD and lets it enter the
    # portal in flight. The corridor height never changes, so the units stay
    # independent. The upper player (p2) stays at rest on the ceiling = "what
    # happens to the partner that is NOT inside the portal's box" can be read at
    # the same time (a test of the dual mirror rule).
    # [v5] When kind is "g2in", shape it so BOTH PLAYERS ARE INSIDE THE SAME BOX
    # (reproducing lv16@13,496). Lowering the ceiling to 200 puts the upper
    # player at rest at 185, only 10px from the apex (105+70=175) of the lower
    # player launched by the yellow pad. Placing the portal at the apex's x
    # (97px past the pad) covers both with a single portal.
    # [v6 failure] Lowering the ceiling to 200 for g2in crushed the yellow pad's
    # launch (vy~8.9) against the ceiling and killed instantly. KEEP THE
    # CORRIDOR HEIGHT THE SAME FOR EVERY UNIT and instead PLACE THE PORTAL
    # HIGHER (cy=200): p1 near its apex (175) and p2 on the ceiling (225) are
    # then both inside one box (157..243).
    two_in = (kind == "g2in")
    ceil = GROUND_TOP + 150.0                          # 240
    x_end = x + 40 * GRID
    xp = x + 20 * GRID
    xx = x - GRID
    while xx <= x_end:
        objs.append(obj(BLOCK, xx, ceil + GRID / 2))
        xx += GRID
    # The launch: normally 45px before (entering on the rising part of the arc),
    # while g2in enters at the apex
    objs.append(obj(PAD_YELLOW, xp - (97.0 if two_in else 45.0),
                    GROUND_TOP + 5.0))
    cy = GROUND_TOP + (110.0 if two_in else 55.0)      # 200 / 145
    # Re-apply mode/size at the head of every unit (to avoid carry-over from the
    # previous unit). PLACE THEM AT A HEIGHT THAT HITS BOTH PLAYERS (at floor
    # height they only hit p1).
    objs.append(obj(MODE_PORTAL[mode], x, cy))
    objs.append(obj(SIZE_NORM, x + 3 * GRID, cy))
    if kind in ("same", "both"):
        objs.append(obj(MODE_PORTAL[mode], xp, cy))
    if kind == "othr":
        objs.append(obj(P_UFO if mode != "ufo" else P_SHIP, xp, cy))
    # [both] Reproducing lv16 means OVERLAYING THEM AT THE SAME x (so the mode
    # portal and the gravity portal take effect on the same tick). Separating
    # them would only measure "whichever fired first".
    if kind in ("gnorm", "both", "g2in"):
        objs.append(obj(GRAV_NORM, xp, cy))
    if kind == "ginv":
        objs.append(obj(GRAV_FLIP, xp, cy))
    if kind == "size":
        objs.append(obj(SIZE_MINI, xp, cy))
    u = {"x0": x, "x1": x_end, "mode": mode, "kind": kind,
         "x_port": xp, "port_cy": cy}
    return objs, x_end, u


def build_dualport() -> str:
    u"""Rig for portals inside a dual. DUAL FROM THE START, VIA THE HEADER (kA8=1).

    With zero input p1 sticks to the floor and p2 to the ceiling, both sliding.
    A vertically stretched portal is then passed over them, and HOW THE vy AND
    upsideDown OF BOTH PLAYERS CHANGE is read from the dump's p2y/p2vy/p2up
    columns.
    """
    objs: list[str] = []
    x = 90.0
    # g2in (both players inside the same box = reproducing lv16@13,496) has a
    # ceiling 40px lower, so PUT IT FIRST. Placed later, the player stuck to the
    # ceiling ends up inside a solid at the boundary where the ceiling drops and
    # the whole rig dies (the v5 failure: A STEP CAN ONLY BE BUILT UPWARD).
    # [UNFINISHED - NEXT MOVE] g2in still has no working shape. The three
    # attempts and their results:
    #   lower the ceiling to 200 -> the yellow pad (vy~8.9) is crushed against
    #                               the ceiling, instant death
    #   put g2in last            -> at the boundary where the ceiling drops, the
    #                               upper player enters a solid and dies
    #   move only the portal to 200 -> the first one passes, but on the leading
    #                               unit THE PLAYER STRADDLES AND OVERSHOOTS THE
    #                               MODE PORTAL AT THE HEAD (mode stays cube)
    # What is needed is "both players inside an 86px box at once, with at least
    # one of them in flight". The next ideas are a weaker pad (pink), or putting
    # the lower player on a platform to close the distance.
    for mode in ("ship", "ufo"):
        for kind in ("same", "gnorm", "ginv", "both", "othr", "size"):
            u_objs, x_next, u = dualport_unit(x, kind, mode)
            objs += u_objs
            UNITS.append(u)
            x = x_next
    objs += floor_run(0, x + 600.0)
    return header(dual=True) + ";" + ";".join(objs) + ";"


def build_dropair() -> str:
    u"""Rig for STEPPING ON A BLACK ORB (drop ring) IN MID-AIR. The black-orb
    version of orbair.

    The corpus' lv21@7,217 shows a 1-tick hole: "on the tick AFTER exactly
    -15.000 (the terminal velocity) is assigned, GD emits -15.216 (= terminal +
    one gravity step), and the tick after that it is back to -15.000" (the only
    such case across all 22 gdref levels). On the ground-based orbs rig the
    player lands on the very next tick and it cannot be seen, so a shape where
    IT IS STEPPED ON IN MID-AIR WITH ROOM TO FALL BELOW is required.

    The black orb assigns its value ignoring the incoming vy (cube/ball/robot
    15.0 / spider 16.5 / ship/wave/swing 14.0 / UFO 11.2), so the entry point
    (off) is only there to confirm "the fire really was the orb". What is read
    is ONLY THE FIRE TICK AND THE 3 TICKS AFTER IT.
    """
    objs: list[str] = []
    x = 90.0
    # [v2] SWEEP THE INCOMING vy. v1's 4 modes x 2 points could only produce a
    # counterexample (ball) to "stepping on it while rising delays it by 1
    # tick". Sweeping off (the x offset from the top of the arc) finely moves
    # the entry from rising to apex to falling, so where in the incoming vy the
    # delay boundary sits can be read off. cube and ball are laid out side by
    # side (the delayed sample in the corpus is cube, the rig's counterexample
    # is ball).
    for mode in ("cube", "ball"):
        for off in (20.0, 30.0, 40.0, 50.0, 70.0, 90.0):
            x0 = x
            u, pl, x, tp, tr = orbair_unit(x, "black", mode, False, off)
            objs += u
            PLAN.extend(pl)
            UNITS.append({"x0": x0, "x1": x, "mode": mode, "orb": "black",
                          "mini": 0, "off": off,
                          "t_press": tp, "t_rel": tr})
    # The version that ARRIVES WITH THE BUTTON HELD (a test of whether lag is
    # the discriminator; see the note above).
    # Pressing early (starting in mid-air) fires immediately on the rising part
    # of the arc, so OFF BECOMES THE KNOB THAT SWEEPS THE INCOMING vy. This
    # brackets the delay boundary (for cube it does not appear at +1.337 but
    # does at +2.221).
    for mode in ("cube", "ball"):
        for off in (35.0, 45.0, 55.0, 60.0, 61.0, 62.0, 63.0, 64.0, 65.0,
                    75.0, 85.0):
            x0 = x
            u, pl, x, tp, tr = orbair_unit(x, "black", mode, False, off,
                                           early=True)
            objs += u
            PLAN.extend(pl)
            UNITS.append({"x0": x0, "x1": x, "mode": mode, "orb": "black",
                          "mini": 0, "off": off, "early": 1,
                          "t_press": tp, "t_rel": tr})
    for mode in ("cube", "ball", "robot", "spider"):
        for off in (60.0, 90.0, 120.0):
            x0 = x
            u, pl, x, tp, tr = orbair_unit(x, "black", mode, False, off,
                                           early=True)
            objs += u
            PLAN.extend(pl)
            UNITS.append({"x0": x0, "x1": x, "mode": mode, "orb": "black",
                          "mini": 0, "off": off, "early": 1,
                          "t_press": tp, "t_rel": tr})
    for mode in ("cube", "ball", "robot", "spider"):
        for mini in (False, True):
            for off in (60.0, 120.0):
                x0 = x
                u, pl, x, tp, tr = orbair_unit(x, "black", mode, mini, off)
                objs += u
                PLAN.extend(pl)
                UNITS.append({"x0": x0, "x1": x, "mode": mode, "orb": "black",
                              "mini": int(mini), "off": off,
                              "t_press": tp, "t_rel": tr})
    # Flight modes go last (how they enter the slope launch is mode-dependent,
    # and if one dies everything after it comes out EMPTY -- the rig's rule)
    for mode in ("ship", "ufo"):
        for off in (60.0, 120.0):
            x0 = x
            u, pl, x, tp, tr = orbair_unit(x, "black", mode, False, off)
            objs += u
            PLAN.extend(pl)
            UNITS.append({"x0": x0, "x1": x, "mode": mode, "orb": "black",
                          "mini": 0, "off": off, "t_press": tp, "t_rel": tr})
    return header() + ";" + ";".join(objs) + ";"


def orbedge_unit(x: float, kind: str, mode: str, mini: bool, delta: float,
                 dy: float = 0.0
                 ) -> tuple[list[str], list[tuple[int, int]], float, int, int]:
    """A unit for sweeping the fire boundary. PRESS FOR EXACTLY 1 TICK.

    What is wanted is "the x boundary at which the orb fires". A tick step is
    1.298px, so sweeping the press tick caps the resolution there -- instead,
    PIN THE PRESS TICK AND MOVE THE ORB 1px AT A TIME. The switch between fire
    and no-fire is the boundary, at a resolution of 1px (in fact at whatever
    precision the generator chooses).

    `delta` is the orb centre's offset from "the player's x at the press tick".
    The player's real x is read from the dump, so any prediction error is
    absorbed on the extraction side.
    """
    oid, _ = ORB[kind]
    objs: list[str] = []
    y = GROUND_TOP + 15.0
    objs.append(obj(MODE_PORTAL[mode], x, y))
    objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID, y))
    x_ref = x + 8 * GRID          # press for exactly 1 tick here
    x_orb = x_ref + delta
    objs.append(obj(oid, x_orb, y + dy))
    t = tick_at(x_ref)
    # A 1-tick press: if the boxes overlap on that tick it fires, otherwise the
    # player's own action happens (a jump, for a grounded cube). Which one
    # occurred is told by the value of vy.
    # x_orb is returned so the extraction side can compute the gap from "the
    # player's x at the press tick" FROM THE MEASUREMENT (using delta directly
    # as the gap adds tick_at's 1.3px rounding).
    return objs, [(t, 1), (t + 1, 0)], x_ref + 20 * GRID, t, x_orb


def build_orbedge() -> str:
    """Sweep rig for the orb fire boundary (PINK orb, cube normal/mini, -40..+40px).

    An orb is reported as 36x36, so with a plain AABB the boundary would be
    18+15 = 33px for normal and 18+9 = 27px for mini. ANY DEVIATION FROM THAT
    MEANS THE TEST IS NOT RECTANGULAR (a radius test, or an inner box), which
    bears directly on the body of the orbnear fixup family (already established
    to be a problem of the contact tick, not of the value).

    USE PINK, NOT YELLOW. A grounded cube's 1-tick press becomes a jump (11.180)
    when the orb is out of reach, which is the same value as the yellow orb and
    therefore indistinguishable. Pink is 8.050, so whether it fired can be read
    uniquely from the value of vy.
    """
    objs: list[str] = []
    x = 90.0
    for mini in (False, True):
        for d in range(-40, 41):
            x0 = x
            u, pl, x, tp, x_orb = orbedge_unit(x, "pink", "cube", mini,
                                               float(d))
            objs += u
            PLAN.extend(pl)
            UNITS.append({"x0": x0, "x1": x, "mode": "cube", "orb": "pink",
                          "mini": int(mini), "delta": d,
                          "t_press": tp, "t_rel": tp, "x_orb": x_orb})
    return header() + ";" + ";".join(objs) + ";"


def build_orbedge2() -> str:
    """A TWO-DIMENSIONAL sweep of the fire region (pink, normal cube). Settles the
    shape of the test.

    The 1-D sweep at dy=0 put the boundary at a clamped distance of 18.0-18.13,
    which does not lie on the same circle as the "clamped 22.996 fires" from
    lv12 noted in the model. So step dy and sweep dx finely to produce THE
    BOUNDARY CURVE dx_max(dy).

    Distinguishing the predictions:
      circle vs box (the model's current shape, radius R):
        dx_max = 15 + sqrt(R^2 - (dy-15)^2)
        -> once dy passes 15, dx_max shrinks and drops to 15 at dy = 15+R
      plain AABB: dx_max stays at 33 regardless of dy, and everything above
        |dy| > 33 fails to fire at once
    One run tells the two apart.
    """
    objs: list[str] = []
    x = 90.0
    for dy in (0.0, 10.0, 20.0, 25.0, 30.0, 32.0, 34.0):
        for d in range(10, 41, 2):
            x0 = x
            u, pl, x, tp, x_orb = orbedge_unit(x, "pink", "cube", False,
                                               float(d), dy)
            objs += u
            PLAN.extend(pl)
            UNITS.append({"x0": x0, "x1": x, "mode": "cube", "orb": "pink",
                          "mini": 0, "delta": d, "dy": dy,
                          "t_press": tp, "t_rel": tp, "x_orb": x_orb})
    return header() + ";" + ";".join(objs) + ";"


def build_orbedge3() -> str:
    """A MODE SWEEP of the fire boundary (uses the spider to settle how the
    half-width is treated).

    For a normal cube the boundary came out as 33 = orb half 18 + player half
    15, but it is not yet decided whether that is
      (a) orb + THE HALF-WIDTH OF THAT MODE  -> 31.5 for a spider (13.5)
      (b) orb + ALWAYS 15                    -> 33 even for a spider
    lv22's rotating section goes through spider/ball, so the AABB cannot be
    installed until this is settled (reach_check blocked it).

    A spider's own action is a teleport (vy +/-1.000), so it is distinguishable
    from a pink fire by value. Both normal and mini, to be safe.
    """
    objs: list[str] = []
    x = 90.0
    for mode, mini, own in (("spider", False, 1.000), ("spider", True, 1.000),
                            ("robot", False, 5.590), ("robot", True, 4.472)):
        for d in range(24, 37):
            x0 = x
            u, pl, x, tp, x_orb = orbedge_unit(x, "pink", mode, mini,
                                               float(d), 0.0)
            objs += u
            PLAN.extend(pl)
            UNITS.append({"x0": x0, "x1": x, "mode": mode, "orb": "pink",
                          "mini": int(mini), "delta": d, "own": own,
                          "t_press": tp, "t_rel": tp, "x_orb": x_orb})
    return header() + ";" + ";".join(objs) + ";"


def padedge_unit(x: float, rot: float, scale: float, mini: bool, dy: float,
                 kind: str = "yellow") -> tuple[list[str], float, dict]:
    """One pass under a single pad, for the OUTLINE of the pad's contact shape.

    lv20 uid 7030 (id 35, rot=29, scale 1.45) is activated by GD two ticks LATER
    than either candidate rectangle predicts: the circumscribed box GD itself
    prints as `orect`, and the true rotated plate (36.25 x 5.80). `ccl:` already
    ruled out the alternatives -- the pad is a candidate every tick with act,
    actP, claim and both group flags at 0 -- so what is left is the SHAPE used
    by the call, and a shape is read off an outline rather than off two points.

    The measured quantity is deliberately NOT "does it fire" and NOT "at which
    tick": it is **the player x at which the pad fires**, swept against the pad's
    height offset `dy`. A horizontal pass cannot separate the two rectangles by
    fire/no-fire, because sweeping x drags the player through the plate's whole
    extent and both boxes then have the same vertical reach. The x of FIRST
    contact does separate them:

      circumscribed box   x_fire = pad_cx - (bboxW/2 + pHalf), FLAT in dy
      true rotated plate  x_fire slides with dy, slope cot(29 deg) = 1.804
      rot = 0             the two coincide -> x_fire = pad_cx - (12.5*s + pHalf)

    so the signature is a slope, not a constant, and rot=0 is the arm that says
    whether the method itself is sound before any rot=29 number is believed.

    No presses anywhere: a pad fires on contact, so this rig has no plan at all
    and XMAP's tick/x drift cannot reach it.

    The player runs on the ground, so its centre is fixed and `dy` alone moves
    the pad. Negative dy would bury the pad in the ground, so the sweep takes the
    upper half of the outline; the slope is what discriminates, and it is
    symmetric. Firing launches the player +16, which is ~148 ticks and ~192 px of
    x -- the unit is wider than that so it lands well before the next pad.
    """
    oid, _ = PAD[kind]
    p_half = 9.0 if mini else 15.0
    y_run = GROUND_TOP + p_half          # the grounded centre
    objs: list[str] = []
    y0 = GROUND_TOP + 15.0
    objs.append(obj(MODE_PORTAL["cube"], x, y0))
    objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID, y0))
    pad_cx = x + 10 * GRID
    pad_cy = y_run + dy
    objs.append(obj(oid, pad_cx, pad_cy, rot=rot, scale=scale))
    # The three predictions, written into the unit table so the extraction side
    # compares against numbers fixed BEFORE the run.
    th = math.radians(rot)
    c, s = abs(math.cos(th)), abs(math.sin(th))
    w0, h0 = 25.0 * scale, 4.0 * scale
    bbox_w = w0 * c + h0 * s
    u = {"x0": x, "rot": rot, "scale": scale, "mini": int(mini), "dy": dy,
         "pad_cx": pad_cx, "pad_cy": pad_cy, "p_half": p_half, "y_run": y_run,
         "plate_w": w0, "plate_h": h0, "bbox_w": bbox_w,
         "bbox_h": w0 * s + h0 * c,
         # circumscribed-box model: flat in dy
         "pred_bbox_x": pad_cx - (bbox_w / 2.0 + p_half)}
    return objs, x + 24 * GRID, u


def build_padedge() -> str:
    """Outline sweep for the pad's contact shape (lv20 uid 7030's family).

    Three shapes x two sizes x a dy sweep:
      rot=0  scale=1.00  -- METHOD CHECK. The plate is the known 25x4, so both
                            models agree and x_fire must be pad_cx - (12.5+15)
                            exactly, flat in dy, with the boundary at dy=17.
                            If this arm does not come out flat and at the
                            predicted intercept, the instrument or the phase is
                            wrong and no rot=29 number means anything.
      rot=0  scale=1.45  -- separates SCALE from ROTATION (lv20's pads are both)
      rot=29 scale=1.45  -- lv20's actual plate

    dy stops past each shape's own predicted reach so the sweep contains the
    boundary as well as the slope.
    """
    objs: list[str] = []
    x = 90.0
    for mini in (False, True):
        # -29 is not a duplicate of +29: the outline's SIGN is what says which
        # way the plate leans, and the +29 sweep alone cannot show it (every dy
        # in it is positive, so both leanings put first contact on the same
        # side). lv20's player falls VERTICALLY past the plate, where the lean
        # decides which face it reaches first -- and the true OBB still overlaps
        # two ticks before GD activates there, so the sign is exactly the term
        # that is missing. If the slope flips with the sign of rot, GD's
        # rotation runs the way this generator's math assumes and lv20 can be
        # recomputed against it; if it does not, the contact shape is not simply
        # the rotated plate.
        for rot, scale, dy_max in ((0.0, 1.0, 20.0), (0.0, 1.45, 22.0),
                                   (29.0, 1.45, 30.0), (-29.0, 1.45, 30.0)):
            dy = 0.0
            while dy <= dy_max:
                u, x, meta = padedge_unit(x, rot, scale, mini, dy)
                objs += u
                UNITS.append(meta)
                dy += 2.0
    return header() + ";" + ";".join(objs) + ";"


def padfall_unit(x: float, off: float, mini: bool, jump: bool = True
                 ) -> tuple[list[str], list[tuple[int, int]], float, dict]:
    """One pass at a pad while DESCENDING, to weigh the approach direction.

    The horizontal sweeps (padedge, padedge13) put the activation delay in [0,1)
    ticks over 39 samples at two speeds -- the pad fires on the first tick of
    geometric contact. lv20's pad fires two ticks late. The difference left
    between the two cases is that lv20's player is falling, and the horizontal
    rig is STRUCTURALLY BLIND to that: with the player running its y never
    moves, so a contact test reading a stale y would give identical results in
    every unit of both sweeps. This rig makes y move.

    The plate is rot=0, whose shape is already settled three ways, so any
    residual here is delay and not geometry.

    Placement without measuring the arc: a CURTAIN of identical pads at one x,
    the trick orbair_unit uses for the same reason. Exactly one of them fires --
    `padact:` names it and reports its centre -- and WHICH one fires is set by
    where the arc is at that x, so sweeping the curtain's x sweeps the descent
    speed without predicting the trajectory. Spacing is 2 * (pad half 2 + player
    half): the reach regions then tile with neither overlap (two pads in range
    at once, which would make "which fired" ambiguous) nor gap (a hole the arc
    slips through un-caught). IT DEPENDS ON THE PLAYER'S HALF -- 34 normal, 22
    mini -- and a curtain built at 34 for a mini body leaves a 12 px hole every
    34 px, which is not a wrong measurement but a partly blind one.

    The delay is read in ticks without any per-tick dump, because `padact:`
    carries the fire `vy`:
        predicted fire y = fired pad's cy + (2 + pHalf)      <- descending
        delay [ticks]    = (predicted - measured y) / (|vy| * dyPerVy)
    with dyPerVy calibrated from the run's own rows. k=0 means the pad fires on
    the first overlapping tick here too, which would put lv20's two ticks down
    to something level-specific (its teleport, its gravity portal, its speed
    1.3) rather than to the direction of approach.

    `jump=False` is the control arm: no press, so the player runs past at
    constant y and must reproduce the horizontal rigs' k=0.
    """
    oid, _ = PAD["yellow"]
    p_half = 9.0 if mini else 15.0
    objs: list[str] = []
    y0 = GROUND_TOP + 15.0
    objs.append(obj(MODE_PORTAL["cube"], x, y0))
    objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID, y0))
    x_ref = x + 8 * GRID
    plan: list[tuple[int, int]] = []
    t = tick_at(x_ref)
    if jump:
        # One tick of press on flat ground = the cube's own 11.180 jump. The
        # press tick is approximate (tick_at drifts a few px over a rig this
        # long) but the player is grounded for hundreds of ticks here, so the
        # jump lands wherever it lands and the curtain catches the arc anyway.
        plan = [(t, 1), (t + 1, 0)]
    x_curtain = x_ref + off
    spacing = 2.0 * (2.0 + p_half)      # 34 normal, 22 mini
    cy = GROUND_TOP + p_half
    n_pads = 0
    while cy <= GROUND_TOP + p_half + 320.0:
        objs.append(obj(oid, x_curtain, cy))
        n_pads += 1
        cy += spacing
    meta = {"x0": x, "off": off, "mini": int(mini), "jump": int(jump),
            "p_half": p_half, "x_curtain": x_curtain, "t_press": t if jump else -1,
            "pad_w": 25.0, "pad_h": 4.0,
            "spacing": spacing, "n_pads": n_pads,
            # Coverage is gapless by construction: the curtain's step equals the
            # height of one pad's reach, so every y in the swept band belongs to
            # exactly one pad. A unit that does not fire is therefore evidence
            # about the ARC (it left the band), never about coverage.
            "coverage": "gapless",
            # the pre-registered rule: contact on the first tick where the boxes
            # overlap. `pad_cy` is filled in from the run (which pad fired).
            "pred_fire_y_offset": 2.0 + p_half,
            "pred_x_reach": 12.5 + p_half}
    return objs, plan, x_ref + 30 * GRID, meta


def build_padfall() -> str:
    """Descending-approach rig: is the pad's activation delay still 0 ticks when
    the player's y is moving?

    Sweeps the curtain's x past the apex so the contact walks down the descent,
    which is what varies the fall speed. Two control arms: `jump=False` (y
    constant -- must reproduce the horizontal rigs) and mini (a different player
    half, which the horizontal sweep showed enters only through the reach).
    """
    objs: list[str] = []
    x = 90.0
    for mini in (False, True):
        u, pl, x, meta = padfall_unit(x, 0.0, mini, jump=False)
        objs += u
        PLAN.extend(pl)
        UNITS.append(meta)
        for off in range(70, 210, 10):
            u, pl, x, meta = padfall_unit(x, float(off), mini, jump=True)
            objs += u
            PLAN.extend(pl)
            UNITS.append(meta)
    return header() + ";" + ";".join(objs) + ";"


def padnorm_unit(x: float, rot: float, mini: bool, off: float,
                 y_plate: float = 150.0
                 ) -> tuple[list[str], list[tuple[int, int]], float, dict]:
    """One plate, met while falling, to read the pad gate's THICKNESS threshold.

    padedge swept the plate's long axis and is blind to its thin direction by
    construction; lv20's player falls, which is that direction, and the two
    ticks nobody could explain turn out to live there. Measured at lv20 uid
    7030: GD refuses at a normal-axis overlap of 4.197 and fires at 6.887, i.e.
    the threshold on |d.v| is bracketed by [16.404, 19.094). Three candidates
    sit inside and one witness cannot separate them:

        15 * sec(theta)                          17.151 at 29 deg
        player half + plate half-thickness       17.900, theta-independent
        15*(|cos|+|sin|) - plate half-thickness   17.491 at 29 deg

    Sweeping THETA separates them, since only the middle one is flat. The
    corpus cannot: all six of lv20's rotated pads are at 29 degrees.

    ONE plate per unit, not a curtain. padfall used a column -- the trick
    orbair_unit uses for orbs -- and it failed, because an orb needs a press
    while a pad fires on contact: the first plate's +16 launched the player into
    the next one and the column became a ladder, 149 activations from 30 units.
    With a single plate that cannot happen.

    theta is kept off the quarter turns so the object takes the `oriented`
    branch (level_loader.hpp:811). A theta=0 plate is a different branch AND,
    at the geometry padfall happened to produce, does not measure the threshold
    at all -- the player ran at the plate's own centre height, so the normal
    overlap sat at its maximum for the whole pass and bounds the threshold only
    from above. Those points are not controls for this.
    """
    oid, _ = PAD["yellow"]
    p_half = 9.0 if mini else 15.0
    objs: list[str] = []
    y0 = GROUND_TOP + 15.0
    objs.append(obj(MODE_PORTAL["cube"], x, y0))
    objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID, y0))
    x_ref = x + 8 * GRID
    t = tick_at(x_ref)
    objs.append(obj(oid, x_ref + off, y_plate, rot=rot, scale=1.45))
    th = math.radians(rot)
    c, s = abs(math.cos(th)), abs(math.sin(th))
    sec = 1.0 / math.cos(th)
    plate_half_t = 4.0 * 1.45 / 2.0
    meta = {"x0": x, "rot": rot, "mini": int(mini), "off": off,
            "p_half": p_half, "plate_cx": x_ref + off, "plate_cy": y_plate,
            "plate_half_thick": plate_half_t, "t_press": t,
            # written BEFORE the run: what each candidate predicts for the
            # normal-axis threshold |d.v| at the firing tick
            "cand_sec": p_half * sec,
            "cand_sum": p_half + plate_half_t,
            "cand_proj": p_half * (c + s) - plate_half_t}
    return objs, [(t, 1), (t + 1, 0)], x_ref + 30 * GRID, meta


def build_padnorm() -> str:
    """Thickness-threshold rig: three rotations x two sizes x three drop points.

    The three drop points are insurance, not an axis -- the jump's apex is only
    ~67 px above the run line, so a plate at y=150 is met on the way down near
    off=105, and neighbouring offsets cover any error in that estimate. Each is
    its own unit with its own single plate, so a wasted one costs nothing and
    cannot interfere with the others.
    """
    objs: list[str] = []
    x = 90.0
    # THE SLOW ARM IS THE ONE THAT DECIDES. A threshold is bracketed between the
    # last tick that did not fire and the first that did, so the bracket's width
    # is one tick of approach -- and at theta=29 two candidates sit 0.75 px apart
    # (17.151 vs 17.900). A body falling at ~2 px/tick cannot separate them.
    # Putting the plate just under the jump's apex makes the player arrive at
    # ~0.2-0.3 px/tick, bracketing to well under half a pixel. The fast arm is a
    # control: at 15 and 45 degrees those two candidates are 2.4 and 3.3 px
    # apart, so it should split them alone, and the arms then check each other.
    # Apex height differs by size, so each size gets its own plate heights.
    GEOM = {False: {"fast": (150.0, (105.0, 115.0, 125.0)),
                    "slow": (168.0, (60.0, 67.0, 74.0))},
            True: {"fast": (130.0, (85.0, 95.0, 105.0)),
                   "slow": (145.0, (48.0, 55.0, 62.0))}}
    for mini in (False, True):
        for rot in (15.0, 29.0, 45.0):
            for arm in ("fast", "slow"):
                y_plate, offs = GEOM[mini][arm]
                for off in offs:
                    u, pl, x, meta = padnorm_unit(x, rot, mini, off, y_plate)
                    meta["arm"] = arm
                    objs += u
                    PLAN.extend(pl)
                    UNITS.append(meta)
    return header() + ";" + ";".join(objs) + ";"


def build_padedge13() -> str:
    """The same outline at speed 1.3, which is the one thing lv20 has and the
    first rig did not.

    The horizontal sweep put the activation delay in [0,1) ticks over 30 rot=0
    samples, so the pad fires on the first tick of geometric contact -- but every
    one of those units ran at 0.9, while `padtrace` reports spd=1.3 on the lv20
    pad that fires two ticks late. Speed is therefore an uncontrolled difference
    between the arm that shows no delay and the case that shows one, and it is
    cheap to control: the x step goes 1.298 -> 1.949, so a delay measured in
    TICKS stays put while one measured in PIXELS shrinks by a third.

    Kept to the normal-size arms: mini adds a size axis that the 0.9 run already
    settled (the two reaches differ by exactly 15-9).
    """
    objs: list[str] = []
    x = 90.0
    for rot, scale, dy_max in ((0.0, 1.0, 20.0), (29.0, 1.45, 30.0),
                               (-29.0, 1.45, 30.0)):
        dy = 0.0
        while dy <= dy_max:
            u, x, meta = padedge_unit(x, rot, scale, False, dy)
            objs += u
            meta["speed"] = 3
            UNITS.append(meta)
            dy += 2.0
    return header(speed=3) + ";" + ";".join(objs) + ";"


def crush_unit(x: float, gap: float, mode: str, mini: bool) -> tuple[list[str], float, dict]:
    u"""One crush corridor: a floor pillar (top 210) + a ceiling pillar
    (underside 210+gap).

    The player runs on the real ground (world 90), and the pillars hang high
    enough that it can pass underneath the corridor. An injection (inject y=225)
    seats it on the floor, so we can measure what GD does when the gap is
    smaller than the player's height (crush / push out / pass through).
    The rig is static, so no Move trigger is needed.
    """
    objs: list[str] = []
    # Always place the portals (so the mode/size of the previous unit is not
    # inherited)
    objs.append(obj(MODE_PORTAL[mode], x - 4 * GRID, GROUND_TOP + 15.0))
    objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x - 2 * GRID,
                    GROUND_TOP + 15.0))
    floor_top = GROUND_TOP + 120.0          # 210: well above the running line (head 120)
    apr = 4                                  # 4 cells of run-up floor (no ceiling)
    n = 4                                    # corridor length 4 cells = 120px
    for k in range(apr + n):
        cx = x + GRID / 2 + k * GRID
        objs.append(obj(BLOCK, cx, floor_top - GRID / 2))          # floor pillar
        if k >= apr:
            objs.append(obj(BLOCK, cx, floor_top + gap + GRID / 2))  # ceiling pillar
    u = {"x0": x, "x1": x + (apr + n) * GRID, "mode": mode, "mini": int(mini),
         "gap": gap, "floor_top": floor_top, "x_gapstart": x + apr * GRID,
         "inject_x": x + 1.5 * GRID,          # inject onto the run-up floor -> walks in
         "inject_y": floor_top + (9.0 if mini else 15.0)}
    return objs, x + (apr + n) * GRID, u


def build_crush() -> str:
    u"""Rig for measuring THE CONDITIONS FOR A CRUSH (squeeze) (2026-08-22).

    The model does not have lv22's x=20,130 dead end (a ~20px gap between floor
    1,179 and ceiling 1,200, an obj=NULL kill), so it currently needs a
    dedicated deadband. Turning it into a rule requires measuring the kill
    threshold of "gap vs height" and, when the player survives, the resolution
    (which way it is ejected). Every unit is independent (run with one injection
    per session).
    """
    UNITS.clear()
    PLAN.clear()
    # First sweep (gap 31..21, all survived) -> the death is not the outer box
    # but THE INNER BOX. In the second sweep, cube survives at 20.0 and dies at
    # 19.5, matching "dies on contact" with an inner-box half-height of 4.5.
    # This pass tightens the boundary and covers the other modes.
    parts: list[str] = []
    x = 600.0
    for g in [19.9, 19.75, 19.6, 19.5]:
        objs, x1, u = crush_unit(x, g, "cube", False)
        parts += objs
        UNITS.append(u)
        x = x1 + 10 * GRID
    for g in [20.5, 20.0, 19.75, 19.5]:
        objs, x1, u = crush_unit(x, g, "robot", False)
        parts += objs
        UNITS.append(u)
        x = x1 + 10 * GRID
    for g in [20.5, 20.0, 19.5, 19.0]:
        objs, x1, u = crush_unit(x, g, "ball", False)
        parts += objs
        UNITS.append(u)
        x = x1 + 10 * GRID
    # Mini cube: 12.5 died = the inner box is NOT scaled by 0.6.
    # If the inner-box half-height stays 4.5, death happens at gap <= 9+4.5 = 13.5
    for g in [14.5, 14.0, 13.6, 13.5]:
        objs, x1, u = crush_unit(x, g, "cube", True)
        parts += objs
        UNITS.append(u)
        x = x1 + 10 * GRID
    return header() + ";" + ";".join(parts) + ";"


SPIKE30, SPIKE60 = 366, 367   # the two shz=1 (spiked) slope ids
# ...and their PLAIN counterparts, the same two shapes with shz=0. 309 is lv16's
# own plain twin (uid 3782/3783, co-located with the spiked 366 pair) and 484 is
# the 60x30 the corpus uses; both are already on calib_slopespike's flag survey.
PLAIN30, PLAIN60 = 309, 484
# ...and the pair lv21 is built out of. 1338/1339 are a DIFFERENT plain family:
# 202 of them carry that level's whole wave section (x 18915..26415) and NO other
# level in the corpus has a single one. The plain rule was measured on 309 and
# corroborated on 309/665, so applying it to 1338/1339 is a generalisation across
# ids, and lv21 is exactly where that generalisation is cashed.
SLOPE1338, SLOPE1339 = 1338, 1339

# Base extent per id. Taken from the corpus dump, not assumed: 1339 is 30 WIDE by
# 60 TALL (|m| = 2), which is the transpose of 367, so the two ids do not share a
# gradient and the pair still separates vertical from perpendicular offset.
SLOPE_DIMS = {SPIKE30: (30.0, 30.0), SPIKE60: (60.0, 30.0),
              PLAIN30: (30.0, 30.0), PLAIN60: (60.0, 30.0),
              SLOPE1338: (30.0, 30.0), SLOPE1339: (30.0, 60.0)}


def slopespike_unit(x: float, oid: int, rot: float, fx: bool,
                    fy: bool) -> tuple[list[str], float, dict]:
    u"""ONE LONE SPIKED RAMP, hanging clear of everything else.

    Nothing else is placed: no plain twin under it, no solid butted against it,
    no floor of its own. That is the whole point. Every measurement of a spiked
    ramp's lethal region so far has come from the corpus, where lv18 stacks 116
    of its 154 spiked ramps on a plain one at the same (cx,cy) -- so "GD killed
    the player inside a ramp" and "GD resolved the solid twin" are the same
    observation there, and the five-point probe the kill test still quotes was
    taken on such a pair (uid 2424 shz=0 / uid 2414 shz=1, both sdir=5).

    The box centre sits 150 px above the ground, which leaves room to inject the
    player both under the line and over it. The player never reaches it on its
    own: a cube running the floor tops out at 120, so every unit survives to be
    probed in one session and the sweep decides which one it is looking at by
    injecting x.

    WHICH sdir each (rot, flip) produces is NOT assumed here -- the rig reports
    it, exactly as calib_slopeflags does. Read sdir/sup/sy0/sy1 back out of the
    objrects dump and label the units from that.
    """
    w, h = SLOPE_DIMS[oid]
    # The SLOT -- how much x this unit consumes, and therefore where every LATER
    # unit sits -- is kept at the number the first version of this rig used, so
    # adding ids cannot move a unit that has already been measured. It is not the
    # shape's width: 309 is a 30x30 and has always been given a 60-wide slot.
    # That is why `w` used to be recorded as 60 for it, which was simply wrong --
    # the 2026-09-15 plain measurement read the real box (4215..4245) out of the
    # rig's objrects dump, as this unit's docstring tells you to. w/h now report
    # the shape and the slot does the spacing, so the label agrees with the dump.
    slot = 30.0 if oid == SPIKE30 else 60.0
    cx = x + slot / 2.0
    cy = GROUND_TOP + 150.0
    objs = [obj(oid, cx, cy, rot=rot, flip_x=fx, flip_y=fy)]
    u = {"x0": x, "oid": oid, "rot": rot, "flip_x": int(fx), "flip_y": int(fy),
         "cx": cx, "cy": cy, "w": w, "h": h,
         "sx0": cx - w / 2.0, "sx1": cx + w / 2.0,
         # three sample columns: a quarter in from each end and the middle. The
         # ends are where a horizontal box edge and a line-parallel one differ
         # most -- the middle is where the two forms agree and lv16 looked fine.
         "probe_x": [round(cx - w / 4.0, 3), round(cx, 3),
                     round(cx + w / 4.0, 3)],
         # the line spans cy-15 .. cy+15, so a y sweep of +-40 around the centre
         # covers both the lethal band and clear air on both sides
         "probe_y": [cy - 40.0, cy + 40.0]}
    return objs, x + slot + 6 * GRID, u


HAZROT_ROTS = (0.0, 8.0, 15.0, 30.0, 45.0, 63.0, 90.0)


def hazrot_unit(x: float, oid: int, rot: float) -> tuple[list[str], float, dict]:
    u"""ONE TURNED HAZARD, alone, 150 px above the floor.

    The game's hazard loop is the player's rect against the object's rect and then,
    only for an oriented object, the two turned boxes (the disassembly is quoted at
    hazardHit). The model's second test uses the RECORDED corners, and the note at
    the wave's hazard branch already says those are not the game's shape either --
    measured once, on lv20's spike id667 at rot -63, where the recorded box fitted
    the three probed points only at a half of 2.96..2.98. Nothing has swept a turned
    hazard on a rig, so the shape is a guess wherever the corpus has no probe.

    One id per file and one rotation per unit, nothing else within 150 px, so a
    column sweep reads that rotation alone. The unit's slot is wide enough (10 cells)
    that the player's own box cannot reach the neighbours.
    """
    cx = x + 5 * GRID
    cy = GROUND_TOP + 150.0
    objs = [obj(oid, cx, cy, rot=rot)]
    u = {"x0": x, "oid": oid, "rot": rot, "cx": cx, "cy": cy,
         # three columns: through the centre and a cell either side, which is where
         # a turned box and its bound differ most
         "probe_x": [round(cx - GRID, 3), round(cx, 3), round(cx + GRID, 3)],
         "probe_y": [cy - 40.0, cy + 40.0]}
    return objs, x + 10 * GRID, u


def build_hazrot(mode: str = "wave", oid: int = 368, mini: bool = False) -> str:
    u"""Rig for THE SHAPE OF A TURNED HAZARD (2026-09-18).

    lv19 t=7,131 is the case that needs it: the game kills a wave 0.08 px outside the
    model's second test, and simply widening the first test costs 43 iterations
    elsewhere -- so the second test's shape has to be measured rather than adjusted.

    The verdict comes from py/hitbox_sweep.py (inject x and y, read life or death),
    one unit per rotation, and the terminal spike past the last unit is load-bearing:
    serve mode parks at the head of the attempt AFTER A DEATH, so a rig the player
    survives ends the session and every later sweep fails with "the rerun never
    landed".
    """
    UNITS.clear()
    PLAN.clear()
    objs: list[str] = []
    x = 600.0
    for rot in HAZROT_ROTS:
        part, x, u = hazrot_unit(x, oid, rot)
        objs += part
        u["mode"] = mode
        u["mini"] = int(mini)
        UNITS.append(u)
    objs.append(obj(SPIKE, x + 4 * GRID, GROUND_TOP + 6.0))
    objs += floor_run(0, x + 300.0)
    return header(start_mode=mode, mini=mini) + ";" + ";".join(objs) + ";"


def build_slopespike_mode(mode: str, mini: bool = False,
                          flip_gravity: bool = False) -> str:
    u"""Rig for THE LETHAL BOUNDARY OF A SPIKED RAMP (2026-09-15).

    Two open questions, and the second is why this rig has to exist rather than
    another corpus reading:

      1. The boundary runs PARALLEL to the line, not along the box's floor. The
         lv18 probe says so (5 points, offset 9.54 px) and the model still uses
         the box edge on the floor branch.
      2. **Vertical offset or PERPENDICULAR offset.** For |m| = 1 the two are the
         same statement up to sqrt(2) -- 9.54 vertical = 17.35 along the normal --
         and EVERY case measured so far has |m| = 1, so nothing in the corpus can
         separate them. id 366 is the 30x30 (|m| = 1) and id 367 the 60x30
         (|m| = 0.5), so the pair separates them here.

    48 units per mode: six ids (two spiked, four plain) x four rotations x two
    flips, appended in id order so earlier measurements keep their x. One mode
    per file,
    as the sawcal rigs do, so the mode is the header's and nothing has to pass a
    portal to get it.

    The verdict comes from py/hitbox_sweep.py (inject x and y, read life/death),
    NOT from loading alone -- that is the difference from calib_slopeflags,
    which is a geometry survey in which nothing is ridden.
    """
    UNITS.clear()
    PLAN.clear()
    objs: list[str] = []
    x = 600.0
    for oid in (SPIKE30, SPIKE60):
        for rot in (0.0, 90.0, 180.0, 270.0):
            for fx, fy in ((False, False), (False, True)):
                part, x, u = slopespike_unit(x, oid, rot, fx, fy)
                objs += part
                u["mode"] = mode
                u["mini"] = int(mini)
                UNITS.append(u)
    # ...AND THE PLAIN TWINS OF THE SAME TWO SHAPES. The model kills on a spiked
    # ramp and never on a plain one (`if (!sp->slopeHazard) continue;`), but GD's
    # gate reads `(m_slopeIsHazard == 0 && (A || B)) || player+0xc44`, so a plain
    # ramp kills whenever A||B is false -- and +0xc44 is a field nothing ever
    # sets. The corpus cannot settle it (the 7-point probe at lv16's (6708,293)
    # only says A||B was true there), so the rig has to.
    # APPENDED, not interleaved: x advances monotonically through the loops, so
    # the sixteen spiked units keep the positions everything measured so far was
    # taken at.
    for oid in (PLAIN30, PLAIN60):
        for rot in (0.0, 90.0, 180.0, 270.0):
            for fx, fy in ((False, False), (False, True)):
                part, x, u = slopespike_unit(x, oid, rot, fx, fy)
                objs += part
                u["mode"] = mode
                u["mini"] = int(mini)
                UNITS.append(u)
    # ...AND lv21's OWN PLAIN FAMILY. The measured rule ("a plain ramp kills a
    # wave", d = 4.985) was taken on 309 and corroborated on 309/665 in the
    # corpus, and then applied to every shz=0 slope. lv21 is the only level that
    # owns 1338/1339 -- 202 of them, spanning its whole wave section -- so it is
    # the only level where that generalisation is cashed, and it cost 36
    # iterations there the first time the rule shipped. Whether that cost is a
    # correction or an over-kill is a question about THESE two ids, and nothing
    # measured so far has touched them.
    for oid in (SLOPE1338, SLOPE1339):
        for rot in (0.0, 90.0, 180.0, 270.0):
            for fx, fy in ((False, False), (False, True)):
                part, x, u = slopespike_unit(x, oid, rot, fx, fy)
                objs += part
                u["mode"] = mode
                u["mini"] = int(mini)
                UNITS.append(u)
    # A TERMINAL SPIKE, past every unit, and it is load-bearing rather than
    # scenery. Serve mode parks at the head of the next attempt AFTER A DEATH
    # (config.hpp: servemode) and that is where it reads cmd.txt -- so a rig the
    # player SURVIVES runs to the end, the session is over, and every sweep
    # afterwards fails with "the rerun never landed". Measured that way once.
    # It sits at the far right so the no-input player dies only after passing
    # all sixteen units, which keeps the level uncompletable without putting a
    # hazard anywhere a probe might look. ("all sixteen" when this was written;
    # it is all forty-eight now, and the argument is the same.)
    objs.append(obj(SPIKE, x + 4 * GRID, GROUND_TOP + 6.0))
    objs += floor_run(0, x + 300.0)
    # --- the FLIPPED-GRAVITY twin (2026-09-17). A gravity portal on the floor
    # before the first unit, and nothing else changes: every unit keeps its x, so
    # a column measured on the plain rig and on this one differ in the player's
    # gravity alone. lv17's spiked 367 (uid 8727, rot 180, sdir 3) measured a
    # sloped edge 0.8-1.0 px thicker than this rig's identical unit under a normal
    # wave, with the flipped wave also riding a plain twin -- this rig removes
    # the twin and keeps the flip.
    # A flipped player rises away from the floor spike above, so this rig also
    # needs a spike HANGING where it rides, or the session never ends in a death
    # and serve mode never parks (the first sweep of this rig failed exactly that
    # way). Where it rides was measured, not assumed: the flipped wave climbs to
    # y=380 and slides there -- the flying band's own ceiling (band 90..390) --
    # so a ceiling laid higher is never reached (the second attempt put one at
    # 490 and the level completed with no death). The spike hangs from 390, clear
    # of every unit's probe band (units at GROUND_TOP+150, probes +-40).
    if flip_gravity:
        objs.append(obj(GRAV_FLIP, 300.0, GROUND_TOP + 15.0))
        objs.append(obj(SPIKE, x + 4 * GRID, 390.0 - 6.0, rot=180.0))
    return header(start_mode=mode, mini=mini) + ";" + ";".join(objs) + ";"


def build_slopespike_mirror(mode: str, mini: bool = False) -> str:
    u"""Rig for A SPIKED RAMP MIRRORED IN x (2026-09-29).

    Every unit of the slopespike rigs has flip_x 0, so the only descending ramps
    they sweep are the ROTATED ones (366 rot 90 reports dir 4). A ramp mirrored in
    x -- dir 2 on a floor, the form a custom level's ridge uses -- was never on a
    rig. On such a ridge the game kills a full ship 0.98 px above the cap the
    rotated unit measures (objMaxY + ph - 1, 269 there, both ends and both slopes),
    and the ship's attitude does not move that cap, so the mirrored unit itself is
    the next thing to measure.

    The same unit function and spacing as build_slopespike_mode, in its own file
    so no unit measured there moves: the two spiked ids at rot 0, mirrored in x,
    upright and flipped in y.
    """
    UNITS.clear()
    PLAN.clear()
    objs: list[str] = []
    x = 600.0
    for oid in (SPIKE30, SPIKE60):
        for fx, fy in ((True, False), (True, True)):
            part, x, u = slopespike_unit(x, oid, 0.0, fx, fy)
            objs += part
            u["mode"] = mode
            u["mini"] = int(mini)
            UNITS.append(u)
    # the terminal spike and the floor, for the reason build_slopespike_mode gives
    objs.append(obj(SPIKE, x + 4 * GRID, GROUND_TOP + 6.0))
    objs += floor_run(0, x + 300.0)
    return header(start_mode=mode, mini=mini) + ";" + ";".join(objs) + ";"


TWIN_SPIKED60, TWIN_PLAIN60 = 364, 493   # a custom level's stacked 60x30 pair


def build_slopespike_twin(mode: str, mini: bool = False) -> str:
    u"""Rig for A SPIKED RAMP STACKED ON ITS PLAIN TWIN (2026-09-29).

    The slopespike rigs hang each spiked ramp alone, on purpose (see
    slopespike_unit), and on them the model's outline for a ship holds to 0.05 px
    -- the high-end cap, the mirrored unit and a ship turned by 33 degrees all
    included. Where a custom level stacks the spiked 60x30 on a plain 60x30 at the
    same place, the game kills a ship 0.5 to 1 px outside that outline, under a
    ceiling unit and at a floor ridge alike. So the twin is the variable left.

    Four units, each the pair at one (cx, cy): the ceiling unit (rot 180), the
    floor unit rising, the floor unit mirrored in x (falling), and the last two
    side by side as a ridge.
    """
    UNITS.clear()
    PLAN.clear()
    objs: list[str] = []
    cy = GROUND_TOP + 150.0
    x = 600.0
    for label, parts in (("ceil", ((180.0, False),)),
                         ("rise", ((0.0, False),)),
                         ("fall", ((0.0, True),)),
                         ("ridge", ((0.0, False), (0.0, True)))):
        x0 = x
        for i, (rot, fx) in enumerate(parts):
            cx = x + 30.0 + 60.0 * i
            objs.append(obj(TWIN_SPIKED60, cx, cy, rot=rot, flip_x=fx))
            objs.append(obj(TWIN_PLAIN60, cx, cy, rot=rot, flip_x=fx))
        w = 60.0 * len(parts)
        UNITS.append({"x0": x0, "label": label, "oids": [TWIN_SPIKED60, TWIN_PLAIN60],
                      "cy": cy, "sx0": x0, "sx1": x0 + w, "mode": mode, "mini": int(mini)})
        x = x0 + w + 6 * GRID
    objs.append(obj(SPIKE, x + 4 * GRID, GROUND_TOP + 6.0))
    objs += floor_run(0, x + 300.0)
    return header(start_mode=mode, mini=mini) + ";" + ";".join(objs) + ";"


def portalpress_unit(x: float, frm: str, to: str, offset: int,
                     cell: str, air: bool = False
                     ) -> tuple[list[str], float, dict]:
    u"""ONE mode portal, with a ONE-TICK press placed relative to its tick.

    Nothing else is in the unit: flat ground, no ramp, no size portal, no
    hazard. That is the point. lv21's t=18,619 -- where this question came
    from -- has a ramp exit, a mode portal and a SIZE portal all on the one
    tick, and three explanations fit the one number.
    """
    objs: list[str] = [obj(MODE_PORTAL[frm], x + 2 * GRID, GROUND_TOP + 15.0)]
    # The run-up is long enough for a flight mode to settle onto the floor
    # (a UFO with no input rests there, onGround 1, vy 0) before the test.
    x_test = x + 22 * GRID
    objs.append(obj(MODE_PORTAL[to], x_test, GROUND_TOP + 15.0))
    # THE PORTAL'S TICK IS MEASURED, never `tick_at(x_test)`. The first build
    # of this rig used the latter and put all twenty-one presses ~25 ticks past
    # the portal, so the sweep asked one question seven times per pair. Pass 1
    # (no --xmap) is only used to produce the dump this reads.
    pt = mode_change_near(x_test)
    base = pt if pt >= 0 else tick_at(x_test)
    t = base + offset
    # AIR CELLS. Every cell of the first build met the portal standing on the
    # floor, so the re-issued impulse always had the new mode's precondition
    # satisfied and the rig could not see whether the model CHECKS it. It does
    # not: step.hpp's `-> cube/robot` re-issue writes the jump without asking
    # whether the player is grounded, and lv21 t=18,619 is a cube arriving at a
    # portal in mid-air (it had just left a ramp) where GD does nothing and the
    # model leaves with 9.136 = 11.420 * 8.944/11.180, its own mini cube jump.
    # A setup press twelve ticks earlier puts the player in the air; the portal
    # box is 86 tall (y 62..148), so a jump from the floor is still inside it.
    # THE CELL IS ONLY VALID IF IT IS ACTUALLY AIRBORNE -- the reader has to
    # check onGround at the portal tick and throw the cell away otherwise.
    if air:
        # 25, not 12: at 12 the setup press lands on the -12 CONTROL's own tick,
        # so that cell stops being an independent control and just re-reads the
        # setup. (It did, in the first air pass -- the cube->ufo -12 control came
        # back with a grounded cube's 11.180.) A cube's jump takes about a
        # hundred ticks to land, so at -25 the player is still airborne at the
        # portal and both controls keep their own press.
        PLAN.append((base - 25, 1))
        PLAN.append((base - 24, 0))
    # ONE tick, not the three rampjump uses: a press that is NOT consumed has
    # to be unambiguous, and a held button lets a cube re-jump on landing.
    PLAN.append((t, 1))
    PLAN.append((t + 1, 0))
    u = {"x0": x, "from": frm, "to": to, "offset": offset, "cell": cell,
         "x_test": x_test, "press_t": t, "portal_t": pt, "air": int(air),
         "portal_t_measured": pt >= 0}
    # Settle: whatever the press did to y has to be over before the next unit.
    # 40 grid cells = 1,200px = ~925 ticks, of which the run-up takes 22 and the
    # rest is settling -- a cube's jump lands in about a hundred ticks, so this
    # is still generous. It used to be 62, and THE RIG HAS A TICK BUDGET: the
    # mod forces any attempt over at g_tick > 40000 (hooks_gamelayer.cpp, the
    # zombie-glitch stall guard, written when "no legitimate attempt exceeds
    # ~22k ticks"). At 62 cells the air variant pushed the rig to ~50k ticks and
    # it was killed mid-run, walking flat ground at vy=0 -- which reads as a
    # death in the rig rather than as a budget.
    return objs, x + 40 * GRID, u


def build_portalpress() -> str:
    u"""WHICH BODY SPENDS A PRESS MADE ON A MODE PORTAL'S OWN TICK?

    GD's tick is update -> collisions -> buttons, so a portal that fires in
    collisions has already changed the body by the time the button is read. The
    model reads the button FIRST. The two orders disagree only on the portal's
    own tick, and that is one tick nobody has ever put a press on deliberately.

    It matters because the DP will USE whatever the model offers. lv21's cold
    spent 37 of its 44 rounds on one wall, and the first divergence on that
    route is a mode portal at t=18,619 where the model comes out with vy 9.136
    and GD with 3.324. The model's value is in the UFO-flap family; GD's is
    not. But that tick also carries a ramp exit and a size portal, and the
    plan's press does not visibly land on EITHER side at the two ticks before
    it -- so the corpus cannot say what spent the press, or when. Hence a rig.

    Per pair, seven cells:
      2 CONTROLS -- press at portal_t -10 and +10. These prove the rig can see
        a press at all, in each body, away from the seam. A pair whose controls
        are silent measures nothing and is thrown away, not read as "no effect"
        (the discipline build_ufoexit spells out).
      5 SWEEP -- offsets -2..+2. The offsets are the instrument: which of them
        produce the `from` body's answer and which the `to` body's locates the
        seam AND any input lag at the same time, without either having to be
        assumed. Assuming the lag is exactly what went wrong reading lv21.

    Three pairs: ufo->cube is the corpus case; cube->ufo is it backwards (a
    grounded cube's jump against a flap); ship->cube changes the body without
    changing whether the press has an effect at all.
    """
    UNITS.clear()
    PLAN.clear()
    objs: list[str] = []
    x = 90.0
    for frm, to in (("ufo", "cube"), ("cube", "ufo"), ("ship", "cube")):
        # The window is shifted left because pass 1 measured the input lag: a
        # press row at T moves vy at T+1 for a cube and T+2 for a UFO. A window
        # centred on the portal would put the lagged effect of the interesting
        # presses outside it.
        for offset, cell in ((-12, "control"), (-4, "sweep"), (-3, "sweep"),
                             (-2, "sweep"), (-1, "sweep"), (0, "sweep"),
                             (1, "sweep"), (2, "sweep"), (12, "control")):
            part, x, u = portalpress_unit(x, frm, to, offset, cell)
            objs += part
            UNITS.append(u)
    # ...and the same seam met IN MID-AIR. This is the half the ground cells
    # cannot speak about: whether the press the new body receives still has to
    # satisfy that body's own precondition. A cube's does -- it only jumps from
    # the ground -- and the model's re-issue does not ask.
    for frm, to in (("ufo", "cube"), ("cube", "ufo")):
        for offset, cell in ((-12, "control"), (-1, "sweep"), (0, "sweep"),
                             (12, "control")):
            part, x, u = portalpress_unit(x, frm, to, offset, cell, air=True)
            objs += part
            UNITS.append(u)
    objs += floor_run(0, x + 300.0)
    return header(start_mode="cube") + ";" + ";".join(objs) + ";"


# Corridor height, floor top -> ceiling bottom. 120 was too low: a cube that
# jumps at portal_t - 3 becomes a spider on the way up, keeps rising under the
# spider's much weaker gravity (-0.129/tick) and bonks the ceiling -- the
# second pass died there at unit 10 and left every later unit empty.
PORTALSPIDER_CEIL = 240.0


def portalspider_unit(x: float, frm: str, press: tuple[int, int], cell: str
                      ) -> tuple[list[str], float, dict]:
    u"""ONE `frm -> spider` portal, with the button down over [portal_t + a,
    portal_t + b] (a == b is a one-tick press).

    The corridor has a ceiling, because a spider's jump is a teleport to the
    nearest surface above it: without one the rig could not see the jump at
    all. Each unit opens with normal-gravity portals at floor AND ceiling
    height (a spider the last unit left on the ceiling meets the upper one and
    falls back to the floor), then the `frm` portal on the floor past where that
    fall lands, so the old body settles before the test.
    """
    objs: list[str] = [obj(GRAV_NORM, x + 1 * GRID, GROUND_TOP + 15.0),
                       obj(GRAV_NORM, x + 1 * GRID,
                           GROUND_TOP + PORTALSPIDER_CEIL - 15.0),
                       obj(MODE_PORTAL[frm], x + 6 * GRID, GROUND_TOP + 15.0)]
    x_test = x + 25 * GRID
    # Floor-level, as in calib_portalpress: only a body on (or just off) the
    # floor meets it.
    objs.append(obj(P_SPIDER, x_test, GROUND_TOP + 15.0))
    pt = mode_change_near(x_test)
    base = pt if pt >= 0 else tick_at(x_test)
    a, b = press
    PLAN.append((base + a, 1))
    PLAN.append((base + b + 1, 0))
    u = {"x0": x, "x1": x + 40 * GRID, "from": frm, "to": "spider",
         "press_a": a, "press_b": b, "cell": cell, "x_test": x_test,
         "press_t": base + a, "portal_t": pt, "portal_t_measured": pt >= 0}
    return objs, x + 40 * GRID, u


def build_portalspider() -> str:
    u"""DOES A MODE PORTAL HAND A PRESS TO A SPIDER, AND WHEN?

    calib_portalpress settled it for cube / UFO (the press belongs to the new
    body from portal_t - 1, and the new body's precondition still applies) and
    left wave / robot / spider / ball / swing unmeasured. lv21 t=16,723 is a
    wave -> spider portal met grounded, with the button held since the wave
    climbed a ramp: GD's spider teleports on the next tick (y 163.5 -> 226.5,
    once; the button stays down and nothing more happens), and the model's does
    not, because its re-issue covers cube / robot / UFO only.

    Cells, per old body:
      ONE-TICK PRESSES at portal_t -12 and +12 (controls: the old body's and the
        spider's own answer, away from the seam) and -3..+2 (the sweep: which
        body owns the press, and the input lag).
      HELD from before the portal to +15: the lv21 shape as far as a flat floor
        allows. A held wave or ship rises off the floor, so those arrive
        airborne; a UFO held from -40 flaps once and is back on the floor, still
        held, at the portal -- the "grounded, held, press already spent" cell.
    The wave goes last: one death ends the run.
    """
    UNITS.clear()
    PLAN.clear()
    objs: list[str] = []
    x = 90.0
    sweep = ((-12, "control"), (-3, "sweep"), (-2, "sweep"), (-1, "sweep"),
             (0, "sweep"), (1, "sweep"), (2, "sweep"), (12, "control"))
    for frm in ("ufo", "cube", "ship", "wave"):
        for off, cell in sweep:
            part, x, u = portalspider_unit(x, frm, (off, off), cell)
            objs += part
            UNITS.append(u)
        held = ((-40, 15),) if frm == "ufo" else ((-6, 15), (-1, 15))
        for a, b in held:
            part, x, u = portalspider_unit(x, frm, (a, b), "held")
            objs += part
            UNITS.append(u)
    objs += floor_run(0, x + 300.0)
    ceil_cy = GROUND_TOP + PORTALSPIDER_CEIL + GRID / 2.0
    objs += floor_run(0, x + 300.0, y=ceil_cy)
    return header(start_mode="cube") + ";" + ";".join(objs) + ";"


def build_spiderairhold() -> str:
    u"""DOES A SPIDER KEEP A PRESS MADE IN THE AIR UNTIL IT LANDS?

    calib_portalspider left one cell the portal rules do not cover: a ship ->
    spider unit whose press started one tick after the portal, with the spider
    already falling (it comes out 1.5 px above the floor), held -- GD teleports
    on the tick it lands (+11), and the model, whose spider teleports only on a
    fresh press while grounded, never does. That is a claim about the spider
    in general, so it is asked here with no portal at all: a yellow pad puts a
    spider on the floor into the air, and the press is made on the way up or on
    the way down, then held (or released) through the landing.

    Cells: held from pad_t +10 / +40 / +80 until pad_t +400; one tick at pad_t
    +40 (the control that a released press is not kept); one tick at pad_t +600,
    long after landing (the grounded tap every other rig already sees).
    """
    UNITS.clear()
    PLAN.clear()
    objs: list[str] = []
    x = 90.0
    cells = (((10, 400), "held"), ((40, 400), "held"), ((80, 400), "held"),
             ((40, 40), "released"), ((600, 600), "grounded"))
    for (a, b), cell in cells:
        objs.append(obj(GRAV_NORM, x + 1 * GRID, GROUND_TOP + 15.0))
        objs.append(obj(GRAV_NORM, x + 1 * GRID, GROUND_TOP + PORTALSPIDER_CEIL - 15.0))
        objs.append(obj(P_SPIDER, x + 6 * GRID, GROUND_TOP + 15.0))
        x_pad = x + 20 * GRID
        objs.append(obj(PAD["yellow"][0], x_pad, GROUND_TOP + 15.0))
        base = tick_at(x_pad)
        PLAN.append((base + a, 1))
        PLAN.append((base + b + 1, 0))
        UNITS.append({"x0": x, "x1": x + 40 * GRID, "cell": cell, "press_a": a,
                      "press_b": b, "x_pad": x_pad, "pad_t_est": base,
                      "press_t": base + a})
        x += 40 * GRID
    objs += floor_run(0, x + 300.0)
    objs += floor_run(0, x + 300.0, y=GROUND_TOP + PORTALSPIDER_CEIL + GRID / 2.0)
    return header(start_mode="spider") + ";" + ";".join(objs) + ";"


def build_slopeup() -> str:
    u"""A cube meets a ramp WHILE STILL RISING -- AND IT DOES NOT WORK.

    KEPT AS A REJECTION, not as an instrument. The geometry does not pose the
    question it was built for, and the reason generalises: while a ramp's surface
    faces the player's gravity-up, a contact with s*v > 0 can only happen from
    INSIDE the box, so a rising player meets the UNDERSIDE and this rig measures
    head-bumps. Two cells push the player onto the box top (+42.9px), the rest
    stop it dead with vy kept, and pass 1 dies -- which then exhausts the xmap, so
    the last nine units all got the same press tick. That last part is how it was
    caught: `ahead` goes up while `press_t` goes DOWN.
    The underside is not unmeasured anyway -- the gate has already been measured
    separately, including that the 5.0 threshold is hitGround's and floor-only,
    so the underside has no vy test at all.

    Original intent, left for whoever tries again:

    kSlopeLandV is a SIGNED test -- GD's hitGround sets m_isOnGround only when
    s*v <= 5.0 and above it the caller restores the old vy -- so a faller always
    lands however fast, and the only refused side is a player LEAVING the
    surface faster than 5. Nothing has ever been measured on that side. lv21
    t=19,724 is one case of it (flipped gravity, s*v = +9.45): neither GD nor the
    model lands, but GD still moves the player 3.534px onto the seat and the
    model skips the reposition entirely.

    An injected player cannot measure it: injection CARRIES onGround OVER, and
    the slope gate reads the grounded state and two 0.1s timers, so every
    injected cell is a player GD thinks is already standing (measured -- seven
    cells, all useless). So the player has to get there on its own: it jumps off
    the flat floor and meets a ramp mounted above it on the way up.

    ONE ramp, at a fixed height, and the PRESS PHASE is the sweep: pressing
    earlier puts the player further along its arc when it arrives at the ramp's
    x, which walks the contact velocity from about +11 down through 0 and into
    the falling half. That is a continuous sweep through the 5.0 boundary with a
    single piece of geometry, and both sides of the boundary are in the same rig.

    PREDICTION, registered before the run: contact vy above +5 repositions
    without landing (vy kept, onGround 0); at or below +5 it lands (vy 0,
    onGround 1). If the boundary lands anywhere else, kSlopeLandV's stated
    meaning is wrong, not just its use.

    The ramp's box bottom is at 150, thirty above the running player's box top
    (120), so it is clear of the run-up and only the jump can reach it.
    """
    UNITS.clear()
    PLAN.clear()
    objs: list[str] = []
    x = 90.0
    BOX_BOTTOM = 150.0
    for n in range(0, 26, 2):
        x0 = x
        x_ramp = x + 22 * GRID
        # 309: plain (shz=0), 30x30, |m|=1, sup=1 -- a FLOOR ramp, the same
        # family the seat was measured on.
        objs.append(obj(PLAIN30, x_ramp, BOX_BOTTOM + 15.0))
        t = tick_at(x_ramp) - n
        PLAN.append((t, 1))
        PLAN.append((t + 1, 0))
        UNITS.append({"x0": x0, "x_ramp": x_ramp, "press_ahead": n,
                      "press_t": t, "box_bottom": BOX_BOTTOM,
                      "ramp_cy": BOX_BOTTOM + 15.0,
                      "ramp_t": tick_at(x_ramp)})
        x = x + 40 * GRID      # the tick budget -- see portalpress_unit
    objs += floor_run(0, x + 300.0)
    return header(start_mode="cube") + ";" + ";".join(objs) + ";"


def build_slopeceil() -> str:
    u"""DOES A RAMP CONTACT SEAT THE PLAYER BEFORE THE RIDE STARTS? -- AND THIS
    SHAPE DOES NOT ANSWER IT EITHER. KEPT AS A REJECTION.

    Measured: the cube dies. First unit, t=589, x=763.4, y=127.5, still rising at
    +9.02 -- its box top reaches 142.5 where the ceiling ramp's line is at 142, so
    it is 0.5px inside the solid and GD crushes it. Every phase of the sweep does
    the same, and pass 1 ends at the first one.

    That is a real answer to a smaller question -- a cube rising into a CEILING
    ramp's solid is killed, not seated -- and it also says the analogy to lv21 was
    wrong. lv21's player is UPSIDE DOWN, so for it the ramp's solid half and its
    own "up" are on opposite sides; it enters the EMPTY triangle of a sup=1 floor
    ramp. Reproducing that needs a gravity portal, a ceiling ride, and a floor
    ramp below it, not a ceiling ramp with normal gravity. The flip is not
    decoration here.

    The original intent, kept for whoever builds that rig:

    Two different events run when a player touches a ramp, and confusing them
    made a rig measurement and a corpus tick look like a contradiction:

      the seat        hitGround writes y once, on the RECT overlap, and raises
                      m_isOnGround2 unconditionally. Whether it also lands --
                      m_isOnGround, and the caller's vy restore -- is what the
                      5.0 gate decides, on the SIGNED gravity-frame speed
      the ride start   GD follows the line from the tick the CONTACT POINT
                      `cx +- slopeXOffset(m,pH)` enters the span. For a cube at
                      |m|=1 that is cx+6.213, nine px later than the box edge,
                      and calib_ceilramp measured it 6/6 for the cube and 6/6
                      for the UFO

    lv21 t=19,724 is the seat: GD moves the player 3.534px on the tick the boxes
    first overlap by 0.70px, keeps vy, leaves m_isOnGround at 0 and raises
    m_isOnGround2. The model has no seat before its ride window, so it follows
    seven ticks late -- and those seven ticks are the whole divergence that the
    cold's 37-round wall sits under.

    calib_ceilramp cannot settle it: its measurement is that the box edge is
    NINE PX EARLY for the descent, which means GD did not seat at the box edge
    THERE. What differs is how the boxes meet. On that rig the player travels
    horizontally under a ceiling ramp, so the y overlap starts near zero; in lv21
    the player is driven INTO the box (16.25px of y overlap against 0.70px of x).

    So: the same approach as lv21, in a rig. The ramp is a CEILING one (rot 0 with
    flip_y -> sup=0, sdir=1, line 255->225) hung low enough that the cube's jump
    carries it into the empty half below the line while still rising at more than
    5 -- which is the side of kSlopeLandV that refuses to land, so a seat there
    cannot be confused with a landing. One ramp; the sweep is the press phase, as
    in calib_slopeup, because that walks the contact velocity continuously.

    A seat shows as a y step the tick's vy does not explain, with onGround still
    0 and onGround2 raised. If none appears at any phase, lv21 has a further
    ingredient and this rig says so rather than guessing one.
    """
    UNITS.clear()
    PLAN.clear()
    objs: list[str] = []
    x = 90.0
    BOX_BOTTOM = 140.0
    for n in range(0, 26, 2):
        x0 = x
        x_ramp = x + 22 * GRID
        objs.append(obj(PLAIN30, x_ramp, BOX_BOTTOM + 15.0, flip_y=True))
        t = tick_at(x_ramp) - n
        PLAN.append((t, 1))
        PLAN.append((t + 1, 0))
        UNITS.append({"x0": x0, "x_ramp": x_ramp, "press_ahead": n,
                      "press_t": t, "box_bottom": BOX_BOTTOM,
                      "ramp_cy": BOX_BOTTOM + 15.0,
                      "ramp_t": tick_at(x_ramp), "sup": 0})
        x = x + 40 * GRID      # the tick budget -- see portalpress_unit
    objs += floor_run(0, x + 300.0)
    return header(start_mode="cube") + ";" + ";".join(objs) + ";"


def build_slopeflip(oid: int = PLAIN30, nbrs: bool = False,
                    group: bool = False) -> str:
    u"""lv21's OWN APPROACH, IN A RIG: a FLIPPED cube driven into the EMPTY half
    of a FLOOR ramp.

    Third attempt at one question -- does a ramp contact seat the player before
    the ride starts? -- and the first with the right geometry. The two rejections
    say why (both kept, with their own docstrings):

      calib_slopeup    normal gravity, rising into a sup=1 ramp -> head-bump on
                       the underside (+42.9px onto the box top, or stopped dead)
      calib_slopeceil  normal gravity, rising into a sup=0 ramp -> DEAD, half a
                       pixel inside the solid at t=589

    Both fail the same way: with normal gravity, "moving toward the line against
    my own gravity" puts the player into the SOLID half. lv21's player is upside
    down, so the ramp's solid half and its own up are on opposite sides and it
    enters the EMPTY triangle. The flip is load-bearing, not decoration.

    So: flip at the start, ride the underside of a flat ceiling at 320, and jump
    DOWNWARD into a sup=1 floor ramp whose box is 240..270 -- the empty side, near
    the low end of its line. From y=305 a jump is -11.18 and the box's top edge
    is 20px down, about eight ticks, by which time vy is near -9.45: s*v = +9.45,
    which is lv21's own number and above the 5.0 that refuses to land. A seat
    there therefore cannot be read as a landing.

    The sweep is the press phase, as in calib_slopeup, which walks the contact
    point along the span continuously instead of assuming where it lands.

    What to read: a y step the tick's vy does not explain, with onGround still 0
    and onGround2 raised. If the player dies instead, that is an answer too --
    and it would mean lv21's survival needs a further ingredient.
    """
    UNITS.clear()
    PLAN.clear()
    objs: list[str] = []
    x = 90.0
    CEIL = 320.0            # underside of the flat ceiling; the flipped cube
                            # rides at CEIL - 15 = 305
    # THE KNOB IS THE RAMP'S HEIGHT, NOT THE PRESS PHASE.
    # Phase alone cannot reproduce lv21: there the player travels at a y ALREADY
    # inside the ramp's band (the tick before the contact has ZERO x overlap and
    # ~18px of y overlap) and then clips in x by 0.70px, with its box bottom 11px
    # ABOVE the line's low end -- so no part of it is in the solid. Coming down
    # from above the band, x overlap and y overlap grow together: at the corner
    # touch both are 0.5px, GD does NOT seat, and ten ticks later the box bottom
    # has dropped below the rising line and GD kills (measured at cy=255).
    # So place the band where the player already is on the arrival tick. At phase
    # 32 it reaches the span at y=284.5 with its box at 269.5..299.5; putting the
    # band bottom 11px under the box bottom -- 258.5, i.e. cy 273.5 -- reproduces
    # lv21's numbers. The ceiling ride at 290..320 still clears the band top.
    RAMP_CY = 273.5         # box 258.5..288.5, line 258.5->288.5 (sup=1)
    objs.append(obj(GRAV_FLIP, x + 4 * GRID, GROUND_TOP + 15.0))
    # THE PHASE WINDOW IS SHIFTED EARLY, AND THE EARLIEST CELL COMES FIRST.
    # Measured on the first build (phases 0..26): the player reached the box at
    # x=763, a step from the span's right edge at 765, where the ascending line
    # has climbed to 268.4 -- so its box bottom at 267.5 was inside the SOLID and
    # it died at t=589. lv21 enters at x0+0.7, where the line is still at its low
    # end and the empty triangle is nearly the whole box. Pressing ~8 ticks before
    # the LEFT edge is what puts the descent there, and the fall from the ceiling
    # takes about that long, so the phase has to be 20-40 ticks ahead of the
    # centre rather than 0-26.
    # ...AND THE WINDOW IS ONE PHASE WIDE, BECAUSE THE CONTACT IS A CORNER.
    # lv21's x overlap on the deciding tick is 0.70px against 16.25px of y: the
    # player's bottom-right corner clips the ramp's top-left corner and NO part of
    # its box is below the line. Give it more x overlap and the box straddles the
    # rising line, part of it ends up in the solid, and GD kills -- measured twice
    # here, at 13.5px of overlap (t=566) and at the span's far end (t=589).
    # A death ends the attempt and therefore pass 1, so the rig cannot carry
    # lethal phases at all: every cell has to be survivable. Back-computed from
    # pass 1's own dump -- box right edge reaches 735 and box bottom reaches 270
    # on the same tick when the press is 32 ticks ahead of the centre -- so this
    # is one unit at that phase. Widen only after it is seen to survive.
    for n in (32,):
        x0 = x
        x_ramp = x + 22 * GRID
        # `group`: lv21's 1338 carries a group id even though grouptrace shows it
        # never moves (key 57 in the level string). Being IN a group is a
        # different object state from being static.
        # `nbrs`: and it is not alone -- within 60px lv21 has a solid 467 COLUMN
        # starting at the ramp's own cy and stacked upward, plus a thin 468 slab
        # (30 x 1.5) 14.25px below that. Same offsets here.
        objs.append(obj(oid, x_ramp, RAMP_CY,
                        extra={57: "1"} if group else None))
        if nbrs:
            for k in range(5):
                objs.append(obj(467, x_ramp + 30.0, RAMP_CY + k * 30.0))
            objs.append(obj(468, x_ramp + 30.0, RAMP_CY - 14.25))
        t = tick_at(x_ramp) - n
        PLAN.append((t, 1))
        PLAN.append((t + 1, 0))
        UNITS.append({"x0": x0, "x_ramp": x_ramp, "press_ahead": n,
                      "press_t": t, "ramp_cy": RAMP_CY, "ceil": CEIL,
                      "ramp_t": tick_at(x_ramp), "sup": 1, "flip": 1,
                      "oid": oid, "nbrs": int(nbrs), "group": int(group)})
        x = x + 40 * GRID      # the tick budget -- see portalpress_unit
    # The ceiling runs the whole rig: the ride has to survive between units, and
    # a gap would drop the player onto the ramps from above, which is the
    # rejected geometry again.
    xx = x + 300.0
    objs += floor_run(0, xx)
    objs += floor_run(0, xx, y=CEIL + GRID / 2)
    return header(start_mode="cube") + ";" + ";".join(objs) + ";"


def build_empty() -> str:
    """For triage: header only (no objects)."""
    return header() + ";"


def build_holdjump(mode: str, mini: bool = False, speed: int = 0) -> str:
    """Hold the button from tick 0 and see what the mode does about it.

    Header only: GD's own ground (world y=90) is solid across the whole level,
    so this is a flat run with nothing on it and the mode chosen at the start
    rather than by a portal -- no portal tick, no size change, nothing else that
    could account for a jump.

    The question it exists for: the CUBE re-jumps on a button that is
    merely HELD, and the model now mirrors GD's m_jumpBuffered to say so. For the
    ROBOT the disassembly says it cannot -- updateJump's robot arm needs
    [player+0x986] as well as m_jumpBuffered (0x38ba3c..0x38ba51) and clears
    0x986 in the arm that jumps (0x38c728) -- while the model carries a
    measurement claiming it does. The corpus cannot decide it: across all 22
    verified plans there are 81 robot landings and NOT ONE of them has the button
    held through (4 are rising edges, 77 have no press), so the answer has to be
    asked of the game.

    Read it off the trace: one jump and then a run along the floor means the
    press is spent; a repeating bounce means the held level is enough.

    The floor is laid at y=75 so its TOP FACE IS GD's OWN GROUND (world 90) --
    the flat90 form, which runs to the end, and not the buried y=15 form that
    kills the player at the spawn (see the Y_OFFSET note). It is here only for
    length: a header-only level ends at x=919, which is 3 seconds and not enough
    room for a second landing to be waited for.

    The spike at the far end is what keeps the rig USABLE FROM THE MCP. A flat
    level is completed by the very first attempt, and a session whose level was
    completed stops polling cmd.txt (`g_started && !g_sessionOver`) -- the first
    two builds of this rig came back as "the rerun never landed (session already
    over?)" for exactly that reason. Dying is fine; finishing is not.
    """
    objs = floor_run(0, 12000, y=75.0)
    objs.append(obj(SPIKE, 11400, GROUND_TOP + 15.0))
    return (header(start_mode=mode, mini=mini, speed=speed) + ";"
            + ";".join(objs) + ";")


def build_flat() -> str:
    """For triage: a flat floor and nothing else."""
    return header() + ";" + ";".join(floor_run(0, 6000, y=GRID / 2)) + ";"


def build_flat90() -> str:
    """For triage: align the floor's top surface with GD'S GROUND (y=90).

    empty (header only) ran to the end; flat (floor laid at y=15, i.e. 60px
    below the ground) died instantly. GD's ground is not y=0 but 90 (the player
    stands at y=105 = 90+15), so a block placed below the ground is buried, with
    the player inside it. Build calibration rigs ON TOP OF the ground.
    """
    return header() + ";" + ";".join(floor_run(0, 6000, y=75.0)) + ";"


def build_flatfar() -> str:
    """For triage: move the buried blocks away from the spawn (x>=300).

    Separates whether the instant death is "overlapping the spawn" or "the
    buried block itself".
    """
    return header() + ";" + ";".join(floor_run(300, 6000, y=GRID / 2)) + ";"


def build_sawcal() -> str:
    """Isolated circle hazards for outline sweeps (wave first; any mode later).

    Four stations 1000px apart, each one saw in open air at y=300, nothing else
    within 900px. Probes inject (x,y) around a station and bisect the kill
    boundary radially; the clean surroundings are the whole point -- lv20's own
    saws are all decorated with spikes/walls and every approach line is
    polluted (measured 2026-08-26: the polar sweep around uid1321 hit walls at
    R=30 in every direction).

      x=2000  id 1734  (lv20 big wheel, dumped radius 32)
      x=3000  id 1735  (lv20 small wheel, dumped radius 17.51)
      x=4000  id 1734 at scale 0.5 (does the kill radius scale?)
      x=5000  id 88    (classic saw family 88/89/98, the one the margins were
                        calibrated on)

    The rig starts as WAVE; the probe plan holds the input from t=0 so the
    natural path climbs away from the floor and the injection tick is free.
    Per-mode variants (sawcal_ship etc.) exist because the branch inside
    playerCircleCollision (0x211df0) and the player rect are per-mode; probes
    inject vy=0 so the injection tick is mode-agnostic.
    """
    return build_sawcal_mode("wave")


def build_sawcal_mode(mode: str, mini: bool = False) -> str:
    parts = [header(start_mode=mode, mini=mini)]
    parts += floor_run(0, 8000, y=GROUND_Y)
    # The no-input attempt slides along the flush floor ALIVE and completes the
    # level, and a completed session stops polling cmd.txt (the gd-probe trap).
    # A wall at x=230 kills every natural attempt; probe plans hold the input
    # from t=0 (climbing away over it is irrelevant -- they stop_at t=100,
    # x~130, before ever reaching it).
    for k in range(12):
        parts.append(obj(BLOCK, 230, 105 + GRID * k))
    parts.append(obj(1734, 2000, 300))
    parts.append(obj(1735, 3000, 300))
    parts.append(obj(1734, 4000, 300, scale=0.5))
    parts.append(obj(88, 5000, 300))
    # id 918 (type 47, radius 24): its kill circle is fetched via a VIRTUAL
    # "circle centre" (vtable +0x4a8 in playerCircleCollision), so it need not
    # sit on the anchor -- lv20's rot=-61 one kills 0.5..1.5px off the model's
    # prediction. One straight and one rotated to measure the offset.
    parts.append(obj(918, 6000, 300))
    parts.append(obj(918, 7000, 300, rot=-61))
    return ";".join(parts) + ";"


# ---- The same rig, with the saws GROUP-MOVED (2026-08-28) ------------------
# WHY. hazardHit (object.hpp) sends a moving circle down branch A (circle vs
# circle) and a static one down branch B (the player rect plus corner discs).
# The gate rests on ONE reading -- lv22 uid710, spider vs a group-moved saw --
# and lv21 contradicts it: 12 injection probes there (mini ship vs a rotated
# r=4 blade, full cube vs a moved r=24) ALL land on branch B, with A wrong in
# both directions. The disassembly says the branch is chosen by
# [[layer+0xdb0]+0x1cf] (0x211df0 @0x211e15), which is read off the LAYER and so
# cannot be a per-object property at all.
#
# Re-reading it in a real level failed: lv22's own circles sit in decorated
# columns and gd_death_context names four overlapping objects at once, exactly
# the pollution this rig family exists to avoid. So: the sawcal stations, with
# the saws group-moved, which reproduces lv21's condition in clean air and
# covers all 8 modes at once.
#
# THE LEVEL-STRING KEYS BELOW ARE NOT MEASURED. mklevel has never emitted a
# trigger, so 57 (group list), 51 (target group), 10 (duration), 28/29 (move
# x/y) and their units are taken from the community spec and MUST be closed by
# generating this rig, loading it, and reading the MOD's own trigger dump back
# (target / dur / ox / oy). The move offset's unit in particular is unverified,
# which is why the probe reads the saw's position out of grouptrace rather than
# predicting it.
TRIG_MOVE = 901
K_GROUPS, K_TARGET, K_DURATION, K_MOVE_X, K_MOVE_Y = 57, 51, 10, 28, 29
K_EASING, K_EASING_RATE = 30, 85
SAW_GROUP = 1

# One extra pair over the static rig: id 1582/1583 are lv21's r=4 blades, the
# objects the contradiction was measured on, and a small radius is the only way
# to separate the branches for the SPIDER (its rect half 13.5 exceeds r=4, so
# B's corner test cannot fire and B collapses to the bare rect -- a 4 px gap
# against A's 17.5).
SAWCAL_STATIONS = [(1734, 2000, 0.0), (1735, 3000, 0.0), (1734, 4000, 0.5),
                   (88, 5000, 0.0), (918, 6000, 0.0), (1582, 7000, 0.0),
                   (1583, 8000, 0.0)]


TRIG_ROTATE = 1346
# Rotate trigger properties. NOT taken on faith: the rig is dumped and the
# columns are read back (center/deg/t360 land where they should), so a wrong id
# shows up as a zero in triggers.txt before any conclusion rests on it.
K_CENTER, K_DEGREES, K_TIMES360, K_LOCKROT = 71, 68, 69, 70


# ---- The same saws in the OTHER flag world (2026-09-02) ---------
# WHY. hazardHit sends a circle hazard down branch B (the player's rect plus
# corner discs) wherever sawRectHalfB has a measurement, and down branch A
# (circle against circle) only where it has none. ALL of that measurement --
# the 2026-08-26 sweep, eight modes by five stations, and the 2026-08-28 rebuild
# with the saws group-moved -- was taken in ONE flag world. Every rig mklevel
# has ever emitted stops its header at kA11, so kA39 was 0 in all of it.
#
# The disassembly says the branch is picked by `[[layer+0xdb0]+0x1cf]`
# (0x211df0 @0x211e15), read off the LAYER and so not a property of either
# object -- and LevelSettingsObject +0x1cf is kA39, which lv22 is the only
# official level to set. That makes "static saws take branch B" possibly
# "kA39=0 saws take branch B", and lv22's own reading (a spider dome at
# 13.5 + 4, which branch B cannot produce at r < h) the other half of the same
# statement rather than a contradiction of it.
#
# So these rigs are one experiment: THE SAME GEOMETRY GENERATED TWICE, with and
# without --ka39, so the only difference between the two runs is one header key.
# The kA39=0 arm is the control, and it is not decoration -- it has to reproduce
# the numbers already on record (object.hpp's note: rect half 5.0 wave / 13.5
# spider / 15.0 everything else, radius scaling exactly). If the control arm
# does not land there, something other than the flag has moved and neither arm
# means anything.
#
# Stations are 1000 px apart in open air at y=300, the sawcal convention, so
# nothing is within 900 px of the probe.
KA39_STATIONS = [
    # (id, x, scale, rot, why this station exists)
    (1583, 2000, 0.0, 0,
     "r=4. SMALLER THAN EVERY MODE'S HALF, which is what makes the two "
     "branches differ in kind rather than in degree: B's corner disc cannot "
     "reach past the rect at all (its axis boundary is the flat edge h) while "
     "A's is a circle at h+4. This is the lv22 uid710 configuration -- the "
     "spider dome measured at 17.5 = 13.5 + 4"),
    (1583, 3000, 0.0, 90,
     "the same blade turned 90 degrees. id 1583 is 31x23, so w/w0 stops being "
     "the scale and becomes the SWAP ratio 0.742: the model recovers a radius "
     "of 2.968 where GD's is still 4.00. The axis boundary tells them apart, "
     "1.03 px. 31x23 is also not a multiple of 30, so this one station also "
     "separates the two pivot conventions -- getRealPosition against the rect "
     "centre -- which is the other thing this rig is meant to settle"),
    (918, 4000, 0.0, 0,
     "r=24, larger than every mode's half, so B's corner arcs DO reach and the "
     "branches straddle: A is wider on the axis and narrower on the diagonal. "
     "One station carrying both signs is what stops a single boundary from "
     "being read as agreement"),
    (918, 5000, 0.0, -61,
     "the same circle turned by something that is not a multiple of 90. This "
     "is the OBB arm's static subject: kA39 is also said to skip the turned "
     "box's SAT and let the circle be the final word, and a 90-degree turn "
     "cannot show that because the box is still axis-aligned"),
    (1734, 6000, 0.0, 0,
     "r=32, the widest. This is where A and B come CLOSEST on the axis (47.0 "
     "against 43.3 for a cube), so a rig that cannot separate them here is "
     "under-resolved and its agreement elsewhere means less"),
    (1734, 7000, 0.5, 0,
     "the same wheel at half scale, R=16. Whether the effective radius still "
     "follows the scale in the A world, which branch A's own formula "
     "(max(scaleX,scaleY) * m_objectRadius) says it should"),
]


def _ka39_rig(mode: str, mini: bool, spin: bool) -> str:
    """The kA39 station set, optionally with the saws spun by a Rotate trigger.

    The floor, the wall at x=230 and the 1000 px spacing are sawcal's, so the
    control arm is comparable with what is already on record. The wall is what
    stops the no-input attempt from completing the level: a completed session
    stops polling cmd.txt and the probe hangs (the gd-probe trap).
    """
    parts = [header(start_mode=mode, mini=mini)]
    parts += floor_run(0, 9000, y=GROUND_Y)
    for k in range(12):
        parts.append(obj(BLOCK, 230, 105 + GRID * k))
    grp = {K_GROUPS: str(SAW_GROUP)} if spin else None
    for oid, x, scale, rot, why in KA39_STATIONS:
        UNITS.append({"x": x, "id": oid, "scale": scale, "rot": rot,
                      "why": why})
        parts.append(obj(oid, x, 300, rot=rot, scale=scale, extra=grp))
    if spin:
        # ONE Rotate, one centre, every station in the turned group. The centre
        # sits 45 px under the FIRST station, so each saw runs a small orbit
        # (bounded by 90 px, staying in its own clean air) while its own facing
        # goes all the way round -- times360=1 -- and therefore passes through
        # 45 degrees, the angle at which a turned box and its bounding circle
        # differ most.
        #
        # The centre marker is a BLOCK, as in cpriderot. Its top face is at
        # y=270 and the probe sweeps the outline from above (y around 320), so
        # it is never in the swept column -- CHECK THAT with `column` before
        # bisecting anything, exactly as hitbox_sweep's own note says.
        #
        # UNVERIFIED, and the rig is how it gets verified: that a Rotate turns
        # a circle hazard's own angle at all, and that the trigger's property
        # ids are what this file assumes. Load it and read the MOD's trigger
        # dump back (target / centre / deg / t360) before any conclusion rests
        # on it -- the same round trip build_sawcal_moved documents.
        cen_x, cen_y = KA39_STATIONS[0][1], 300 - 45
        parts.append(obj(BLOCK, cen_x, cen_y, extra={K_GROUPS: str(SAW_GROUP + 1)}))
        parts.append(obj(TRIG_ROTATE, 45, 300, extra={
            K_TARGET: str(SAW_GROUP),
            K_CENTER: str(SAW_GROUP + 1),
            K_DURATION: "30",
            K_DEGREES: "0",
            K_TIMES360: "1",
            K_LOCKROT: "0",
            K_EASING: "0",
            K_EASING_RATE: "2",
        }))
    return ";".join(parts) + ";"


# ---- The flip window, with the LAUNCH taken off the flip -------
# WHY A NEW RIG AT ALL. The probe this replaces could not be built: a blue pad
# leaves the player upside-down and injecting it back onto the same pad does not
# re-fire it (GD keeps the contact as spent), so "upright again, and recently
# flipped" was unreachable. What is needed is an UPRIGHT player whose head
# reaches a ceiling within 0.1 s of a gravity flip.
#
# The trap in the obvious build is that a flip is also a launch: flip, rise,
# flip back, and the time from the flip to the ceiling is set by a parabola
# whose constants are exactly what is in question. So this rig SEPARATES THE
# TWO. The gravity-portal pair is short -- twelve ticks, sixteen pixels, the
# player barely leaves the floor -- and does nothing but stamp the flip. The
# launch is a yellow pad further along, and the only thing that differs between
# stations is HOW FAR ALONG THE FLOOR that pad is.
#
# The floor distance converts to ticks exactly (dx is a constant per speed), so
# the ladder's STEPS are exact even though its offset is not: every station
# shares the same "pad -> ceiling" flight, so that unknown is a constant added
# to every rung and cancels out of the comparison between them. The absolute
# delta is read from GD's own dump, never predicted.
#
# Ordered by increasing delay, so a single natural run walks the ladder and, if
# the window is real, dies at the first rung outside it: the death x names the
# boundary without any bisection at all.
FLIP_ARM_ID = 1859          # the ceiling arm (GameObjectType 40)
FLIPWIN_PITCH = 1600.0      # between rungs; nothing of one reaches the next
# TWO PORTAL BOXES MUST NOT OVERLAP. A gravity portal is 25 wide, so the player
# (30 wide) is inside both at once for any separation under 55 px, and while it
# is, each tick ends with whichever of the two GD happened to process last --
# the flip has no single timestamp to measure from. A first cut put them 16 px
# apart for exactly the reason that looked attractive (the player barely leaves
# the floor) and would have measured a refresh, not a flip.
#
# Separated enough to be two events, the flip is also a LAUNCH: sixty ticks of
# inverted gravity lifts the player 389 px, and the yellow portal has to be up
# there to catch it. That is the trade this rig accepts, and it is the safe
# side of it -- the portal's box is 75 tall against a placement computed from a
# constant measured to a thousandth, and a miss announces itself (the player
# simply never comes back down) instead of quietly shifting a boundary.
FLIPWIN_FLIP_TICKS = 60
# Ticks between the unflip and the head reaching the ceiling. The ceiling
# HEIGHT is what sets this, and the rungs are spaced so the resolution near the
# 24-25 tick mark is about 7.5 px of ceiling per tick -- far off the apex,
# where a parabola has no resolution at all.
FLIPWIN_RUNGS = [10, 16, 20, 22, 24, 26, 28, 32, 40]
# Gravity per tick at 0.9x, by mode. Only the cube's is measured here
# (speed.hpp kCubeG, 0.216, twice at two places in lv15); the robot's 0.195
# appears in a force-block note but not at this speed, and a rig built on a
# gravity that is out by a percent puts the yellow portal in the wrong place.
# Add a mode here only with a measurement to hand.
FLIPWIN_G = {"cube": 0.216}


def build_flipwin(mode: str = "cube", mini: bool = False,
                  armed: bool = False) -> str:
    """The flip-window ladder. `armed` puts an 1859 under every ceiling.

    The armed pair is the other half of the experiment: the bonk whitelist has
    an 1859 arm AND a flip-grace arm, and a bonk seen on one rig alone cannot
    say which of them produced it. Two rigs differing by that object separate
    them the way the kA39 pair separates the saw branches.

    Rungs run in increasing delay, so one natural pass walks the ladder and --
    if the window is real -- dies at the first rung outside it. The death x
    names the boundary with no bisection at all.
    """
    if mode not in FLIPWIN_G:
        raise SystemExit(f"flipwin: no measured gravity for {mode!r} at 0.9x - "
                         f"measure it before generating this rig "
                         f"(have: {sorted(FLIPWIN_G)})")
    dx = 1.29825044                      # 0.9x, speed.hpp kDxF
    g = FLIPWIN_G[mode]
    half = 9.0 if mini else 15.0
    n = FLIPWIN_FLIP_TICKS
    stand_y = GROUND_TOP + half          # the player's centre on the floor
    # inverted for n ticks: vy climbs by g each tick, and the rise is the sum
    rise_flip = g * n * (n - 1) / 2.0
    vy_unflip = g * n
    y_unflip = stand_y + rise_flip
    parts = [header(start_mode=mode, mini=mini)]
    parts += floor_run(0, FLIPWIN_PITCH * (len(FLIPWIN_RUNGS) + 4), y=GROUND_Y)
    for i, k in enumerate(FLIPWIN_RUNGS):
        x0 = 900.0 + FLIPWIN_PITCH * i
        x_yellow = x0 + n * dx
        # after the unflip, gravity is down again and vy bleeds off by g a tick
        rise_after = vy_unflip * k - g * k * (k - 1) / 2.0
        ceil_bottom = y_unflip + rise_after + half
        parts.append(obj(GRAV_FLIP, x0, stand_y))
        # ...on the computed parabola. Blue = id 11 (inverse), yellow = id 10
        # (normal): written the other way round once, and the symptom was the
        # player running the whole level along the ceiling
        parts.append(obj(GRAV_NORM, x_yellow, y_unflip))
        for b in range(3):
            parts.append(obj(BLOCK, x_yellow + GRID * b, ceil_bottom + GRID / 2))
            if armed:
                # lv22 puts its 1859s 15 px under the ceiling they arm
                # (cy 2,055 against an underside of 2,070)
                parts.append(obj(FLIP_ARM_ID, x_yellow + GRID * b,
                                 ceil_bottom - 15.0))
        UNITS.append({"rung": i, "delay_ticks": k, "x_blue": x0,
                      "x_yellow": round(x_yellow, 3),
                      "y_yellow": round(y_unflip, 3),
                      "ceil_bottom": round(ceil_bottom, 3), "armed": armed,
                      "what": "ticks between the UNFLIP and the head reaching "
                              "this ceiling, if the gravity constant holds. "
                              "The real delay comes from the dump; these "
                              "numbers only have to bracket the boundary"})
    # The THIRD BEHAVIOUR, which is neither a bonk nor a kill: an inverted
    # player driven head-first into a block's TOP face was measured sinking 7 px
    # in and carrying on down. It has no home in the model and none in the
    # disassembly yet. These are bare blocks in open air with a clear column
    # above, for an injection probe (inverted, descending) -- nothing about the
    # ladder reaches them.
    for j, y in enumerate((400.0, 700.0)):
        x = 900.0 + FLIPWIN_PITCH * (len(FLIPWIN_RUNGS) + j + 1)
        for k in range(4):
            parts.append(obj(BLOCK, x + GRID * k, y))
        UNITS.append({"rung": -1 - j, "x_block": x, "block_cy": y,
                      "what": "third-behaviour station: inject an INVERTED "
                              "player above this, descending, and watch "
                              "whether it passes through the top face"})
    return ";".join(parts) + ";"


def build_cpride() -> str:
    """A floor that RISES while the player stands on it, for checkpoint work.

    The open question here is that obj+0x4d0/0x4d4 -- the position the rotation
    pass snaps at the head of a tick, and the source of the speed a surface
    carries its rider at -- is saved into m_vectorSavedObjectStateRef but not
    written back on a restore. Whether that matters was never measured, and it
    can only matter where something is being carried, so the rig makes the
    player a rider for the whole run: the floor itself is the moving group.

    Slow and long (150 px over 20 seconds) so that any tick is mid-carry. The
    floor starts AT the player's own level and rises from there -- a first cut
    put it 60 px up, where the player simply ran along GD's own ground
    underneath it and was never a rider at all (the checkpoint printed y=105).
    """
    G = 30
    parts = [header(start_mode="cube")]
    x = 0.0
    while x <= 9000:
        parts.append(obj(BLOCK, x, GROUND_Y, extra={K_GROUPS: str(G)}))
        x += GRID
    parts.append(obj(TRIG_MOVE, 45, 300, extra={
        K_TARGET: str(G),
        K_DURATION: "20",
        K_MOVE_X: "0",
        K_MOVE_Y: "150",
        K_EASING: "0",
        K_EASING_RATE: "2",
    }))
    return ";".join(parts) + ";"


def build_cpriderot() -> str:
    """cpride's sibling: the floor is ROTATED, not translated.

    obj+0x4d0/0x4d4 is written by the ROTATION pass (survey E1), so a floor that
    merely slides does not exercise it -- measured, and a rider on a sliding
    floor comes back from a restore exact over 599 ticks. This one turns the
    whole floor slowly about a centre far below, so the surface sweeps upward
    and carries the rider while the rotation pass is the thing moving it.

    Five degrees about a centre 2,000 px down is roughly 180 px of arc over the
    twenty seconds -- the same order as the sliding rig, so the two are
    comparable.
    """
    G_ROT, G_CEN = 31, 32
    parts = [header(start_mode="cube")]
    x = 0.0
    while x <= 9000:
        parts.append(obj(BLOCK, x, GROUND_Y, extra={K_GROUPS: str(G_ROT)}))
        x += GRID
    parts.append(obj(BLOCK, 4500, GROUND_Y - 2000, extra={K_GROUPS: str(G_CEN)}))
    parts.append(obj(TRIG_ROTATE, 45, 300, extra={
        K_TARGET: str(G_ROT),
        K_CENTER: str(G_CEN),
        K_DURATION: "20",
        K_DEGREES: "5",
        K_TIMES360: "0",
        K_LOCKROT: "0",
        K_EASING: "0",
        K_EASING_RATE: "2",
    }))
    return ";".join(parts) + ";"


def build_cprot() -> str:
    """A rotate AND a move in flight on the SAME group, for checkpoint work.

    The question here is whether a mid-flight action survives a checkpoint
    restore. Two Moves on separate groups already came back exact; the classes
    still untested are a Rotate and two actions on one group, and this rig is
    both at once -- which is also the shape lv21 and lv22 are full of.

    Laid out like lv21 uid15367: the object is in the ROTATED group and in the
    MOVED group, the centre is in the CENTRE group and the same MOVED group, so
    the whole figure slides while the object goes round it. Eight seconds of
    travel each, so a checkpoint anywhere in the first 1,900 ticks catches both
    actions mid-flight.
    """
    G_ROT, G_CEN, G_MOVE = 20, 21, 22
    parts = [header(start_mode="cube")]
    parts += floor_run(0, 9000, y=GROUND_Y)
    # the orbiting block (rotated and moved) and its pivot (centre and moved)
    parts.append(obj(BLOCK, 2000, 420, extra={K_GROUPS: f"{G_ROT}.{G_MOVE}"}))
    parts.append(obj(BLOCK, 2000, 300, extra={K_GROUPS: f"{G_CEN}.{G_MOVE}"}))
    parts.append(obj(TRIG_ROTATE, 45, 300, extra={
        K_TARGET: str(G_ROT),
        K_CENTER: str(G_CEN),
        K_DURATION: "8",
        K_DEGREES: "0",
        K_TIMES360: "1",
        K_LOCKROT: "0",
        K_EASING: "0",
        K_EASING_RATE: "2",
    }))
    parts.append(obj(TRIG_MOVE, 45, 300, extra={
        K_TARGET: str(G_MOVE),
        K_DURATION: "8",
        K_MOVE_X: "0",
        K_MOVE_Y: "150",
        K_EASING: "0",
        K_EASING_RATE: "2",
    }))
    return ";".join(parts) + ";"


def build_expease() -> str:
    """Where do GD's Exponential easings actually STOP?

    Three blocks, one per easing, all given the SAME offset by their own Move
    trigger, all firing at the same x. Reading the three terminals against each
    other answers the question without needing the unit of the move offset:

        ExpIn (11)   ends at 0.999 of the offset -- cocos subtracts 0.001 and
                     the object stays a tenth of a percent short, forever
        ExpOut (12)  ends exactly, because GD special-cases t==1
        ExpIO (10)   the insurance row: neither quirk is supposed to be inside
                     it, so it should follow the model's curve -- which itself
                     ends at 0.99951, not at 1

    MEASURED (2026-09-01): 299.700 / 300.000 / 299.821 of a 300 offset. The
    first two are the prediction exactly. The third is NOT a terminal: the
    recorder stops writing once the move drops under its epsilon, and 299.821
    is u=0.985 on that curve, so this rig sees ExpIO mid-tail and cannot read
    its endpoint. It is consistent with the model and contradicts nothing, but
    an ExpIO endpoint needs a probe that does not depend on the recorder.

    ExpIn is worth measuring here and nowhere else -- it is used ZERO times in
    all 22 official levels, so a rig is the only place it can be confirmed.

    Two seconds of travel, well inside the run, so every block is parked at its
    terminal for most of the recording rather than caught mid-curve.
    """
    parts = [header(start_mode="cube")]
    parts += floor_run(0, 9000, y=GROUND_Y)
    # one block per easing, far apart so grouptrace rows cannot be confused
    for k, (grp, x) in enumerate(((11, 2000), (12, 3000), (13, 4000))):
        parts.append(obj(BLOCK, x, 300, extra={K_GROUPS: str(grp)}))
    for grp, ease in ((11, 11), (12, 12), (13, 10)):
        parts.append(obj(TRIG_MOVE, 45, 300, extra={
            K_TARGET: str(grp),
            K_DURATION: "2",
            K_MOVE_X: "0",
            K_MOVE_Y: "300",
            K_EASING: str(ease),
            K_EASING_RATE: "2",
        }))
    return ";".join(parts) + ";"


def build_sawcal_moved(mode: str, mini: bool = False) -> str:
    """sawcal with every saw carried by an autonomous Move trigger.

    The move is slow and vertical (the stations keep their x, so a dx=0 column
    -- where the two branches differ most -- is still reachable by injecting y
    alone), and long enough that the saws are STILL ANIMATING across the whole
    probe window rather than parked at the end of their travel.
    """
    parts = [header(start_mode=mode, mini=mini)]
    parts += floor_run(0, 9000, y=GROUND_Y)
    for k in range(12):
        parts.append(obj(BLOCK, 230, 105 + GRID * k))
    for oid, x, scale in SAWCAL_STATIONS:
        extra = {K_GROUPS: str(SAW_GROUP)}
        parts.append(obj(oid, x, 300, scale=scale, extra=extra))
    # x=45, NOT past the wall at 230. Probes reach a station by injecting x, and
    # the trigger has to have fired BEFORE that: the natural attempt dies on the
    # wall at x=211, so anything placed beyond it never fires at all (measured --
    # the first cut put this at 500 and the dump came back with the trigger read
    # correctly and the saws never moving). At 1x the player crosses x=45 around
    # t=35, well before any probe tick.
    #
    # 10 s of travel keeps the saws ANIMATING across every probe tick rather than
    # parked at the end. The displacement at any tick is small but not zero, so
    # the probe reads the saw's position out of grouptrace instead of predicting
    # it -- which also sidesteps the unverified unit of the move offset.
    parts.append(obj(TRIG_MOVE, 45, 300, extra={
        K_TARGET: str(SAW_GROUP),
        K_DURATION: "10",
        K_MOVE_X: "0",
        K_MOVE_Y: "120",
        K_EASING: "0",
        K_EASING_RATE: "2",
    }))
    return ";".join(parts) + ";"


# ---- A dual whose two halves are NOT in the same mode (2026-08-28) ---------
# WHY. The anchor seeds the second body's mode from the first
# (dp/src/dp/cli.hpp, `init.mode2 = init.mode`) because the mod's dump carried
# one mode column for the pair, and justifies it as "they differ for at most the
# tick between one clearing a mode portal's window and the other reaching it".
# With p2mode/p2vsize emitted that became measurable, and on lv16's solution the
# two never differ across 5,557 dual ticks -- so the assumption holds for the
# OFFICIAL corpus. It is not true in general: in custom levels, which this solver
# already clears cold, differing modes and sizes between the halves are ordinary.
#
# Rather than hunt for a custom level, build the case. A dual ship with no input
# separates on its own -- the first body falls to the floor, the second (flipped)
# climbs -- so a portal placed at FLOOR height is taken by one half and never
# reached by the other. Each station changes exactly one thing about the first
# body and leaves the second alone, which is what makes the dump columns readable
# as an answer.
#
# The third question the rig is for is whether the two can differ in X at all.
# The model gives the pair a single x (State::xAbs, which swapHalves does not
# swap), so that case would not be mis-modelled but unrepresentable. p2x is
# emitted alongside; this rig is where "always equal" gets its first evidence.
# ---- Force blocks (2026-08-30) ---------------------------------------------
# WHY. The push strength was a table keyed on m_uniqueID (level_loader.hpp), and
# a uid is level-specific by construction: a custom level's force block gets the
# default and is simply wrong. ForceBlockGameObject carries the strength as a
# member, and dividing the model's measured k by the m_force the game reports
# collapses the whole table:
#
#     uid     model k   m_force   k/m_force   mode (read off the g in each note)
#     11412    0.283      1.4      0.20214    robot   (-0.195)
#     14472    0.304      1.5      0.20267    robot   (-0.195)
#     17701    0.330      1.63     0.20245    robot   (-0.195)
#     14472    0.159      1.5      0.10600    ship    (-0.103)
#     17701    0.172      1.63     0.10552    ship    (-0.069)
#     carpet   0.108      1.2      0.09000    swing
#     17581    0.270      2 (max)  0.13500    ball
#
# Three independent objects agree to 0.26% for the robot and two to 0.5% for the
# ship, so dvy = m_force * C(mode) and the per-uid AND per-mode table was that
# one division written out longhand. C is known for four modes from lv22 alone.
# This rig is where the other four come from, and it also closes three things
# lv22 cannot answer with one instance each: whether C depends on scale (17701
# is 5.1x3.9 and agrees with the scale-1 boxes, but that is a single reading),
# whether m_force is linear (every value in lv22 is between 1.2 and 4.2), and
# the rot=180 mirror, which is an OPEN at both kFF2069 and kFF3645Max because
# lv22 has no force block that is rotated the other way.
#
# The keys come from ForceBlockGameObject::customObjectSetup (win 0x4c1d30),
# which indexes `values` (gd::string, 0x20 each) and `exists` (void*, 8 each) in
# parallel -- both divisions give the same six numbers, which is what makes them
# read rather than guessed.
FKEY_FORCE, FKEY_MIN, FKEY_MAX = 149, 526, 527
FKEY_RELATIVE, FKEY_RANGE, FKEY_ID = 528, 529, 530
FORCE_BOX, FORCE_FIELD = 2069, 3645

# (x, id, m_force, scale, rot, (min,max) when m_forceRange is set)
# Stations 1000px apart at y=300 with nothing within 900px: the sawcal geometry,
# for the same reason. The probes inject a state inside a box and read dvy, so a
# polluted approach line makes the reading meaningless. The default scale is 3
# (90x90) so an injected point sits well inside; the two scale stations are the
# ones that vary it.
FORCE_STATIONS = [
    (2000, FORCE_BOX,   1.0, 3.0,   0.0, None),          # baseline
    (3000, FORCE_BOX,   2.0, 3.0,   0.0, None),          # is m_force linear?
    (4000, FORCE_BOX,   1.0, 1.0,   0.0, None),          # does scale enter?
    (5000, FORCE_BOX,   1.0, 5.0,   0.0, None),          # ...at the other end
    (6000, FORCE_BOX,   1.0, 3.0, 180.0, None),          # the box mirror
    (7000, FORCE_FIELD, 1.0, 3.0, 180.0, (0.0, 2.0)),    # the lerp, as 17581
    (8000, FORCE_FIELD, 1.0, 3.0,   0.0, (0.0, 2.0)),    # the field mirror
]


def build_forcecal_mode(mode: str, mini: bool = False) -> str:
    """THIS RIG DOES NOT MEASURE THE FORCE. Kept for what it proves instead.

    Every station reads a push of EXACTLY ZERO under injected probes, in every
    mode. The field is not broken: the push is applied inside checkCollisions'
    object loop (0x215b4e), and an injection teleports the player 2,370 px in one
    tick, so the candidate list the loop walks was built somewhere else and does
    not contain the box. calib_forcedrop_* walks the player in instead and reads
    the field immediately.

    So this is the control that establishes "injection does not reach this
    mechanism" -- worth keeping, because the same reasoning applies to anything
    else resolved in that loop, and because a zero from an injected probe is
    otherwise indistinguishable from a zero force.
    """
    parts = [header(start_mode=mode, mini=mini)]
    parts += floor_run(0, 10000, y=GROUND_Y)
    # Same as sawcal: with no input the run slides along the flush floor ALIVE
    # and completes the level, and a completed session stops polling cmd.txt.
    for k in range(12):
        parts.append(obj(BLOCK, 230, 105 + GRID * k))
    for x, oid, force, scale, rot, rng in FORCE_STATIONS:
        extra = {FKEY_FORCE: f"{force:g}"}
        if rng is not None:
            extra[FKEY_RANGE] = "1"
            extra[FKEY_MIN] = f"{rng[0]:g}"
            extra[FKEY_MAX] = f"{rng[1]:g}"
        parts.append(obj(oid, x, 300, rot=rot, scale=scale, extra=extra))
    return ";".join(parts) + ";"


# The control for forcecal. The injected probes on that rig read a force of
# EXACTLY ZERO at every station, and an injection teleports the player 2,370 px
# in one tick -- the force is applied inside checkCollisions' object loop
# (0x215b4e), so a candidate list built for the old position would explain a
# zero without the field being wrong at all. Here the player reaches the box by
# walking: the floor stops at a ledge and the box straddles the fall, so nothing
# is injected and nothing is teleported. If dvy still does not move, the field
# is not firing for a reason that has nothing to do with the probes.
def build_forcedrop_mode(mode: str, mini: bool = False,
                         force: float = 1.0) -> str:
    """...and `force` is the whole point of the variants.

    dvy = m_force * |g| / D, and D could not be pinned from the m_force=1 rigs
    at all: the term is 0.09..0.225 there, GD's vy is on the 0.001 grid, so
    every reading carries 0.5-1% and the D backed out of the corpus scatters
    over 0.9556..0.9647 -- exactly that width. At m_force=10 the term is ~2.25
    and the same 0.001 is 0.04%, which separates those. The ladder of forces
    also settles whether m_force is linear at all, which no lv22 value shows
    (they run 1.2..4.2 and each is one point).
    """
    parts = [header(start_mode=mode, mini=mini)]
    # A gap from 300 to 700 with the floor resuming after it. The level still
    # has to be a level: the 439-char first cut (a ledge and nothing else) never
    # reached `serve: loaded` at all.
    parts += floor_run(0, 300, y=GROUND_Y)
    parts += floor_run(700, 4000, y=GROUND_Y)
    # 30 px grid, scale 10 -> 300x300 centred on the run height, so the fall off
    # the ledge at x=300 enters it at x=350 and leaves at x=650.
    parts.append(obj(FORCE_BOX, 500, GROUND_Y, scale=10.0,
                     extra={FKEY_FORCE: f"{force:g}"}))
    # AND THE WALL, past the box. The first cut left it out and the no-input
    # attempt COMPLETED the level (tick 3112, x=4390) -- which ends the session,
    # so every later run got "no serve: loaded" and the rig looked broken. It is
    # the same trap the sawcal note spells out; the wall has to be somewhere the
    # run reaches AFTER the thing being measured.
    # ...and it has to be TALL. At 12 blocks (435 px) the same trap came back for
    # m_force=10 only: f3 climbs into the wall, f10 sails over it and completes,
    # f30 leaves the world before it gets there -- so two rigs out of five failed
    # to load and the two looked like bad levels rather than one short wall.
    # 120 blocks clears any force this rig will be asked for.
    for k in range(120):
        parts.append(obj(BLOCK, 1000, 105 + GRID * k))
    return ";".join(parts) + ";"


# ---- Speed bands (2026-08-30) ----------------------------------------------
# cubePhysFor and ship_params both carry an UNMEASURED row for GD's 1.6 (the 4x
# portal), and the note at cubePhysFor says it "falls back" to the 0.7 row --
# which cannot be right, because the first branch there is `dxF > 1.78` and 4x is
# faster than 3x. One of the two is wrong and the level is the only place to ask.
#
# A plain floor and nothing else. The plan presses once, so one run gives the
# jump (the vy the press produces) and the gravity (the dvy of the arc after it)
# together, at whatever dx the game reports for the band.
# The one level the solver must REFUSE. kA22 is the platformer flag: identified
# by writing it into a working rig and asking the game (kA23 on the same rig
# leaves it an ordinary level, which is the control -- there the solver takes its
# normal path and reports that it cannot solve, rather than refusing).
#
# It is built from its own header rather than through a `platformer` argument to
# header(), deliberately. The note there says kA22-kA45 CHANGE THE PHYSICS, and a
# flag on the shared header is an invitation to set it on a physics rig and
# measure a different game.
def build_platformer() -> str:
    parts = [header(start_mode="cube") + ",kA22,1"]
    parts += floor_run(0, 4000, y=GROUND_Y)
    return ";".join(parts) + ";"


def build_speedcal(mode: str, speed: int, mini: bool = False) -> str:
    parts = [header(start_mode=mode, mini=mini, speed=speed)]
    parts += floor_run(0, 12000, y=GROUND_Y)
    # The wall is far out and tall: at 4x the run covers ground fast, and a
    # completed level ends the session (the trap the sawcal note spells out).
    for k in range(120):
        parts.append(obj(BLOCK, 6000, 105 + GRID * k))
    return ";".join(parts) + ";"


def build_dualmode() -> str:
    parts = [header(start_mode="ship", mini=False, dual=True)]
    parts += floor_run(0, 9000, y=GROUND_Y)
    # No wall here: the run has to REACH the stations, and the session ends by
    # completing the level rather than by dying on the way in.
    #
    # Every station sits at floor height. With no input the first body rests at
    # y=105 and the second climbs away, so the first takes them all and the
    # second keeps what it started with.
    parts.append(obj(P_CUBE, 1500, 105))      # p1 -> cube, p2 stays ship
    parts.append(obj(SIZE_MINI, 3000, 105))   # p1 -> mini, p2 stays normal
    parts.append(obj(P_BALL, 4500, 105))      # p1 -> ball
    parts.append(obj(P_SHIP, 6000, 105))      # ...and back, to see it swap twice
    return ";".join(parts) + ";"


def build_minhdr() -> str:
    """For triage: minimal header + floor. Which header key is causing trouble."""
    h = "kA2,0,kA3,0,kA4,0,kA6,1,kA7,1,kA8,0,kA10,0,kA13,0"
    return h + ";" + ";".join(floor_run(0, 6000, y=GRID / 2)) + ";"


# ---- Calibration rig for slope attachment conditions (2026-08-19) -------
PAD_YELLOW = 35

# Downhill floor slopes (probe measurement 2026-08-19: the solid is below the
# line in every case)
#   |m|=0.5: id1744 rot0 flipX  -> w60 h30, sy0=cy+15, sdir 2
#   |m|=1.0: id1743 rot0 flipX  -> w30 h30, sy0=cy+15, sdir 2
#   |m|=2.0: id1744 rot90 plain -> w30 h60, sy0=cy+30, sdir 4
DOWNRAMP = {0.5: (SLOPE60A, 0.0, True, False, 60.0, 30.0),
            1.0: (SLOPE30, 0.0, True, False, 30.0, 30.0),
            2.0: (SLOPE60A, 90.0, False, False, 30.0, 60.0)}

# The arc after a pad launch (fed in from a pass1 dump via --arc).
# (dt, dx, y, vy): tick relative to the launch tick / relative x / ABSOLUTE y / vy.
# The arc is identical for every unit (the same pad is entered in the same
# grounded state), so a single one suffices.
SL_ARC: list[tuple[int, float, float, float]] = []
SL_FIRE_DX = 0.0        # launch x - pad centre (measured in pass1)
SL_PITCH = 20 * GRID    # unit pitch. MUST NOT DEPEND ON ARC (identical in pass1/2)
SL_MODE = "cube"        # player mode for the slopeland family (ball for slopelandball)
SL4_SPEED = 0           # kA4 for slopeland4 (0=1x, 2=2x = the corpus' sp1.1)


def sl_pad_cx(k: int) -> float:
    return 90.0 + k * SL_PITCH + 6 * GRID


def load_arc(dump: Path) -> None:
    u"""Take the arc from a pass1 dump. The launch = the row where vy jumps by
    +8 or more in one tick. The rig takes zero input, so nothing but a pad can
    produce an upward jump beyond +8."""
    import csv as _csv
    global SL_FIRE_DX
    rows = []
    with dump.open(newline="", encoding="utf-8-sig", errors="replace") as f:
        for r in _csv.DictReader(f):
            try:
                rows.append((int(r["tick"]), float(r["x"]), float(r["y"]),
                             float(r["yvel"]), r.get("onGround", "0")))
            except (ValueError, KeyError):
                continue
    fire = None
    for i in range(1, len(rows)):
        if rows[i][3] - rows[i - 1][3] > 8.0 and rows[i][3] > 8.0:
            fire = i
            break
    if fire is None:
        raise SystemExit("--arc: no launch found (vy never jumps by +8)")
    t0, x0 = rows[fire][0], rows[fire][1]
    SL_FIRE_DX = x0 - sl_pad_cx(0)
    for i in range(fire, len(rows)):
        t, x, y, vy, og = rows[i]
        if i > fire and og == "1":
            break
        SL_ARC.append((t - t0, x - x0, y, vy))
    print(f"arc: {len(SL_ARC)} tick, fire_dx={SL_FIRE_DX:+.2f}, "
          f"apex={max(y for _, _, y, _ in SL_ARC):.1f}, "
          f"vy at the end {SL_ARC[-1][3]:.2f}")


def sl_place(m: float, vy_target: float, pH: float
             ) -> tuple[float, float, float, float, float] | None:
    u"""Place the slope at "the first descending point on the arc where vy drops
    to this value or below", so that its centre straddles the seat plane
    (line + pH*sqrt(1+m^2)). If the low end would reach the ground, walk back up
    the arc and re-place it at a shallower point. Returns (cx, cy, w, h, vyA)."""
    mm = abs(m)
    oid, rot, fx, fy, w, h = (DOWNRAMP if m < 0 else RAMP)[mm]
    idx = None
    for i, (dt, dx, y, vy) in enumerate(SL_ARC):
        if vy <= vy_target:
            idx = i
            break
    if idx is None:
        return None
    for i in range(idx, 0, -1):
        dt, dxA, yA, vyA = SL_ARC[i]
        if vyA >= 0:
            return None
        xa_rel = dxA                    # relative to the launch point
        xs_rel = xa_rel - 0.30 * w      # the straddle point is 30% from the left edge
        cx_rel = xs_rel + w / 2.0
        cy = (yA - pH * math.sqrt(1.0 + mm * mm)) - m * (xa_rel - cx_rel)
        if cy - mm * w / 2.0 >= GROUND_TOP + 3.0:
            return cx_rel, cy, w, h, vyA
    return None


def build_slopeland() -> str:
    u"""Calibration rig for SLOPE ATTACHMENT CONDITIONS. Zero input. cube only (v1).

    The foundation for lv16 t=5,923 (GD SNAPS A FALLING CUBE DOWNWARD onto a
    downhill slope) and for ceiling-ramp attachment (the most important census
    node). Exactly one quantity is measured: WHERE ON THE FALLING BOX GD SEATS
    THE PLAYER ON THE TICK THE LINE IS CROSSED (candidates: bottom-left corner /
    bottom of centre / bottom-right corner / centre against the seat plane). The
    spacing between candidates (2-23px) is wider than one tick of y (0.7-3.3px),
    so scattering the fractional part of the crossing with a phase delta lets a
    single run tell them apart.

    Unit = [yellow pad][arc][a downhill slope LEFT FLOATING]. No support is
    placed (the support's left face becomes a wall and kills). Once seated, the
    player slides off the low end back to the ground and walks to the next unit.

    Geometric constraint: unless the falling arc's gradient (vy*0.225/1.298
    px/px) is steeper than m, the player cannot land on a downhill slope (a
    shallow one diverges). So the vy target is per m: from -4 for |m|=0.5, from
    -7 for |m|=1, from -12.5 for |m|=2.
    A grazing intersection where the arc gradient ~ m has a relative approach of
    under 0.3px per tick = the sample that brackets the threshold most finely,
    so one is deliberately placed at the head of each m.

    BUILD IT IN TWO PASSES:
      pass1: no --arc = a pad-only rig. Run it and measure the arc
      pass2: rebuild with the slopes using --arc <the dump.csv from pass1>
    """
    objs: list[str] = []
    objs += floor_run(0, PAVE_X)
    if SL_MODE != "cube":
        objs.append(obj(MODE_PORTAL[SL_MODE], 45.0, GROUND_TOP + 15.0))
    combos: list[dict] = []
    targets = {0.5: (-4.0, -6.0, -9.0, -13.0),
               1.0: (-7.0, -9.0, -11.0, -13.0),
               2.0: (-12.5, -13.5, -14.5)}
    for mm, vys in targets.items():
        for vyt in vys:
            for d in (0.0, 0.4, 0.8):
                combos.append({"m": -mm, "vyt": vyt, "d": d})
    # The uphill control (the conditions for landing on an uphill slope from a fall)
    for mm in (0.5, 1.0):
        for d in (0.0, 0.4):
            combos.append({"m": mm, "vyt": -9.0, "d": d})
    pH = 15.0
    for k, c in enumerate(combos):
        x0 = 90.0 + k * SL_PITCH
        pad = sl_pad_cx(k)
        objs.append(obj(PAD_YELLOW, pad, GROUND_TOP + 5.0))
        u = {"x0": x0, "x1": x0 + SL_PITCH, "pad": pad, "mode": SL_MODE,
             "m": c["m"], "vyt": c["vyt"], "d": c["d"], "mini": 0}
        if SL_ARC:
            got = sl_place(c["m"], c["vyt"], pH)
            if got is None:
                print(f"  unit {k} (m={c['m']}, vy={c['vyt']}): "
                      f"no room on the arc -- slope skipped")
            else:
                cx_rel, cy, w, h, vyA = got
                cx = pad + SL_FIRE_DX + cx_rel
                cy += c["d"]
                oid, rot, fx, fy, _w, _h = (DOWNRAMP if c["m"] < 0
                                            else RAMP)[abs(c["m"])]
                objs.append(obj(oid, cx, cy, rot=rot, flip_x=fx, flip_y=fy))
                u.update({"cx": cx, "cy": cy, "w": w, "h": h, "vyA": vyA})
        UNITS.append(u)
    return header() + ";" + ";".join(objs) + ";"


def build_slopeland3() -> str:
    u"""Rig measuring THE RIDE-TIME DEPENDENCE OF THE RECTANGLE-TOP CLAMP.
    Zero input, cube, 1x.

    Measured on lv16: on the tick where the centre of a downhill ride crosses
    the top of the slope's rectangle (cy+hh), GD clamps to it for exactly 1
    tick -- but there are sites that do it (22 ticks into the ride,
    uid2292/2293/2865) and sites that do not (12 ticks in, uid2580). The
    geometry is a perfect clone (id/sdir/sup/rot/flip all identical), so the
    discriminator must be dynamic state = the ride-time hypothesis. The boundary
    is somewhere in (12, 22].

    Unit = [yellow pad][arc][2 chained downhill ramps (m=-0.5, w60)]. Placing
    the mid-air attachment height "0.649*K px above the top crossing" makes the
    ride at the crossing K ticks. The second of the pair is crossed too, so one
    unit yields two samples, K and K+46.
    Detection is y == cy+hh (GD emits a round value such as 270.000 for 1 tick).
    """
    objs: list[str] = []
    objs += floor_run(0, PAVE_X)
    combos = [(k, 0.0) for k in (4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24)]
    combos += [(12, 0.3), (16, 0.3), (20, 0.3)]
    pH = 15.0
    m = -0.5
    oid, rot, fx, fy, w, h = DOWNRAMP[0.5]
    for kk, c in enumerate(combos):
        K, d = c
        x0u = 90.0 + kk * SL_PITCH
        pad = sl_pad_cx(kk)
        objs.append(obj(PAD_YELLOW, pad, GROUND_TOP + 5.0))
        u = {"x0": x0u, "x1": x0u + SL_PITCH, "pad": pad, "K": K, "d": d,
             "mode": "cube", "m": m, "mini": 0}
        if SL_ARC:
            got = sl_place(m, -9.0, pH)
            if got is None:
                print(f"  unit {kk}: no room on the arc")
            else:
                # Taking sl_place's seat point (the x where the centre crosses
                # the seat plane) as the reference, re-derive the ramp's
                # vertical position so the ride up to the crossing is K ticks.
                # The line at the seat x: seat - pH*sqrt(1+m^2).
                # rTop = sy0 = seat y - 0.649K
                # So the seat x falls inside the span: x0 = xa - xoff - (33.54 - 1.298K)
                cx_rel, cy0, ww, hh, vyA = got
                dxA = None
                for dt, dx, y, vy in SL_ARC:
                    if vy <= -9.0:
                        dxA, yA = dx, y
                        break
                xa = pad + SL_FIRE_DX + dxA
                xoff = pH * math.tan(math.atan(0.5) / 2.0)
                xs1 = xa - xoff - (33.54 - 1.298 * K)
                sy0 = yA - 0.649 * K + d
                cy1 = sy0 - 15.0
                if cy1 - 15.0 - 30.0 - h / 2.0 < GROUND_TOP:
                    print(f"  unit {kk} (K={K}): too low, skipped")
                else:
                    objs.append(obj(oid, xs1 + w / 2.0, cy1, rot=rot,
                                    flip_x=fx, flip_y=fy))
                    objs.append(obj(oid, xs1 + w + w / 2.0, cy1 - 30.0,
                                    rot=rot, flip_x=fx, flip_y=fy))
                    u.update({"xs1": xs1, "cy1": cy1, "w": w,
                              "rtop1": cy1 + 15.0, "rtop2": cy1 - 15.0,
                              "yA": yA})
        UNITS.append(u)
    return header() + ";" + ";".join(objs) + ";"


def build_slopeland4() -> str:
    u"""RIG THAT SWEEPS THE RECTANGLE-TOP CLAMP GATE OVER |m| AND MODE
    (a generalisation of slopeland3).

    slopeland3 pinned m=-0.5 and cube and swept only K (the ride ticks up to the
    crossing), which produced the gate "descent >= pH*sqrt(1+m^2)". But THE
    CORPUS CONTRADICTS IT (measured 2026-08-19: the clamping cases
    8.07/14.53/28.55 and the pass-through cases 8.88/12.98/19.37/38.7 perfectly
    interleave by descent).
    This rig is 3 values of |m| x 6 values of K x 2 ramps, so |m| can be swept
    with the descent held fixed (the same descent occurs at a different K for
    each |m|).
    The ball version is `slopeland4ball`.

    Two passes: pass1 = no --arc (pad only) -> run it and capture the arc;
    pass2 = --arc <pass1 dump.csv>.
    """
    objs: list[str] = []
    objs += floor_run(0, PAVE_X)
    if SL_MODE != "cube":
        objs.append(obj(MODE_PORTAL[SL_MODE], 45.0, GROUND_TOP + 15.0))
    pH = 15.0
    # kA4: 0=1x (dx 1.298) / 2=2x (dx 1.6143). The corpus' sp1.1 is the latter.
    dx = 1.6143 if SL4_SPEED == 2 else 1.298
    vyt = {0.5: -4.0, 1.0: -7.0, 2.0: -12.5}
    combos: list[dict] = []
    for mm in (0.5, 1.0, 2.0):
        for K in (4, 8, 12, 16, 20, 24):
            combos.append({"mm": mm, "K": K})
    for kk, c in enumerate(combos):
        mm, K = c["mm"], c["K"]
        oid, rot, fx, fy, w, h = DOWNRAMP[mm]
        x0u = 90.0 + kk * SL_PITCH
        pad = sl_pad_cx(kk)
        objs.append(obj(PAD_YELLOW, pad, GROUND_TOP + 5.0))
        u = {"x0": x0u, "x1": x0u + SL_PITCH, "pad": pad, "K": K,
             "mode": SL_MODE, "m": -mm, "mini": 0,
             "descent": mm * dx * K}
        if SL_ARC:
            got = sl_place(-mm, vyt[mm], pH)
            if got is None:
                print(f"  unit {kk} (m=-{mm}, K={K}): no room on the arc")
            else:
                dxA = yA = None
                for dt, dxx, y, vy in SL_ARC:
                    if vy <= vyt[mm]:
                        dxA, yA = dxx, y
                        break
                xa = pad + SL_FIRE_DX + dxA
                xoff = pH * math.tan(math.atan(mm) / 2.0)
                # Re-place it at the vertical position that makes the ride up to
                # the crossing K ticks, so the seat x falls inside the span
                # (the generalisation of slopeland3)
                span = pH * math.sqrt(1.0 + mm * mm) / mm
                xs1 = xa - xoff - (span - dx * K)
                sy0 = yA - mm * dx * K
                cy1 = sy0 - h / 2.0
                if cy1 - h / 2.0 < GROUND_TOP + 3.0:
                    print(f"  unit {kk} (m=-{mm}, K={K}): too low, skipped")
                else:
                    objs.append(obj(oid, xs1 + w / 2.0, cy1, rot=rot,
                                    flip_x=fx, flip_y=fy))
                    u.update({"xs1": xs1, "cy1": cy1, "w": w, "h": h,
                              "rtop1": cy1 + h / 2.0, "yA": yA})
                    # A second ramp only if it fits (m=2 barely manages one)
                    if cy1 - h - h / 2.0 >= GROUND_TOP + 3.0:
                        objs.append(obj(oid, xs1 + w + w / 2.0, cy1 - h,
                                        rot=rot, flip_x=fx, flip_y=fy))
                        u["rtop2"] = cy1 - h / 2.0
        u["speed"] = SL4_SPEED
        UNITS.append(u)
    return header(SL_MODE, speed=SL4_SPEED) + ";" + ";".join(objs) + ";"


def build_slopeland4ball() -> str:
    u"""The ball version of slopeland4 (one ball portal at the head of the level)."""
    global SL_MODE
    SL_MODE = "ball"
    return build_slopeland4()


def build_slopeland4fast() -> str:
    u"""The 2x version of slopeland4 (dx 1.6143 = the corpus' sp1.1).

    On the rig (1x) the player does not fall at the |m|=0.5 seam, yet on the
    corpus' lv16@6,948 (m=-0.5, sp1.1) it does. This settles whether speed is
    the discriminator.
    """
    global SL4_SPEED
    SL4_SPEED = 2
    return build_slopeland4()


def build_slopelandball() -> str:
    u"""The ball version of slopeland (one ball portal at the head of the level).
    Measures whether a ball's attachment shares the cube's rules (seat plane
    +1.0 / entry side +0.5 / uphill asymmetry). The foundation for lv16 t=13,117
    (target 6) and lv22's ball corridor."""
    global SL_MODE
    SL_MODE = "ball"
    return build_slopeland()


def build_ceilpush() -> str:
    u"""Rig measuring HOW A CEILING RAMP PUSHES DOWN AND CARRIES AN UPRIGHT
    PLAYER. Zero input.

    The measurements at lv16 t=13,108-13,117 (ball) and lv18 t=3,007 (ship) both
    say "a descending ceiling ramp (sdir1) pushes on the head of an upright
    player and carries it at y = line - 12.728". 12.728 = 9*sqrt(2), which
    suggests the contact half-size is 9 (the player's box differs per purpose).
    Sweeping m separates 9*sqrt(1+m^2) from pH*sqrt(1+m^2) - constant. The
    release vy at the end of the carry (the ramp's low end) is measured at the
    same time (lv16 releases at -3.741).

    Unit = [yellow pad][arc][plateau (stacked blocks)][fall off the edge]
           [a descending ceiling ramp catches the head][release, down to ground].
    The plateau height is set by the apex of the pad's arc (a ball's arc is low,
    so at most 2 tiers).
    SL_MODE is switched to ball by ceilpushball.
    """
    objs: list[str] = []
    objs += floor_run(0, PAVE_X)
    if SL_MODE != "cube":
        objs.append(obj(MODE_PORTAL[SL_MODE], 45.0, GROUND_TOP + 15.0))
    blocks = 2 if SL_MODE == "ball" else 3
    ptop = GROUND_TOP + blocks * GRID          # top surface of the plateau
    mlist = (0.5, 1.0) if SL_MODE == "ball" else (0.5, 1.0, 2.0)
    combos = [{"m": mm, "d": d} for mm in mlist for d in (0.0, 0.4, 0.8)]
    for k, c in enumerate(combos):
        x0u = 90.0 + k * SL_PITCH
        pad = sl_pad_cx(k)
        objs.append(obj(PAD_YELLOW, pad, GROUND_TOP + 5.0))
        # The plateau: from a point clear of the arc's ascent, out to the edge
        px0, px1 = pad + 80.0, pad + 230.0
        xx = px0 + GRID / 2.0
        while xx < px1:
            for b in range(blocks):
                objs.append(obj(BLOCK, xx, GROUND_TOP + GRID / 2.0 + b * GRID))
            xx += GRID
        edge = px0 + GRID * ((px1 - px0) // GRID)   # the real edge (grid-rounded)
        mm = c["m"]
        oid, rot, fx, fy, w, h = CEIL_RAMP[mm]
        # Put the line's high end "just past the edge, 3px above the head"
        xs = edge + 6.0
        sy0 = ptop + 30.0 + 3.0 + c["d"]
        # CEIL_RAMP's line: sy0 (the high side, left) -> sy0 - m*w (right).
        # cy is the midpoint of that.
        cy = sy0 - mm * w / 2.0
        # Join A FLAT CEILING (underside = sy0) just before the ramp. Starting
        # with a bare ramp makes its left face a wall, killing on the tick the
        # head enters (measured on the first attempt). The lv16 site is also a
        # flat-ceiling-into-ramp join.
        xx = px1 - 2.5 * GRID
        while xx - GRID / 2.0 < xs:
            objs.append(obj(BLOCK, xx, sy0 + GRID / 2.0))
            xx += GRID
        objs.append(obj(oid, xs + w / 2.0, cy, rot=rot, flip_x=fx, flip_y=fy))
        UNITS.append({"x0": x0u, "x1": x0u + SL_PITCH, "pad": pad,
                      "mode": SL_MODE, "m": -mm, "d": c["d"], "mini": 0,
                      "edge": edge, "xs": xs, "w": w, "sy0": sy0,
                      "ptop": ptop})
    return header() + ";" + ";".join(objs) + ";"


def build_ceilpushball() -> str:
    global SL_MODE
    SL_MODE = "ball"
    return build_ceilpush()


MODE8 = ("cube", "ball", "robot", "spider", "ship", "ufo", "swing", "wave")


def ceilpush8_unit(x: float, mode: str, mm: float,
                   d: float = 0.0) -> tuple[list[str], float]:
    u"""One situation x one mode: "a descending ceiling ramp (sdir1) pushes down
    on the head of an upright player falling off an edge, carries it, and
    releases it at the low end". Zero input, non-lethal.

    [mode portal][run-up][3 uphill 0.5 ramps (+90px)][plateau (no gap = no
    launch)][edge][45px gap][descending ceiling ramp (sy0 = head height)]
    [release to the ground]

    Difference from ceilpush (the pad version): a pad's launch impulse differs
    per mode, so 8 modes cannot be put on the same plateau. Walking up ramps
    puts every mode at the same height (flyramps already proved zero-input rides
    for ship/UFO/swing; only wave may not follow the surface, so it is best
    effort).

    KEEP THE RAMP 45px FROM THE EDGE (measured in v1: placed at edge+6, the head
    entered the line at x=edge+13.8 while the feet were still on the plateau's
    edge, and the player was CRUSHED while grounded).
    45px = the box's half-width 15 (support ends) + 15 (until the box's right
    edge enters the ramp band) + margin. sy0 is at head height: on entry the
    player has already dropped a few px and does not touch, and the line
    descends (m*dx/tick) faster than the fall, so it catches up in mid-air.
    """
    objs: list[str] = []
    # Portal: partway along the run-up (well clear of the previous unit's
    # release, and after landing)
    objs.append(obj(MODE_PORTAL[mode], x + 4 * GRID, GROUND_TOP + 15.0))
    xr = x + 8 * GRID
    # 3 uphill 0.5 ramps (same placement as ramp_unit, +90px)
    oid, rot, fx, fy, w, h = RAMP[0.5]
    bottom = GROUND_TOP
    for i in range(3):
        cy = bottom + h / 2.0
        objs.append(obj(oid, xr + w / 2.0, cy, rot=rot,
                        flip_x=fx, flip_y=fy))
        yy = GROUND_TOP + GRID / 2
        while yy < cy - h / 2.0 + 1.0:
            for k in range(int(w / GRID)):
                objs.append(obj(BLOCK, xr + GRID / 2 + k * GRID, yy))
            yy += GRID
        bottom += h
        xr += w
    ptop = GROUND_TOP + 3 * h            # top surface of the plateau (180)
    # The plateau: joined to the top end WITH NO GAP = the player walks across
    # instead of launching (the converse of the note in ramp_unit: the plateau
    # version produced 0 launches)
    plen = 7 * GRID
    xx = xr + GRID / 2
    while xx < xr + plen:
        for b in range(3):
            objs.append(obj(BLOCK, xx, ptop - GRID / 2 - b * GRID))
        xx += GRID
    xe = xr + plen                        # the edge
    # Ceiling ramp (downhill, high side on the left). sy0 = ptop+30 = the head
    # height while on the plateau. The player drops a few px between losing
    # support at the edge and its box's right side reaching the ramp, so there
    # is no contact.
    coid, crot, cfx, cfy, cw, ch = CEIL_RAMP[mm]
    xs = xe + 45.0
    sy0 = ptop + 30.0 + d          # d: the offset that sweeps the release condition (ceilrel)
    objs.append(obj(coid, xs + cw / 2.0, sy0 - mm * cw / 2.0,
                    rot=crot, flip_x=cfx, flip_y=cfy))
    # After release the player falls to the ground (world 90). 10 cells to the
    # next unit
    return objs, xs + cw + 10 * GRID


def build_ceilpush8() -> str:
    u"""ONE SITUATION x ALL 8 MODES: the ceiling ramp's push-down (the
    upceil/ceilpush branch).

    A rig for validating the mode whitelists. The rule for this situation
    currently has three mode gates:
      - the upceil clamp value (r64: 0 for spider alone, -2.000 for ship/cube;
        ball/UFO/wave/robot are UNMEASURED)
      - the `c.mode != 7` on the upceil branch itself (excludes swing)
      - the {ship,swing,cube} whitelist on the adjacent-ceiling scan L8246 and
        the ridge scan L8930
    If GD behaves the same across all 8 modes, collapse them. If they split, the
    split becomes a measurement.
    """
    objs: list[str] = []
    x = 90.0
    # m=2 GOES LAST: measured in v2, when the line closes on a falling head at
    # 2.6px/tick GD KILLS instead of pushing down (the corpus' lv18 t=20,479 is
    # rising, closing at 0.69px/tick, and that one is pushed). A death ends the
    # rig there, so the 8 m=2 units are isolated at the back to protect the 16
    # units of {0.5,1} even if they die.
    # wave is excluded (measured in v3: wave dies in this rig's ceiling-ramp
    # band at x=7,583 and the rig ends there. The same "does not follow the
    # surface" that made flyramps drop wave)
    # m=2 is excluded too (measured in v3/v4: entering an m=2 downhill ceiling
    # from the side while falling makes GD KILL RATHER THAN PUSH DOWN -- cube
    # died at t=11,590 x=15,042 and everything after was lost. The corpus'
    # lv18 t=20,479 is the same m=-2 but rising, and there it is pushed.
    # The kill boundary cannot be measured on a rig (death = end of rig), so it
    # is done separately by worker injection)
    for mm in (0.5, 1.0):
        for mode in MODE8:
            if mode == "wave":
                continue
            x0 = x
            u, x = ceilpush8_unit(x, mode, mm)
            objs += u
            UNITS.append({"x0": x0, "x1": x, "mode": mode, "m": -mm,
                          "mini": 0})
    # [2026-08-21] KEEP THE LAST UNIT AWAY FROM THE END OF THE LEVEL. If it
    # reaches the end-of-level completion sequence, GD's dump freezes for ~170
    # ticks (the same x/y/rot row repeated; not a death). This turned the final
    # swing of ceilpush8 and ceilrel into a fake DIVERGE. A throwaway floor
    # block pushes levelMaxX 900px further out.
    objs.append(obj(BLOCK, x + 900.0, GROUND_Y))
    return header() + ";" + ";".join(objs) + ";"


def build_shortexit() -> str:
    u"""Rig measuring SHORT-STAY SLOPE LAUNCHES. Zero input, cube, 1x.

    The ramps rig uses 3-ramp chains, so it can only produce launches with a
    ride of 24+ ticks (= saturated). lv20 t=5,269 (target 2) lands on the top
    corner and is released at +2.762 after 1 tick -- the ramp factor's ramp-up
    (a stay of 1-24 ticks) had never been measured.

    Unit = [yellow pad][arc][a single floating uphill ramp]. The ramp is placed
    so the mid-air attachment x lands D px short of the top end. The player then
    leaves the top end after a ride of ~D/1.298 ticks, producing a launch vy.
    Sweeping D gives the factor(k) curve from a single run.
    Units with a small D land on the top corner itself depending on phase = they
    double as samples of target 2's "does not land until the penetration
    exceeds 1.000" side.
    """
    objs: list[str] = []
    objs += floor_run(0, PAVE_X)
    combos: list[dict] = []
    for mm in (0.5, 1.0):
        for D in (2.0, 4.0, 7.0, 10.0, 14.0, 19.0, 26.0, 34.0):
            for d in ((0.0, 0.4) if D <= 4.0 else (0.0,)):
                combos.append({"m": mm, "D": D, "d": d})
    pH = 15.0
    for k, c in enumerate(combos):
        x0u = 90.0 + k * SL_PITCH
        pad = sl_pad_cx(k)
        objs.append(obj(PAD_YELLOW, pad, GROUND_TOP + 5.0))
        u = {"x0": x0u, "x1": x0u + SL_PITCH, "pad": pad, "mode": "cube",
             "m": c["m"], "D": c["D"], "d": c["d"], "mini": 0}
        if SL_ARC:
            mm = c["m"]
            oid, rot, fx, fy, w, h = RAMP[mm]
            dxA = yA = None
            for dt, dx, y, vy in SL_ARC:
                if vy <= -9.0:
                    dxA, yA = dx, y
                    break
            xa = pad + SL_FIRE_DX + dxA          # the centre x we want to seat at
            xs = xa - (w - c["D"])               # top end x1 = xa + D
            cx = xs + w / 2.0
            cy = (yA - pH * math.sqrt(1.0 + mm * mm)) \
                - mm * (xa - cx) + c["d"]
            if cy - mm * w / 2.0 < GROUND_TOP + 3.0:
                print(f"  unit {k}: too low, skipped")
            else:
                objs.append(obj(oid, cx, cy, rot=rot, flip_x=fx, flip_y=fy))
                u.update({"cx": cx, "cy": cy, "w": w,
                          "xtop": xs + w, "ytop": cy + mm * w / 2.0})
        UNITS.append(u)
    return header() + ";" + ";".join(objs) + ";"


def build_edgeland() -> str:
    u"""Rig measuring HOW FAR PAST A PLATFORM'S EDGE THE PLAYER CAN STILL LAND
    (pInner). Zero input.

    lv19 t=15,514: with the falling cube's centre 7.33px past the platform's
    right edge, GD does not catch the platform. lv20 t=5,269: ~12.7px past the
    edge of a width-1.5 bar is not caught either. The boundary of how far it
    will still catch is unmeasured (estimated 5-6).

    Unit = [yellow pad][arc][a single floating block]. The block is placed so
    that the centre x on the tick where the falling bottom crosses the top
    surface is "the right edge + O". Sweeping O brackets the landing /
    pass-through boundary. On a pass-through the player just falls to the ground
    and walks on.
    """
    objs: list[str] = []
    objs += floor_run(0, PAVE_X)
    combos: list[dict] = []
    for O in (2.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 12.0):
        for d in ((0.0, 0.4) if 5.0 <= O <= 9.0 else (0.0,)):
            combos.append({"O": O, "d": d})
    pH = 15.0
    for k, c in enumerate(combos):
        x0u = 90.0 + k * SL_PITCH
        pad = sl_pad_cx(k)
        objs.append(obj(PAD_YELLOW, pad, GROUND_TOP + 5.0))
        u = {"x0": x0u, "x1": x0u + SL_PITCH, "pad": pad, "mode": "cube",
             "O": c["O"], "d": c["d"], "mini": 0}
        if SL_ARC:
            dxA = yA = None
            for dt, dx, y, vy in SL_ARC:
                if vy <= -9.0:
                    dxA, yA = dx, y
                    break
            xa = pad + SL_FIRE_DX + dxA        # centre x around where the bottom crosses
            face = yA - pH + c["d"]            # top surface = the bottom at the crossing
            cx = xa - c["O"] - GRID / 2.0      # right edge = xa - O
            cy = face - GRID / 2.0
            objs.append(obj(BLOCK, cx, cy))
            u.update({"cx": cx, "cy": cy, "face": face,
                      "edge": cx + GRID / 2.0})
        UNITS.append(u)
    return header() + ";" + ";".join(objs) + ";"


def recttop_unit(x: float, mode: str, m: float, mini: bool, n_down: int
                 ) -> tuple[list[str], float, dict]:
    u"""One unit of [portal][climb an uphill ramp][plateau][n downhill ramps]
    [run through]. Zero input.

    Measures ON WHICH CROSSING THE RECTANGLE-TOP CLAMP (sp->cy+sp->hh) HAPPENS.
    The player walks from the plateau onto the high end of the first downhill
    ramp and seats there (descent 0). From then on it crosses rTop exactly once
    per ramp, so one unit yields n_down CROSSING SAMPLES. The point is that the
    ramp index (its own ramp, or one past a seam) is what varies -- since the
    descent has been ruled out as the discriminator (measured 2026-08-19),
    this is the next candidate.
    """
    objs: list[str] = []
    oidU, rotU, fxU, fyU, wU, hU = RAMP[1.0]      # the climb is always |m|=1 (30x30)
    oidD, rotD, fxD, fyD, wD, hD = DOWNRAMP[m]
    top = GROUND_TOP
    objs.append(obj(MODE_PORTAL[mode], x, top + 15.0))
    objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 2 * GRID,
                    top + 15.0))
    xr = x + 8 * GRID
    # The climb: gain the height the descent will use (hD*n_down, in steps of hU=30)
    climb = int(math.ceil(n_down * hD / hU))
    bottom = top
    for _ in range(climb):
        cy = bottom + hU / 2.0
        objs.append(obj(oidU, xr + wU / 2.0, cy, rot=rotU,
                        flip_x=fxU, flip_y=fyU))
        yy = top + GRID / 2
        while yy < cy - hU / 2.0 + 1.0:
            for k in range(int(wU / GRID)):
                objs.append(obj(BLOCK, xr + GRID / 2 + k * GRID, yy))
            yy += GRID
        bottom += hU
        xr += wU
    # Plateau (top surface = bottom). Just 4 cells of walking to settle the
    # speed and the grounded state
    for k in range(4):
        yy = bottom - GRID / 2
        while yy > top - 1.0:
            objs.append(obj(BLOCK, xr + GRID / 2 + k * GRID, yy))
            yy -= GRID
    xr += 4 * GRID
    x_seat = xr
    # n downhill ramps. Placed so the first one's high end (the line at x0) is
    # at the same height as the plateau's top surface (for DOWNRAMP,
    # sy0 = cy + h/2).
    crossings = []
    hi = bottom
    for i in range(n_down):
        cy = hi - hD / 2.0
        objs.append(obj(oidD, xr + wD / 2.0, cy, rot=rotD,
                        flip_x=fxD, flip_y=fyD))
        # Fill in under the ramp (to stop the player falling through)
        yy = cy - hD / 2.0 - GRID / 2
        while yy > top - 1.0:
            for k in range(int(wD / GRID)):
                objs.append(obj(BLOCK, xr + GRID / 2 + k * GRID, yy))
            yy -= GRID
        crossings.append({"idx": i + 1, "rtop": cy + hD / 2.0,
                          "x0": xr, "x1": xr + wD})
        hi -= hD
        xr += wD
    # Run through: lay a floor at the height the descent ended on, out to the
    # next unit
    for k in range(6):
        yy = hi - GRID / 2
        while yy > top - 1.0:
            objs.append(obj(BLOCK, xr + GRID / 2 + k * GRID, yy))
            yy -= GRID
    xr += 6 * GRID
    u = {"x0": x, "mode": mode, "m": m, "mini": int(mini),
         "n_down": n_down, "x_seat": x_seat, "plateau_top": bottom,
         "crossings": crossings}
    return objs, xr + 4 * GRID, u


def build_recttop() -> str:
    u"""Rig measuring THE GATE ON THE RECTANGLE-TOP CLAMP (sp->cy+sp->hh).
    Zero input.

    The existing gate is "descent since attaching >= pH*sqrt(1+m^2)", but that
    was settled on 2026-08-19 as NOT BEING THE DISCRIMINATOR (the clamping cases
    8.07 / 14.53 / 28.55 and the pass-through cases 8.88 / 12.98 / 19.37 / 38.7
    interleave perfectly).
    Here THE RAMP INDEX is swept (the ramp it seated on, versus one past a
    seam). One unit yields n_down crossings, so cube/ball x 3 values of |m| x
    normal/mini x n_down=4 gives 96 samples per run.

    Detection: pick the ticks where y is exactly rtop (a round value) out of the
    dump.
    """
    objs: list[str] = []
    objs += floor_run(0, PAVE_X)
    x = 90.0
    for mode in ("cube", "ball"):
        for m in (1.0, 0.5, 2.0):
            for mini in (False, True):
                u_objs, x, u = recttop_unit(x, mode, m, mini, 4)
                objs += u_objs
                UNITS.append(u)
    return header() + ";" + ";".join(objs) + ";"


def build_portwavebig() -> str:
    u"""The NORMAL-SIZE WAVE version of portwave. Zero input.

    At lv19 t=19,491 (a normal wave passing through the rot=-41 speed portal
    id200) the model fires 1 tick early. The mini wave's contact half-size
    matches 4/5 on portwave, so this measures THE NORMAL SIZE'S CONTACT
    HALF-SIZE in isolation.
    The angle is swept finely (the more the portal is rotated, the more the x
    half and the y half mix).
    """
    objs: list[str] = []
    x = 90.0
    for rot in (0, 10, 20, 30, 41, 43, 50, 60, 70, 90):
        x0 = x
        objs.append(obj(P_CUBE, x, GROUND_TOP + 15.0))
        objs.append(obj(SIZE_NORM, x + 2 * GRID, GROUND_TOP + 15.0))
        objs.append(obj(P_WAVE, x + 4 * GRID, GROUND_TOP + 15.0))
        x_port = x + 14 * GRID
        objs.append(obj(P_UFO, x_port, GROUND_TOP + 15.0, rot=float(rot)))
        x = x_port + 24 * GRID
        UNITS.append({"x0": x0, "x1": x, "rot": rot, "x_port": x_port,
                      "mode": "ufo", "m": 0, "mini": 0, "player": "wave"})
    objs += floor_run(0, PAVE_X)
    return header() + ";" + ";".join(objs) + ";"


def build_flyramps() -> str:
    """Calibration rig for RAMP RIDES/LAUNCHES IN THE FLIGHT MODES. Clears every
    unit with zero input.

    The flight version of `ramps` (the 4 ground modes). With no input, ship /
    UFO / swing simply sink under gravity, so the same `ramp_unit` as the ground
    modes works unchanged (they slide along the floor into the ramp, get pushed
    up by the surface, climb, and launch at the top end).
    wave was dropped because it bounces instead of following the surface.

    THE AIM: the flight-mode ramp families still in census
      lv16 `m1/mini1/g1/gdg1/sp0.7/slope+0.50/ride0`  (ship mini)
      lv18 `m1/mini1/g1/gdg1/sp1.1/slope-1.00/ride2`  (ship mini)
      lv21 `m3/mini1/g1/gdg1/sp1.1/slope-2.00/ride9`  (UFO mini)
      lv22 `m7/mini0/g1/gdg0/sp1.1/slope+1.00/ride3`  (swing)
    Samples that occur only once each across the 22 official levels are taken as
    3 modes x 3 values of |m| x normal/mini x 2 ride lengths = 36 units in a
    single run.
    """
    objs: list[str] = []
    x = 90.0
    for mode in ("ship", "ufo", "swing"):
        for m in (1.0, 0.5, 2.0):
            for mini in (False, True):
                for n, bury in ((3, 0.0), (1, 0.0)):
                    x0 = x
                    u, x = ramp_unit(x, mode, m, mini, n, bury)
                    objs += u
                    UNITS.append({"x0": x0, "x1": x, "mode": mode, "m": m,
                                  "mini": int(mini), "ramps": n,
                                  "bury": bury})
    objs += floor_run(0, PAVE_X)
    return header() + ";" + ";".join(objs) + ";"


def build_slopevy() -> str:
    """Is the SLOPE-CONTACT vy ASSIGNMENT flat, or does it scale with speed?

    GD writes a vy of exactly +/-2.000 on the tick it makes slope contact. Ten
    unambiguous instances across lv16/lv18/lv20; the magnitude does not move with
    the ramp gradient (-2.0, -1.0, -0.5, -0.291, -0.264, +0.5, +1.0 all give
    2.000), so it is an assignment and not a computed launch, and the sign
    follows the RAMP direction rather than gravity. The separator that found them
    is `vy(t) - vy(t-1)`: the largest gravity step in the corpus is 0.216, the
    sorted jump-ins run `... 0.216 x23 | 0.363  2.000 x6 ...`, and nothing
    occupies the gap. 34 of the 44 corpus rows AT |vy| = 2.000 are coincidences --
    2.000 is not enriched, it ranks 34th of 401 populated values in its band.

    WHAT IS UNDECIDED: all ten instances are at speed 1.1, so a flat 2.000 and a
    speed-scaled one are indistinguishable in the corpus. There are zero
    discontinuities among the 366,350 speed-0.9 rows, which is suggestive and not
    proof. This rig sweeps the speed with a real speed portal per unit.

    PREDICTED, BEFORE THE RUN (dx from speed.hpp:75-84; the assignment is read
    off the tick where `vy(t) - vy(t-1)` exceeds 0.216):

        id   speed   dx        A: flat   B: prop. to speed   C: prop. to dx
        200  0.7     1.04650   2.000     1.2726              1.2965
        201  0.9     1.29825   2.000     1.6362              1.6086
        202  1.1     1.61426   2.000     2.000               2.000
        203  1.3     1.95000   2.000     2.3634              2.4160

    B and C differ by 0.024..0.053, and vy is recorded on a 0.001 grid, so all
    three separate. THE 1.1 UNIT IS THE CONTROL: every known instance is at 1.1,
    so if that unit shows no 2.000 the rig is not reproducing the phenomenon and
    THE SWEEP SAYS NOTHING -- read it before reading the others.

    Both modes: the assignment is not flight-specific (lv18 t=20,178 is a cube),
    so ship and cube run at every speed. Zero input, like its `flyramps` sibling.

    [2026-09-07, after the first run] THE ASSIGNMENT DID NOT APPEAR -- not even in
    the 1.1 units, so by the control above the sweep says nothing about it. The
    reason: lv16's event is a DESCENT onto the slope (vyin = -6.752, an inverted
    ship coming down onto it), and these units only ride UP a ramp and launch.
    The descent unit is still to be built.

    What the run did settle is the LAUNCH, and the gradient axis was added so it
    settles a row rather than a point. Measured at |m| = 1, all four speeds:

        speed  dx         ship    cube     ship/dx  cube/dx
        0.7    1.04650    4.477   5.969    4.278    5.704
        0.9    1.29825    5.554   7.405    4.278    5.704
        1.1    1.61426    6.906   9.208    4.278    5.704
        1.3    1.95000    8.342   11.123   4.278    5.704

    8/8 on the 0.001 grid, and both rows reproduce slopeExitVy's own anchors
    (cube 7.405 at sp=1; ship 5.554 = the ball row = cube x 0.75). That CONFIRMS
    the shipped `mode == 1 -> cubeExit * 0.75` at :540; it does not discover it.

    PREDICTED FOR THE GRADIENT AXIS, BEFORE THE RUN (cubeExit anchors 3.999 /
    7.405 / 10.507 at |m| = 0.5 / 1 / 2, times sp = dx/kDxF, times 0.75 for ship):

        |m|    sp0.7            sp0.9            sp1.1            sp1.3
        0.5    3.224 / 2.418    3.999 / 2.999    4.972 / 3.729    6.007 / 4.505
        1.0    5.969 / 4.477    7.405 / 5.554    9.208 / 6.906   11.123 / 8.342
        2.0    8.470 / 6.352   10.507 / 7.880   13.065 / 9.799   15.782 /11.836
        (cube / ship)

    The |m|=1 row is the one already measured, so it doubles as a repeat control.
    WATCH THE CUBE AT |m|=2, sp1.3: 15.782 is past the cube's terminal clamp of
    15.0 (constants.hpp), so a reading of 15.0 there is the clamp and NOT a
    refutation of the anchor -- decide that before reading the number.
    """
    objs: list[str] = []
    x = 90.0
    for sid, sp in ((200, 0.7), (201, 0.9), (202, 1.1), (203, 1.3)):
      for m in (0.5, 1.0, 2.0):
       for mini in (False,):
        for mode in ("ship", "cube"):
            # A REAL SPEED PORTAL, NOT THE HEADER: the header's kA4 does not
            # appear in objrects, so the model would run every unit at 1x and the
            # whole rig would come out a fake DIVERGE (build_ceilrel, 2026-08-21).
            # It sits 4 cells ahead of the unit so it cannot overlap the mode
            # portal ramp_unit puts at the unit's own x.
            objs.append(obj(sid, x, GROUND_TOP + 15.0))
            x0 = x
            u, x = ramp_unit(x + 4 * GRID, mode, m, mini, 3, 0.0)
            objs += u
            UNITS.append({"x0": x0, "x1": x, "mode": mode, "m": m,
                          "mini": int(mini), "ramps": 3, "bury": 0.0,
                          "speed": sp, "speed_id": sid})
    objs += floor_run(0, PAVE_X)
    return header() + ";" + ";".join(objs) + ";"


def build_bandceil() -> str:
    """What is the 14 px between the camera band's top and the player's clamp?

    GD pins a rising flyer BELOW the band's upper bound, and the inset is 14.000
    in two places that share nothing else:

        rig slopevy  t=16610  camy 80         + gy2 309        = 389.000000
                              clamp y 375                        gap 14.000
        lv16         t= 8548  camy 320.117188 + gy2 308.882812 = 629.000000
                              clamp y 615                        gap 14.000

    Different level, different camera height, one number; and in the rig the
    absence of any object at y=375 is KNOWN rather than merely unobserved,
    because the rig's contents are generated here (ramp tops 270, floor fill from
    105 down, the neighbouring portals at 105).

    The full-size player's outer half is 15.0 (kCubeHalf) and its contact half is
    7.5 x 2 = 15.0... but kMiniContactHalf is 7.5 against kMiniHalf 9.0, so size
    separates the readings. PREDICTED MINI GAP, WRITTEN BEFORE THE RUN -- five
    values, not two, because "somewhere near 8" would otherwise be read as
    "half-derived" and lose the distinction:

        flat constant                        14.0
        outer half, minus 1   (9.0 - 1)       8.0
        outer half, scaled    (9.0 x 14/15)   8.4
        contact half, minus 1 (7.5 - 1)       6.5
        contact half, scaled  (7.5 x 14/15)   7.0

    An offset says GD insets by a fixed 1 px; a ratio says the clamp is a
    fraction of the body. They disagree at every other size (spider 13.5 gives
    12.5 against 12.6), so the distinction is worth the extra rows.

    WHY THIS RIG AND NOT `slopevy`'s mini axis: the mini units there never
    reached the ceiling. mini launches from a ramp top 6 px lower at the same vy
    (the exit table has mini equal to full size), and at sp1.1 it peaked at
    368.034 against a clamp at 375 -- 7 px short. A missing contact there is NOT
    a null result, it is an unreached one. sp1.3 clears that margin: full size
    clamped at 375 with vy still 7.613 on the contact tick.

    ONLY the configuration that produces the contact: |m|=2 ship, the two speeds
    that reach, both sizes. Four units, zero input.
    """
    objs: list[str] = []
    x = 90.0
    for sid, sp in ((202, 1.1), (203, 1.3)):
        for mini in (False, True):
            objs.append(obj(sid, x, GROUND_TOP + 15.0))
            x0 = x
            u, x = ramp_unit(x + 4 * GRID, "ship", 2.0, mini, 3, 0.0)
            objs += u
            UNITS.append({"x0": x0, "x1": x, "mode": "ship", "m": 2.0,
                          "mini": int(mini), "ramps": 3, "bury": 0.0,
                          "speed": sp, "speed_id": sid})
    objs += floor_run(0, PAVE_X)
    return header() + ";" + ";".join(objs) + ";"


CR_SPEED = 0   # kA4 for ceilrel (0=1x=sp0.9, 1=0.5x=sp0.7, 2=2x=sp1.1)


def build_ceilrel() -> str:
    u"""Rig that cracks the release-vy ASSIGNMENT on an m=1 downhill ceiling.

    First measurement from ceilpush8: on the tick after release at the low end
    of an m=1 ramp, GD assigns vy (ship -4.628 / swing -4.628 / UFO -4.397; the
    preceding vy differs yet ship=swing, so it is an assignment, not a delta).
    d (a height offset applied to the whole ramp) changes the y, the falling
    speed and the ride length at release, so one run decides whether the
    assigned value
      - is invariant in d -> a per-mode constant (a function of m and dx)
      - moves with d      -> kinematic (a function of the state at release)
    The speed is CR_SPEED (per rig, kA4).
    """
    objs: list[str] = []
    # [2026-08-21] Change the speed WITH A REAL SPEED PORTAL, NOT VIA THE HEADER
    # (kA4). The header does not appear in objrects, so the model ran at 1x and
    # the whole rig came out as a fake DIVERGE (the first run of ceilrel11/07).
    # id 200=0.7 / 202=1.1 (type 20) are measured from the corpus (lv19 uid13186
    # and others).
    if CR_SPEED == 1:
        objs.append(obj(200, 45.0, GROUND_TOP + 15.0))
    elif CR_SPEED == 2:
        objs.append(obj(202, 45.0, GROUND_TOP + 15.0))
    x = 90.0
    for mode in ("ship", "ufo", "swing"):
        for d in (0.0, 4.0, 8.0, 12.0):
            x0 = x
            u, x = ceilpush8_unit(x, mode, 1.0, d)
            objs += u
            UNITS.append({"x0": x0, "x1": x, "mode": mode, "m": -1.0,
                          "mini": 0, "d": d, "speed": CR_SPEED})
    objs.append(obj(BLOCK, x + 900.0, GROUND_Y))   # end-of-level freeze guard (as above)
    return header() + ";" + ";".join(objs) + ";"


def build_ceilrel11() -> str:
    global CR_SPEED
    CR_SPEED = 2
    return build_ceilrel()


def build_ceilrel07() -> str:
    global CR_SPEED
    CR_SPEED = 1
    return build_ceilrel()


SEAM_SPEED = 0   # 0=1x / 1=0.7x / 2=1.1x (set by seam07 / seam11)


def seam_unit_v3(x: float, mode: str, m: float, delta: float, n_dn: int
                 ) -> tuple[list[str], float, dict]:
    u"""One seam unit that RIDES A DOWNHILL CHAIN INTO A FLUSH SLAB (v3).
    Zero input.

    Two facts learned in v1/v2:
      1. Joining a downhill ramp directly to the top of an uphill one makes GD
         LAUNCH AT THE APEX (cube +7.405 / ball +5.554 = the slopeExitVy of that
         gradient). Interposing a plateau prevents the launch
      2. YOU CANNOT WALK FROM A PLATEAU ONTO A DOWNHILL RAMP -- by the time the
         contact point is inside the span, the seat plane is running away at
         1.3|m| px/tick. The player free-falls off the plateau's edge and
         ATTACHES WHERE THE FALL CATCHES UP WITH THE SEAT PLANE. Catching up
         takes n = |m|*dx/(0.225*g) ticks (35px for cube m=0.5, 69px for m=1;
         about twice that for ball), so the key is to MAKE THE DOWNHILL CHAIN
         LONGER THAN THAT. v2 used a single downhill ramp (30px), so at m=1/2 it
         never caught up and passed straight through
      3. The idea of using the apex launch to drop the arc onto the downhill
         (v3) was rejected: the landing is 162px away for cube m=1 and 679px for
         |m|=2, and the landing itself splits at the 9px level via a different
         mechanism (the slopeland family), fouling the seam measurement

    v4 = [n_dn+1 uphill ramps][plateau (suppresses the launch)][n_dn downhill
    ramps][flush slab].
    """
    oid_u, rot_u, fxu, fyu, w, h = RAMP[m]
    oid_d, rot_d, fxd, fyd, _w, _h = DOWNRAMP[m]
    objs: list[str] = []
    objs.append(obj(MODE_PORTAL[mode], x, GROUND_TOP + 15.0))
    objs.append(obj(SIZE_NORM, x + 2 * GRID, GROUND_TOP + 15.0))
    n_up = n_dn + 1                      # one extra so the slab stays above the ground
    xr = x + 8 * GRID + delta
    bottom = GROUND_TOP
    for i in range(n_up):
        cy = bottom + h / 2.0
        objs.append(obj(oid_u, xr + w / 2.0, cy, rot=rot_u,
                        flip_x=fxu, flip_y=fyu))
        yy = GROUND_TOP + GRID / 2
        while yy < cy - h / 2.0 + 1.0:
            for k in range(int(w / GRID)):
                objs.append(obj(BLOCK, xr + GRID / 2 + k * GRID, yy))
            yy += GRID
        bottom += h
        xr += w
    # The plateau at the apex: without it GD launches at the apex (measured in v1)
    plat_len = 6 * GRID
    xx = xr + GRID / 2
    while xx < xr + plat_len:
        yy = GROUND_TOP + GRID / 2
        while yy <= bottom - GRID / 2 + 0.01:
            objs.append(obj(BLOCK, xx, yy))
            yy += GRID
        xx += GRID
    xr += plat_len
    for i in range(n_dn):
        cy = bottom - h / 2.0
        objs.append(obj(oid_d, xr + w / 2.0, cy, rot=rot_d,
                        flip_x=fxd, flip_y=fyd))
        # [v5] DO NOT FILL UNDER A DOWNHILL RAMP. The bottom edge of a downhill
        # ramp's box is "the height of the low end", so filling it the same way
        # as an uphill ramp puts the fill's top surface ABOVE THE LINE over most
        # of the span. GD ignores that and rides the line, while the model
        # landed on the fill's top surface and dropped the ride (this made
        # seam11's fast cube column and every ball column a fake DIVERGE). The
        # ramp itself provides the solid side, so nothing falls through without
        # the fill.
        bottom -= h
        xr += w
    x1 = xr                              # low end of the downhill chain = the seam
    seam_y = bottom                      # the line height there = the slab's top surface
    slab_len = 12 * GRID
    xx = x1 + GRID / 2
    while xx < x1 + slab_len:
        yy = GROUND_TOP + GRID / 2
        while yy <= seam_y - GRID / 2 + 0.01:
            objs.append(obj(BLOCK, xx, yy))
            yy += GRID
        xx += GRID
    u = {"x0": x, "mode": mode, "m": -m, "mini": 0, "delta": delta,
         "x1": x1, "seam_y": seam_y, "w": w, "h": h, "n_dn": n_dn}
    return objs, x1 + slab_len + 14 * GRID, u


def seam_unit(x: float, mode: str, m: float, delta: float
              ) -> tuple[list[str], float, dict]:
    u"""One seam unit of DOWNHILL RAMP -> FLUSH SLAB. Zero input.

    r79 established that "if what follows the end is a flush slab, the ride
    survives until the tick where *the trailing corner (centre - (pH - xoff)) +
    c* leaves the end", but the corpus' 3 samples only bracketed
    c in (1.016, 1.23] (the implementation provisionally uses 1.1). Here the
    same seam is laid out with THE PHASE delta STEPPED, so each unit yields one
    interval for c from the tick of the release pulse (vy := m*dx/0.25 for 1
    tick).

    [mode][size][2 uphill][A FLUSH PLATEAU][1 downhill][flush slab][gap]

    delta shifts the whole ramp assembly (uphill, plateau, downhill, slab, fill)
    in x = it shifts the phase at which the player arrives. THE SLAB IS JOINED
    AT THE SAME HEIGHT AS THE DOWNHILL RAMP'S LOW END (that is the definition of
    "flush": the implementation tests "is there a solid at end +1px whose top
    surface is within +/-0.5 of the line at the end").

    A PLATEAU IS REQUIRED PAST THE UPHILL APEX (the v1 failure): joining a
    downhill ramp directly to the top of an uphill one makes GD launch at the
    apex (cube +7.405 / ball +5.554 = the slopeExitVy of that gradient) and the
    player flies over the seam and lands beyond it -- all 48 units were
    measuring "the apex launch". As the note on the ramps rig says, JOINING A
    PLATEAU AT THE SAME HEIGHT AS THE TOP END WITH NO GAP PREVENTS THE LAUNCH,
    so let the player walk over that before entering the downhill.
    """
    oid_u, rot_u, fxu, fyu, w, h = RAMP[m]
    oid_d, rot_d, fxd, fyd, _w, _h = DOWNRAMP[m]
    objs: list[str] = []
    objs.append(obj(MODE_PORTAL[mode], x, GROUND_TOP + 15.0))
    objs.append(obj(SIZE_NORM, x + 2 * GRID, GROUND_TOP + 15.0))
    n_up = 2
    xr = x + 8 * GRID + delta
    bottom = GROUND_TOP
    for i in range(n_up):
        cy = bottom + h / 2.0
        objs.append(obj(oid_u, xr + w / 2.0, cy, rot=rot_u,
                        flip_x=fxu, flip_y=fyu))
        yy = GROUND_TOP + GRID / 2
        while yy < cy - h / 2.0 + 1.0:
            for k in range(int(w / GRID)):
                objs.append(obj(BLOCK, xr + GRID / 2 + k * GRID, yy))
            yy += GRID
        bottom += h
        xr += w
    # The plateau at the apex (top surface bottom). It suppresses the launch and
    # lets the player "walk" into the downhill
    plat_len = 6 * GRID
    xx = xr + GRID / 2
    while xx < xr + plat_len:
        yy = GROUND_TOP + GRID / 2
        while yy <= bottom - GRID / 2 + 0.01:
            objs.append(obj(BLOCK, xx, yy))
            yy += GRID
        xx += GRID
    xr += plat_len
    # One downhill ramp: the line runs bottom -> bottom - h
    cy_d = bottom - h / 2.0
    objs.append(obj(oid_d, xr + w / 2.0, cy_d, rot=rot_d,
                    flip_x=fxd, flip_y=fyd))
    yy = GROUND_TOP + GRID / 2
    while yy < cy_d - h / 2.0 + 1.0:
        for k in range(int(w / GRID)):
            objs.append(obj(BLOCK, xr + GRID / 2 + k * GRID, yy))
        yy += GRID
    x1 = xr + w                      # right edge of the downhill ramp = the seam
    seam_y = bottom - h              # the line height at the low end = the slab's top
    # The flush slab (top surface seam_y). ALIGN ITS LEFT EDGE WITH x1
    # (aligning centres sticks out 15px too early and makes the seam a lie --
    # the same trap as ceil_unit L465)
    slab_len = 12 * GRID
    xx = x1 + GRID / 2
    while xx < x1 + slab_len:
        yy = GROUND_TOP + GRID / 2
        while yy <= seam_y - GRID / 2 + 0.01:
            objs.append(obj(BLOCK, xx, yy))
            yy += GRID
        xx += GRID
    u = {"x0": x, "mode": mode, "m": -m, "mini": 0, "delta": delta,
         "x1": x1, "seam_y": seam_y, "w": w, "h": h}
    return objs, x1 + slab_len + 14 * GRID, u


def build_seam() -> str:
    u"""Seam rig: bracket the release tick of downhill -> flush slab by phase
    (pins down the c of r79).

    2 modes (cube/ball -- the same cast as the corpus' 3 samples) x 2 values of
    |m| x 12 phase points = 48 units. delta runs 0..1.21 in steps of 0.11
    (covering one tick of movement, 1.298).
    Each unit yields one interval for c from the release tick, so the phases
    intersect to bracket it.
    |m|=2 is left out because the apex launch's arc does not land until 679px
    later (see the v3 note).
    """
    objs: list[str] = []
    # Set the speed with a real portal (the header's kA4 does not appear in
    # objrects -- the lesson from ceilrel)
    if SEAM_SPEED == 1:
        objs.append(obj(200, 45.0, GROUND_TOP + 15.0))
    elif SEAM_SPEED == 2:
        objs.append(obj(202, 45.0, GROUND_TOP + 15.0))
    x = 90.0
    # The downhill chain's length is set by "the distance in which a player
    # falling off the plateau catches up with the seat plane"
    # (35px for cube m=0.5 / 69px for m=1; about twice that for ball; scaling
    # with dx^2 in the speed) + margin
    n_down = {1.0: 6, 0.5: 4}
    for mode in ("cube", "ball"):
        for m in (1.0, 0.5):
            for k in range(12):
                delta = round(k * 0.11, 2)
                u_objs, x_next, u = seam_unit_v3(x, mode, m, delta, n_down[m])
                objs += u_objs
                u["x1_unit"] = x_next
                u["speed"] = SEAM_SPEED
                UNITS.append(u)
                x = x_next
    # In the unit table, x1 means the unit boundary (calib_units), so move the
    # seam's x1 into seam_x1 before overwriting it
    for u in UNITS:
        u["seam_x1"] = u["x1"]
        u["x1"] = u.pop("x1_unit")
    objs.append(obj(BLOCK, x + 900.0, GROUND_Y))   # end-of-level freeze guard
    return header() + ";" + ";".join(objs) + ";"


def ridestep_unit(x: float, mode: str, m: float, dz: float
                  ) -> tuple[list[str], float, dict]:
    u"""A STEP DURING A RIDE: while riding an uphill ramp, run into a block
    whose top surface is dz px above the line. Measures whether GD transfers
    onto the step or passes through on the line.

    The corpus' 2 samples only bracket the boundary; everything between is
    unmeasured:
      lv16 t=5,378  feet 0.219px below the surface -> GD DOES mount (y=341.000)
      lv19 t=245    feet 5.5px below the surface   -> GD DOES NOT (stays on the line)
    The model uses landTol=0.001 during a ride (a guess), so it drops the former.
    """
    oid_u, rot_u, fxu, fyu, w, h = RAMP[m]
    objs: list[str] = []
    objs.append(obj(MODE_PORTAL[mode], x, GROUND_TOP + 15.0))
    objs.append(obj(SIZE_NORM, x + 2 * GRID, GROUND_TOP + 15.0))
    n_up = 3
    xr = x + 8 * GRID
    bottom = GROUND_TOP
    for i in range(n_up):
        cy = bottom + h / 2.0
        objs.append(obj(oid_u, xr + w / 2.0, cy, rot=rot_u,
                        flip_x=fxu, flip_y=fyu))
        yy = GROUND_TOP + GRID / 2
        while yy < cy - h / 2.0 + 1.0:
            for k in range(int(w / GRID)):
                objs.append(obj(BLOCK, xr + GRID / 2 + k * GRID, yy))
            yy += GRID
        bottom += h
        xr += w
    # PUT THE STEP OUTSIDE THE RAMP'S BOX. The v2 failure: a step buried inside
    # the box was completely ignored by GD (28/28 passed through) -- lv16's step
    # uid1935 sits BELOW the next ramp's box, and only there does it act as a
    # "step".
    # Its top surface goes just below the second box's bottom edge (-0.1), and
    # SWEEPING x sets the reach at the contact tick (step top - feet) to dz.
    #   reach = T - line1(X - 15 + xoff), where T = the box's bottom edge - 0.1
    # [v4] What is swept is depth = line(the step's x) - the step's top surface.
    # In the v3 measurement, that is what decides whether GD mounts the step
    # (2.829 passes through / 3.229 mounts). It is a pure geometric quantity,
    # unpolluted by phase (the fractional part of the contact tick).
    # depth = m*(15-xoff) - dz.
    x_r1 = x + 8 * GRID + w                      # left edge of the 2nd ramp (the ridden face)
    top = GROUND_TOP + 2 * h - 0.1               # just below the 3rd ramp box's bottom edge
    xoff = 15.0 * math.tan(math.atan(abs(m)) / 2.0)
    x_step = x_r1 + 15.0 - xoff + (h - 0.1 - dz) / abs(m)
    objs.append(obj(BLOCK, x_step + GRID / 2, top - GRID / 2))
    u = {"x0": x, "mode": mode, "m": m, "mini": 0, "dz": dz,
         "x_step": x_step, "step_top": top, "ramp_x0": x + 8 * GRID,
         "x_r1": x_r1}
    return objs, xr + 16 * GRID, u


def build_ridestep() -> str:
    u"""Rig bracketing the tolerance for landing on a step during a ride.
    cube x |m|{1,0.5} x 14 values of dz = 28.

    PUT THE LARGER dz LATER (a deep step risks a wall death -- the rig's rule).
    The verdict comes from the dump: (step top - feet) at the contact tick, and
    "did GD mount the step".
    """
    objs: list[str] = []
    x = 90.0
    xo = {1.0: 15.0 * math.tan(math.atan(1.0) / 2.0),
          0.5: 15.0 * math.tan(math.atan(0.5) / 2.0)}
    # depth is "how many px below the line the step's top surface is" = the
    # quantity that decides whether the step is mounted (boundary 3.15).
    # THE LIFT, lift = m*(15-xoff) - depth = how far the step raises the feet.
    # Whether GD launches after mounting appears to be decided by this instead
    # (the corpus' lv16 keeps riding at lift 0.22, while the rig launches at
    # lift 5.04). Sweeping depth from 3.2 to 8.5 drops lift from 5.6 to 0.3, so
    # a single run brackets both.
    for m in (1.0, 0.5):
        for depth in (2.6, 2.9, 3.05, 3.1, 3.2, 3.35, 3.6, 4.0, 4.5, 5.0,
                      5.5, 6.0, 6.5, 7.0, 7.6, 8.2):
            dz = m * (15.0 - xo[m]) - depth
            u_objs, x_next, u = ridestep_unit(x, "cube", m, dz)
            objs += u_objs
            u["x1"] = x_next
            u["depth"] = depth
            UNITS.append(u)
            x = x_next
    # Check whether it is mode-independent (only the two sides of the boundary)
    for mode in ("ball", "robot", "spider"):
        for depth in (2.6, 3.6):
            m = 1.0
            dz = m * (15.0 - xo[m]) - depth
            u_objs, x_next, u = ridestep_unit(x, mode, m, dz)
            objs += u_objs
            u["x1"] = x_next
            u["depth"] = depth
            UNITS.append(u)
            x = x_next
    objs += floor_run(0, x + 600.0)
    return header() + ";" + ";".join(objs) + ";"


def build_slopeflags() -> str:
    u"""Survey: which (object id, rotation, flip) yields which m_slopeDirection.

    The slope-adjacency veto census (2026-09-05) has GD refusing to resolve a
    solid next to a ramp on 5 of 14 ticks and resolving it on the other 9, and
    the ramp's `sdir` column explains 13 of the 14 -- but that is a fit of a
    5-valued category to 14 rows, and the corpus' ramps are seven different
    object ids (309, 321, 323, 484, 665, 666, 1744). Before sdir can be an axis
    of a sweep, GD has to say which construction produces which value:
    determineSlopeDirection is the only authority, and the RAMP table above only
    pins three combinations.

    Geometry only -- nothing here is ridden. The verdict is objrects' sdir/sup
    (and w/h/sy0/sy1 for the shape), so the run only has to load the level.
    """
    objs: list[str] = []
    x = 90.0
    # The rig's own four, then the seven the corpus actually uses.
    #
    # [2026-09-07] 366 AND 367 APPENDED -- THE SPIKED SLOPES, which had never
    # been on any table. They are exactly the shz=1 population (487 + 86 = 573
    # across the 22 dumps) and they appeared nowhere in data/rigs, so
    # slopeUphill's rig confirmation covered PLAIN slopes only and the claim
    # rested on the corpus census alone for all 573. Note 309 is already here
    # and is the PLAIN TWIN of lv16's killing column (uid 3782/3783, co-located
    # with the spiked 366 pair at 13323,465 and 13323,495) -- the rig carried
    # one half of that pair and never the other.
    # APPENDED, NOT INSERTED: x advances monotonically through the loop, so the
    # existing 160 units keep their exact positions and the 32 new ones follow.
    # Anything measured against the old file still lines up.
    ids = (SLOPE30, SLOPE60A, SLOPE60B, SLOPE30B,
           309, 321, 323, 484, 665, 666,
           366, 367)
    for oid in ids:
        for rot in (0.0, 90.0, 180.0, 270.0):
            for fx, fy in ((False, False), (True, False),
                           (False, True), (True, True)):
                cx, cy = x + 2 * GRID, GROUND_TOP + GRID
                objs.append(obj(oid, cx, cy, rot=rot, flip_x=fx, flip_y=fy))
                UNITS.append({"x0": x, "cx": cx, "cy": cy, "oid": oid,
                              "rot": rot, "flip_x": int(fx), "flip_y": int(fy)})
                x += 4 * GRID
    objs += floor_run(0, x + 300.0)
    return header() + ";" + ";".join(objs) + ";"


def slopeveto_unit(x: float, mode: str, rot: float, fx: bool, fy: bool,
                   d: float) -> tuple[list[str], float, dict]:
    u"""A ramp chain climbing to a junction, with a solid butted against its
    high end whose top face is d px off the ramp's line there.

    This is the corpus arrangement: lv19 t=254 (ramp uid33 rising to the corner
    at x=330,y=120, slab uid47 occupying 330..360 with its top face at 120) and
    lv18 t=9,297 (ramp uid6440 to 12810,210, block uid6528 at 12810..12840 top
    210) are both d = 0, and GD refuses to resolve the solid on both.

    The ramp is always id 1743, always the same 30x30 box, and -- for the four
    uphill directions -- always the same line 105->135 (the flag survey,
    calib_slopeflags, read all 160 id/rot/flip combinations back from GD). So
    `rot`/`fx`/`fy` move m_slopeDirection WITHOUT moving the geometry, which is
    what makes this a single-variable test rather than another corpus fit.
    """
    oid, w, h = SLOPE30, 30.0, 30.0
    objs: list[str] = []
    objs.append(obj(MODE_PORTAL[mode], x, GROUND_TOP + 15.0))
    objs.append(obj(SIZE_NORM, x + 2 * GRID, GROUND_TOP + 15.0))
    n_up = 3
    xr = x + 8 * GRID
    bottom = GROUND_TOP
    for _ in range(n_up):
        cy = bottom + h / 2.0
        objs.append(obj(oid, xr + w / 2.0, cy, rot=rot, flip_x=fx, flip_y=fy))
        yy = GROUND_TOP + GRID / 2
        while yy < cy - h / 2.0 + 1.0:
            for k in range(int(w / GRID)):
                objs.append(obj(BLOCK, xr + GRID / 2 + k * GRID, yy))
            yy += GRID
        bottom += h
        xr += w
    # The line reaches `bottom` at x = xr, so the solid's top face is bottom + d.
    top = bottom + d
    objs.append(obj(BLOCK, xr + GRID / 2, top - GRID / 2))
    u = {"x0": x, "mode": mode, "rot": rot, "flip_x": int(fx),
         "flip_y": int(fy), "d": d, "solid_cx": xr + GRID / 2,
         "solid_top": top, "ramp_hi_x": xr, "ramp_hi_y": bottom}
    return objs, xr + 12 * GRID, u


def build_slopeveto() -> str:
    u"""Does GD's refusal to resolve a ramp-adjacent solid read the ramp's
    m_slopeDirection?

    The veto census (2026-09-05) measured GD's own `hit` flag out of
    collidedWithObject on the 14 ticks where the model clamps to a solid beside
    a ramp: 5 refusals, 9 resolutions. `sdir` explains 13 of the 14 (sdir=0
    always refused, {2,3,4,7} always resolved), but that is a 5-valued category
    fitted to 14 rows whose ramps are seven different object ids -- exactly the
    shape of a coincidence.

    So hold everything else still. sdir 0 and 7 are both FLOOR ramps
    (slopeIsCeiling = {1,3,5,6}) and both uphill, and for id 1743 both are a
    30x30 box carrying the identical line 105->135 -- an upright cube rides them
    the same way. Only the flag differs.

      sdir=0 : rot 0,  no flip     corpus says REFUSED (lv18 9,297 / lv19 254,
                                   506 / lv20 5,278)
      sdir=7 : rot 90, flip Y      corpus says RESOLVED (lv22 4,592 / 4,595)

    If the hit flag splits along that pair, the veto reads the direction flag
    and the census' 13/14 was real. If it does not split, sdir was a confound
    and the first axis goes back to the placement.

    Run it with nodeath=1 and hitboxtrace=1; the verdict is per unit, so the
    window has to cover the whole level.
    """
    objs: list[str] = []
    x = 90.0
    for rot, fx, fy, sdir in ((0.0, False, False, 0), (90.0, False, True, 7)):
        # d is measured the opposite way round from `ridestep`'s depth: there,
        # depth = line - the step's top surface, so depth = -d. Its boundary is
        # kStepDepth 3.15 (<= 3.1 passes / >= 3.2 mounts), i.e. d <= -3.15, so
        # the sweep runs to -4.0 to straddle the veto's +-2.0 AND that one, on
        # the same units.
        for d in (-4.0, -3.5, -3.0, -2.5, -2.0, -1.5, -1.0, -0.5, 0.0,
                  0.5, 1.0, 1.5, 2.0, 2.5, 3.0):
            u_objs, x_next, u = slopeveto_unit(x, "cube", rot, fx, fy, d)
            objs += u_objs
            u["x1"] = x_next
            u["sdir_expected"] = sdir
            UNITS.append(u)
            x = x_next
    objs += floor_run(0, x + 600.0)
    return header() + ";" + ";".join(objs) + ";"


def build_slopeveto2() -> str:
    u"""Second pass: bracket the two boundaries the coarse sweep exposed.

    calib_slopeveto (2026-09-05) ran sdir 0 against sdir 7 with the geometry held
    bit-identical and found NO difference -- so the veto does not read
    m_slopeDirection, and the corpus' 13-of-14 fit was a confound. What it did
    find is a sharp transition in d (the solid's top face minus the ramp's line
    at the junction): refusals run 20-26 per unit up to d = +2.0 and are 0 at
    d = +2.5, on both directions at once. That is the asm's +-2.0.

    So drop the direction axis and spend the units on resolution:
      +1.85 .. +2.60 in 0.05/0.1 steps  -- where exactly the veto stops
      -2.90 .. -3.50                    -- kStepDepth's 3.15 lives at d = -3.15
                                           (depth = -d), on these same units
    """
    objs: list[str] = []
    x = 90.0
    fine = (1.85, 1.90, 1.95, 2.00, 2.05, 2.10, 2.20, 2.30, 2.40, 2.50, 2.60,
            -2.90, -3.00, -3.10, -3.15, -3.20, -3.30, -3.50)
    for d in fine:
        u_objs, x_next, u = slopeveto_unit(x, "cube", 0.0, False, False, d)
        objs += u_objs
        u["x1"] = x_next
        u["sdir_expected"] = 0
        UNITS.append(u)
        x = x_next
    objs += floor_run(0, x + 600.0)
    return header() + ";" + ";".join(objs) + ";"


def build_seam07() -> str:
    global SEAM_SPEED
    SEAM_SPEED = 1
    return build_seam()


def build_seam11() -> str:
    global SEAM_SPEED
    SEAM_SPEED = 2
    return build_seam()


# ---- Coins -----------------------------------------------------------------
# id 142 = SECRET coin (type 22, w=h=40 in every official dump), id 1329 = USER
# coin. Both are what buildPois collects (src/solver/solver.hpp), and both reach
# GJBaseGameLayer::pickupItem, which is where GD credits one -- the `coingd:`
# line comes out of the hook on it.
COIN_SECRET, COIN_USER = 142, 1329


# Per-axis scale (GD 2.2). 32 is the uniform one obj() already writes; a level
# author can set these two independently, so A COIN'S BOX IS NOT A CONSTANT and
# the model cannot carry one -- it has to read the object.
K_SCALE_X, K_SCALE_Y = 128, 129


def coin_station(x: float, oid: int, dy: float, scale: float = 0.0,
                 player_y: float = GROUND_TOP + 15.0, rot: float = 0.0,
                 sx: float = 0.0, sy: float = 0.0) -> list[str]:
    """One coin, dy above (or below) where a full-size cube's centre runs.

    Nothing else within 300 px. The player runs flat past it with zero input, so
    the only thing that can vary between stations is the coin's own placement.
    """
    extra: dict[int, str] = {}
    if sx:
        extra[K_SCALE_X] = f"{sx:g}"
    if sy:
        extra[K_SCALE_Y] = f"{sy:g}"
    return [obj(oid, x, player_y + dy, rot=rot, scale=scale,
                extra=extra or None)]


# THREE COINS PER RIG, AND NOT ONE MORE. Measured: a cut of this rig placed 36
# id-1329 stations and GD kept the first three (`pois: 0 orbs, 3 coins`, and the
# objrects dump held three rows). A GD level holds three user coins; the rest are
# dropped at load, silently, and a ladder built as one long level measures its
# first three rungs and nothing else. So the ladder is spread over RUNS, three
# rungs at a time, and `--coin` says which three.
#
# That is not the handicap it looks like: the corpus already brackets the
# boundary in (34, 36], so three rungs at 34.5 / 35.0 / 35.5 settle it in one
# run, and a run is about a second of game time.
COINCAL = {"mode": "cube", "mini": False, "scale": 0.0,
           "rot": 0.0, "sx": 0.0, "sy": 0.0,
           "dys": [34.5, 35.0, 35.5]}


def build_coincal() -> str:
    u"""Where exactly does GD credit a coin? Three coins at offsets we choose.

    THE OFFICIAL LEVELS CANNOT ANSWER THIS. Replaying the 22 solutions with the
    pickup hook on (2026-08-31) yields 24 credited coins, and every one of them
    is a sample taken AT THE CREDITING TICK -- i.e. from inside the boundary.
    The largest offsets seen are |dx| 34.80 and |dy| 34.86, and lv6's is credited
    at (33.82, 32.13) at once, which rules out a circle; but nothing in the
    corpus stands JUST OUTSIDE, so the boundary itself is unmeasured. The model's
    COIN_RADIUS of 20 is already known to be wrong (it misses 4 of the 24), and
    replacing one guessed number with another is not what that finding asks for.
    A rig puts a coin exactly where we choose and asks GD.

    **A SECRET COIN (id 142) DOES NOT LOAD IN A GENERATED LEVEL.** The first cut
    of this rig placed 22 of them and GD kept none: `pois: 0 orbs, 3 coins`, and
    the objrects dump held only the three id-1329 stations. A secret coin needs
    a level to be secret in. So the rig measures the USER coin, and the two are
    the same object as far as this measurement goes: id 1329 comes back as
    type 31, w=h=40, the same box the official 142s have (type 22, w=h=40), and
    both reach pickupItem down the same two branches of collisionCheckObjects.
    Neither type has a branch in leveldp's loader, so both are inert to the model.
    (The cross-check that they behave alike: the corpus' 142s cap at 34.86 and
    this rig's 1329s bracket the boundary in (34, 36] -- consistent, and the only
    evidence there is that the type does not enter the test.)

    The player runs flat with zero input, so the only thing that varies between
    the three stations is the coin's own offset.

    THE COINS ARE PLACED RELATIVE TO GROUND_TOP + 15 (or +9 for a mini), WHICH
    IS AN ASSUMPTION, and one mode does not honour it: a spider rests at y=103.5,
    not 105, so every `dy` in a spider rig is really dy+1.5. That is what made
    the first spider run come back 0/3 at 34.5/35/35.5 and look like a different
    rule. `player_y_assumed` in the unit table is only what the generator used;
    THE REAL OFFSET IS (coin_y - the player y in the `coingd:` line). Put a dy=0
    station in the first run of any new mode and read its resting y off that.

    ANSWER (2026-08-31, nine rigs). THE PLAYER'S AXIS-ALIGNED BOX AGAINST THE
    COIN'S OWN ORIENTED ONE -- the same 4-axis SAT the model already runs for
    portal firing, not a radius and not a bounding box. Touching counts: exactly
    on the boundary is credited.

    Unturned, that collapses to one number per axis, and both are per-object.
    THE PLAYER'S SIDE, all eight modes, both sizes (the boundary is that half
    plus the coin's 20; `rest` is where the body sits on the floor with no
    input, which the rig reads off its own dy=0 station):

      | mode   | rest  | half | boundary | in / out    | mini rest | half | in / out    |
      | cube   | 105   | 15   | 35       | 35.0 / 35.1 | 99        | 9    | 29.0 / 29.5 |
      | ship   | 105   | 15   | 35       | 35.0 / 35.5 | 99        | 9    | 29.0 / 29.5 |
      | ball   | 105   | 15   | 35       | 35.0 / 35.5 |           |      |             |
      | ufo    | 105   | 15   | 35       | 35.0 / 35.5 |           |      |             |
      | robot  | 105   | 15   | 35       | 35.0 / 35.5 |           |      |             |
      | swing  | 105   | 15   | 35       | 35.0 / 35.5 |           |      |             |
      | spider | 103.5 | 13.5 | 33.5     | 33.5 / 34.0 | 98.1      | 8.1  | 28.1 / 28.5 |
      | wave   | 100   | 5    | 25       | 25.0 / 25.5 | 96        | 3    | 23.0 / 23.5 |

    MINI IS x0.6 AND NOTHING ELSE, confirmed on three different bases (15->9,
    13.5->8.1, 5->3).

    THE WAVE IS ITS OWN BOX, AND NOT THE ONE IT SITS ON. Its coin half is 5
    while it rests at y=100, i.e. 10 above the floor -- so the box the coin test
    uses is half the box that holds it up, and a third of every other mode's.
    That is the same family as the wave's already-known split between a solid
    half of 1.5 and a hazard rect: the player's box is per purpose, and the coin
    is a purpose of its own. (Measured in y; the x side agrees to within one
    tick -- the credit lands at |dx| 24.87 against a predicted 25.)

    THE COIN'S SIDE, at a full-size cube (half 15):

      | coin                | coin half | boundary | in / out     |
      | default 40x40       | 20        | 35       | 35.0 / 35.1  |
      | scale 0.5           | 10        | 25       | 25.0 / 25.5  |
      | scale 2             | 40        | 55       | 55.0 / 55.5  |
      | sx=2 sy=0.5 (80x20) | 40 / 10   | 55 / 25  | y 25.0/25.5  |

    The last one settles that the two axes are independent: GD reports w=80 h=20
    and the coin is credited at |dx| 54.94 with the dy ladder breaking at 25.

    TURNED, THE BOUNDING BOX IS WRONG. objrects reports w=h=56.5686 for a coin
    at rot=45 (40*sqrt2, the AABB) with w0=h0=40, and if that were the box every
    station would be credited at |dx| = 15 + 28.284 = 43.28. Measured, the three
    stations are credited at three DIFFERENT offsets, each one the SAT bound of
    a different separating axis:

      | dy | binding axis | SAT bound | measured dx | AABB would say |
      |  0 | x            | 43.284    | 43.05       | 43.28          |
      | 20 | coin's u=45  | 38.284    | 38.06       | 43.28          |
      | 43 | coin's u=45  | 15.284    | 14.91       | 43.28          |

    all three inside their bound by 0.22..0.37 px, i.e. under one tick's 1.298.
    At dy=43 the bounding box is wrong by 28 px, and wrong in the dangerous
    direction: a model using it would plan routes that collect a coin GD never
    credits.

    So the coin's box has to be REBUILT from w0,h0 and rot (or read from the
    obb.txt the mod already dumps for anything turned by a non-multiple of 90),
    exactly as the turned-hazard path does. Only two of the 66 official coins are
    even non-default -- lv22's first two are scaled to 56.8 and 48.8 with rot=0,
    where the AABB and the OBB agree -- so this costs the official corpus
    nothing and is entirely about custom levels, where an author sets the size
    and the angle freely.

    On the coin's side THE MODEL NEEDS NO NEW CONSTANT AT ALL, only the object:
    w0,h0, the per-axis scale and the rotation are all already exported.
    `COIN_RADIUS = 20` in src/solver/solver.hpp is not any of these numbers.
    On the player's side it needs the table above -- eight halves, one of which
    (the wave's) is not a box the model already carries for anything else.

    The flight modes needed no plan in the end: with no input a ship, a UFO and a
    swing simply sink onto the floor and slide, and so does a wave (which is why
    the sawcal rigs run as one). Every row above is a zero-input run.

    Reproduce (each about a second of game time):
        python py/mklevel.py coincal --coin cube,0,0,34.5,35,35.5   --out data/rigs/calib_coincal.lvl
        python py/mklevel.py coincal --coin cube,0,0,35.1,35.25,35.4 --out ...
        python py/mklevel.py coincal --coin cube,1,0,28.5,29,29.5    --out ...
        python py/mklevel.py coincal --coin cube,0,0.5,24.5,25,25.5  --out ...
        python py/mklevel.py coincal --coin cube,0,2,54.5,55,55.5    --out ...
        python py/mklevel.py coincal --coin ball,0,0,34.5,35,35.5    --out ...
        python py/mklevel.py coincal --coin robot,0,0,34.5,35,35.5   --out ...
        python py/mklevel.py coincal --coin spider,0,0,0,28,32       --out ...
        python py/mklevel.py coincal --coin spider,0,0,32.5,33,34    --out ...
        python py/mklevel.py coincal --coin cube,0,0,24.5,25,25.5 --coin-sxy 2,0.5 --out ...
        python py/mklevel.py coincal --coin cube,0,0,0,20,43      --coin-rot 45  --out ...
        python py/mklevel.py coincal --coin ship,0,0,0,25,35         --out ...   # and ufo / wave / swing
        python py/mklevel.py coincal --coin ship,0,0,35.5,36,37      --out ...
        python py/mklevel.py coincal --coin wave,0,0,20,22.5,24      --out ...
        python py/mklevel.py coincal --coin wave,1,0,20,20.5,21      --out ...
        python py/mklevel.py coincal --coin spider,1,0,27.2,27.6,28  --out ...
    then run each with `coins=1` (py/run_calib.py ... coins=1) and read the
    `coingd:` lines. The turned rig is read by its CREDIT OFFSETS, not by which
    stations are credited -- all three are, and it is where they are credited
    that separates the box from the bounding box.
    """
    ref = GROUND_TOP + (9.0 if COINCAL["mini"] else 15.0)
    objs: list[str] = []
    x = 600.0
    for dy in COINCAL["dys"]:
        x0 = x
        objs += coin_station(x, COIN_USER, dy, COINCAL["scale"], ref,
                             COINCAL["rot"], COINCAL["sx"], COINCAL["sy"])
        UNITS.append({"x0": x0 - 300.0, "x1": x0 + 300.0, "coin_x": x0,
                      "id": COIN_USER, "dy": dy, "scale": COINCAL["scale"],
                      "rot": COINCAL["rot"],
                      "sx": COINCAL["sx"], "sy": COINCAL["sy"],
                      "mode": COINCAL["mode"], "mini": int(COINCAL["mini"]),
                      "coin_y": ref + dy, "player_y_assumed": ref})
        x += 600.0
    # Mode and size portals well before the first station, so the player is
    # already in the state under test when it gets there (a portal fires on box
    # overlap, ~32 px before its own centre).
    head = []
    if COINCAL["mode"] != "cube":
        head.append(obj(MODE_PORTAL[COINCAL["mode"]], 200.0, GROUND_TOP + 15.0))
    if COINCAL["mini"]:
        head.append(obj(SIZE_MINI, 300.0, GROUND_TOP + 15.0))
    # Floor LAST = a larger uid than everything above it (build_ramps' lesson).
    objs = head + objs + floor_run(0, x + 600.0)
    return header() + ";" + ";".join(objs) + ";"


# ---- Coins a TRIGGER controls (2026-09-20) ---------------------------------
# The official levels gate four coins behind triggers -- lv20's first is toggled
# in and out with the platform under it, lv22's first is alpha'd, lv22's third is
# toggled on by a chain, lv21's third and lv22's second are MOVED into reach --
# and the model has to know which of those a coin is still collectible under.
# Two of those questions have no answer in the corpus at all, because a route
# that never enables a coin never credits it either:
#   * is a coin at ALPHA 0 (invisible) still credited?
#   * is a coin whose group is toggled OFF still credited?
# Guessing either way is a route the game refuses (or a coin the search refuses
# to plan for), so the rig asks.
#
# THE KEYS ARE NOT MEASURED, the same caveat build_sawcal carries: 51 (target
# group), 56 (activate group: 1 on, 0 off), 35 (opacity) and 57 (group list) come
# from the community spec. The rig closes them itself -- the MOD's triggers.txt
# dump reports target/togon back, and the coin's own row carries its group -- so
# a wrong key shows up as a zero in the dump before anything rests on it.
TRIG_ALPHA, TRIG_TOGGLE, TRIG_TOUCH = 1007, 1049, 1595
# The Item Compare and one of the collectibles lv21 uses for its own counter.
# 80 = item id, 381 = "this collectible is a pickup item" (the flag items.txt
# reports, and the one that decides whether it moves a counter at all).
TRIG_COMPARE, ITEM_PICKUP = 3620, 1614
K_ITEM_ID, K_IS_PICKUP = 80, 381
K_ACTIVATE, K_OPACITY = 56, 35

COINGATE = {"variant": 1}


def _coin_in_group(x: float, y: float, group: int) -> str:
    return obj(COIN_USER, x, y, extra={K_GROUPS: str(group)})


def build_coingate() -> str:
    u"""Is a coin GD has hidden or switched off still credited?

    Three stations, 600 px apart, all at dy=30 -- well inside the 35 the coincal
    rig measured -- so a full-size cube running flat with no input touches every
    one of them. What differs is only what a trigger did to the coin first.

    variant 1 (the two open questions):
      A  x=600   plain coin, no group             -- the control: must be credited
      B  x=1200  coin in group 11, ALPHA 0 at x=900
      C  x=1800  coin in group 12, TOGGLE OFF at x=900

    variant 2 (the reversals, so that "not credited" in variant 1 is read as the
    trigger's doing rather than as the group itself breaking something):
      A  x=600   coin in group 11, toggle OFF at x=300 then ON at x=450
      B  x=1200  coin in group 12, alpha 0 at x=900 then alpha 1 at x=1050
      C  x=1800  coin in group 13, MOVED +90 in y at x=1500 -- credited only if
                 the credit follows the object (it starts 120 above the player,
                 i.e. out of reach, and the move brings it to dy=30)

    Read the `coingd:` lines: they name the coin's uid and the offsets at the
    crediting tick, so a station that is silent was not credited at all.
    """
    ref = GROUND_TOP + 15.0
    objs: list[str] = []
    xs = [600.0, 1200.0, 1800.0]
    if COINGATE["variant"] == 1:
        objs.append(obj(COIN_USER, xs[0], ref + 30.0))
        objs.append(_coin_in_group(xs[1], ref + 30.0, 11))
        objs.append(_coin_in_group(xs[2], ref + 30.0, 12))
        objs.append(obj(TRIG_ALPHA, 900.0, ref, extra={
            K_TARGET: "11", K_OPACITY: "0", K_DURATION: "0"}))
        objs.append(obj(TRIG_TOGGLE, 900.0, ref + 60.0, extra={
            K_TARGET: "12", K_ACTIVATE: "0"}))
        kinds = ["plain", "alpha0", "toggle_off"]
    elif COINGATE["variant"] == 3:
        # DOES THE CREDIT FOLLOW THE OBJECT? Decided both ways in one rig, so
        # neither answer can be read as "the move never happened":
        #   A  x=600   plain coin in reach -- the control
        #   B  x=1200  coin IN reach, moved UP 300 at x=900  -> credited only if
        #              the credit is taken at the LOAD position (it would be a
        #              contradiction of everything else the model relies on)
        #   C  x=1800  coin OUT of reach (+150), moved DOWN 300 at x=1500 ->
        #              credited only if the credit follows
        # The `coingd:` line prints the coin's position AT THE CREDITING TICK, so
        # whichever station is credited also measures the move offset's unit --
        # the one thing build_sawcal's note says is not established.
        objs.append(obj(COIN_USER, xs[0], ref + 30.0))
        objs.append(_coin_in_group(xs[1], ref + 30.0, 12))
        objs.append(_coin_in_group(xs[2], ref + 150.0, 13))
        objs.append(obj(TRIG_MOVE, 900.0, ref, extra={
            K_TARGET: "12", K_MOVE_X: "0", K_MOVE_Y: "300", K_DURATION: "0.2"}))
        objs.append(obj(TRIG_MOVE, 1500.0, ref, extra={
            K_TARGET: "13", K_MOVE_X: "0", K_MOVE_Y: "-300", K_DURATION: "0.2"}))
        kinds = ["plain", "moved_up_out_of_reach", "moved_down_into_reach"]
    elif COINGATE["variant"] == 6:
        # WHICH WAY DOES AN ITEM COMPARE (3620) COMPARE? lv22's third coin is
        # behind one, and its row reads item=1 mod1=1 **mod2=6** i1mode=1
        # i2mode=0 tgtmode=1 res=(3,3,2) tol=0 -- so the target is 6 and the
        # operator is in one of those columns, which is exactly what cannot be
        # read off a name. The rig places N pickups of item 1 and one compare
        # against a constant 3, and asks GD which N opens the coin's group.
        #   pickups at x=600, 900, 1200, 1500 (as many as COINGATE["n"])
        #   compare at x=1800, coin (group 40, switched off at x=300) at x=2400
        n = int(COINGATE.get("n", 3))
        objs.append(_coin_in_group(xs[2] + 600.0, ref + 30.0, 40))
        objs.append(obj(TRIG_TOGGLE, 300.0, ref, extra={
            K_TARGET: "40", K_ACTIVATE: "0"}))
        for i in range(n):
            # dy=0, not 30: a pickup's box is 25x20, so its credit bound in y is
            # 10 + the player's 15 = 25, and the first cut placed them 30 above
            # the player -- out of reach, which is why nothing counted.
            objs.append(obj(ITEM_PICKUP, 600.0 + 300.0 * i, ref, extra={
                K_ITEM_ID: "1", K_IS_PICKUP: "1"}))
        # The compare SPAWNS its target group; it does not toggle objects. So
        # its group holds a Toggle, and that is what switches the coin in.
        #
        # 62 = SPAWN TRIGGERED, and without it this rig measures nothing.
        # Belonging to group 41 does not stop an ordinary trigger from firing on
        # its OWN x-crossing, so the gate stood open whatever the compare said:
        # measured 2026-09-20, N = 0, 2, 3, 4 and 6 pickups against a constant
        # of 3 ALL credited the coin, the zero-pickup control included. Every
        # link of lv22's own chain carries spawn=1 for this reason.
        objs.append(obj(TRIG_TOGGLE, 2100.0, ref + 90.0, extra={
            K_TARGET: "40", K_ACTIVATE: "1", K_GROUPS: "41", 62: "1"}))
        # WHICH KEY IS THE CONSTANT? The bindings say m_mod2 is property 484 and
        # the first cut wrote that -- GD read back 0. Rather than try the next
        # number, every candidate goes in at once with a DISTINCT value, and the
        # dump says which column each one landed in.
        # MEASURED (2026-09-20, the probe that wrote 483/484/485/486 as 7/3/9/11
        # and read them back as mod2/tol/rnd1/rnd2): **the constant is property
        # 483 and the tolerance is 484**, the other way round from what the
        # bindings' comments say. The first cut put the constant in 484, which
        # GD read as a tolerance of 3 -- and 4 against 7 within 3 counts as
        # equal, so the gate opened for the wrong reason.
        objs.append(obj(TRIG_COMPARE, 1800.0, ref, extra={
            K_TARGET: "41", K_ITEM_ID: "1",
            476: "1", 477: "0", 478: "1", 479: "1",
            483: "3", 484: "0",
            480: "3", 481: "3", 482: "2"}))
        kinds = [f"compare_vs_3_with_{n}_pickups"]
        UNITS.append({"pickups": n, "compare_const": 3})
        objs += floor_run(0, xs[-1] + 1500.0)
        return header() + ";" + ";".join(objs) + ";"
    elif COINGATE["variant"] == 8:
        # DOES A PRESS THAT CANNOT JUMP STILL FIRE A TOUCH TRIGGER (1595)?
        #
        # lv22's third coin needs six of them inside a 240 px window (about 185
        # ticks): a Touch trigger at x=15,525 feeds a Pickup, and an Item
        # Compare opens the coin's group at item 1 >= 6. A grounded cube cannot
        # jump six times in 0.77 s, so the question is whether the presses that
        # land on an airborne cube -- which move nothing -- are counted.
        #   the Touch trigger sits at x=820, target 60, activate=1
        #   A  x=1800  coin in group 60, switched OFF at x=300
        #   B  x=2400  a plain coin -- this run credits coins at all
        # x(t) on this floor is 1.2983 px/tick (measured off calib_coingate7's
        # own coingd ticks), so the plan taps at t=600 (x=779, BEFORE the
        # trigger -- variant 5 measured that such a tap does nothing) and again
        # at t=660 (x=857, past it and 60 ticks into a jump that lasts about
        # 120). Run it twice: with the second tap and without. Credited only in
        # the first means an airborne press fires one.
        objs.append(_coin_in_group(1800.0, ref + 30.0, 60))
        objs.append(obj(COIN_USER, 2400.0, ref + 30.0))
        objs.append(obj(TRIG_TOGGLE, 300.0, ref + 60.0, extra={
            K_TARGET: "60", K_ACTIVATE: "0"}))
        objs.append(obj(TRIG_TOUCH, 820.0, ref, extra={
            K_TARGET: "60", K_ACTIVATE: "1", K_DURATION: "0"}))
        UNITS.append({"px_per_tick": 1.2983, "trigger_x": 820.0,
                      "taps": "t=600 before, t=660 past it and airborne"})
        for x0, kind in ((1800.0, "touch_by_airborne_press"), (2400.0, "plain")):
            UNITS.append({"x0": x0 - 300.0, "x1": x0 + 300.0, "coin_x": x0,
                          "id": COIN_USER, "kind": kind, "variant": 8,
                          "player_y_assumed": ref})
        objs += floor_run(0, 3000.0)
        return header() + ";" + ";".join(objs) + ";"
    elif COINGATE["variant"] == 7:
        # DOES A TRIGGER MARKED "TOUCH TRIGGERED" NEED THE BUTTON HELD?
        #
        # Not the same object as the Touch trigger (1595) variant 5 measures.
        # This is the flag an ordinary trigger carries -- the `touch` column of
        # the MOD's triggers.txt, GJEffectManager's m_touchTriggered -- and
        # lv22's first coin is behind seven of them (a counter reaches 5 and a
        # Move brings the coin into reach).
        #
        # WHY A RIG AND NOT THE LEVEL: on lv22 the two runs that looked like an
        # answer differed in the button AND in the trajectory, because for a
        # cube the button IS the trajectory. The reference run passed the boxes
        # at |dy|=36 with a gate of 30 -- it never entered them -- so "it did
        # not fire" was geometry, not input. Here the box sits ON the player's
        # own line, so a run with NO INPUT AT ALL goes straight through it.
        #   A  x=1200  coin in group 50, switched OFF at x=300; a touch-
        #              triggered TOGGLE ON at x=600, at the player's own y
        #   B  x=1800  coin in group 51, switched OFF at x=300; the same toggle
        #              at x=1500 STACKED eight high (ref .. ref+210), so a
        #              jumping player is inside one of them whatever the arc
        #   C  x=2400  coin in group 52, switched OFF at x=360 and NEVER turned
        #              back on -- the control WITHOUT it, "A was credited" reads
        #              equally as "the flag fired with no input" and as "the OFF
        #              never took effect", and the first cut of this rig could
        #              not tell those apart (every station came back credited)
        # A GD level holds THREE user coins and drops the rest, so there is no
        # room for a fourth "plain" station -- the first cut of this rig already
        # credited a plain coin (uid14, no group) on the same floor, which is
        # the "this run credits coins at all" control, spent.
        # Run it with no input: if A is credited while C is not, the flag does
        # not ask for the button and markTouched's box-only test is right. Then
        # run it holding: B answers the same question off the ground.
        objs.append(_coin_in_group(1200.0, ref + 30.0, 50))
        objs.append(_coin_in_group(1800.0, ref + 30.0, 51))
        objs.append(_coin_in_group(2400.0, ref + 30.0, 52))
        objs.append(obj(TRIG_TOGGLE, 300.0, ref + 60.0, extra={
            K_TARGET: "50", K_ACTIVATE: "0"}))
        objs.append(obj(TRIG_TOGGLE, 330.0, ref + 60.0, extra={
            K_TARGET: "51", K_ACTIVATE: "0"}))
        objs.append(obj(TRIG_TOGGLE, 360.0, ref + 60.0, extra={
            K_TARGET: "52", K_ACTIVATE: "0"}))
        # 11 = "touch triggered" in the level string. NOT MEASURED -- but the
        # rig closes it itself: the MOD dumps m_touchTriggered back as the
        # `touch` column of triggers.txt, so a wrong key reads as a 0 there
        # before any conclusion rests on it (the caveat build_coingate carries).
        objs.append(obj(TRIG_TOGGLE, 600.0, ref, extra={
            K_TARGET: "50", K_ACTIVATE: "1", 11: "1"}))
        for i in range(8):
            objs.append(obj(TRIG_TOGGLE, 1500.0, ref + 30.0 * i, extra={
                K_TARGET: "51", K_ACTIVATE: "1", 11: "1"}))
        UNITS.append({"touch_key": 11,
                      "stations": "A=flat B=stacked C=off_forever"})
        for x0, kind in ((1200.0, "touchflag_on_the_line"),
                         (1800.0, "touchflag_stacked"),
                         (2400.0, "off_and_never_on")):
            UNITS.append({"x0": x0 - 300.0, "x1": x0 + 300.0, "coin_x": x0,
                          "id": COIN_USER, "kind": kind, "variant": 7,
                          "player_y_assumed": ref})
        objs += floor_run(0, 3900.0)
        return header() + ";" + ";".join(objs) + ";"
    elif COINGATE["variant"] == 5:
        # THE TOUCH TRIGGER (1595), which is not the same thing as a trigger
        # marked "touch triggered": this one fires on the PLAYER'S TAP. lv22's
        # third coin is behind one (a tap chain feeds an Item Compare that
        # switches the coin's group on), so what has to be established is when
        # it fires -- on any tap, or only while the player is inside it, or only
        # after it has been crossed.
        #   A  x=600   a coin in group 30, switched OFF at x=300
        #   the Touch trigger sits at x=900, target 30, activate=1
        #   B  x=1200  the same group -- so both stations answer at once
        #   C  x=1800  a plain coin, the control that the run itself is sane
        # Run it twice: with the rig's .plan.txt (a tap at t=520, i.e. around
        # x=715, BEFORE the trigger's x) and without any input at all.
        objs.append(_coin_in_group(xs[0], ref + 30.0, 30))
        objs.append(_coin_in_group(xs[1], ref + 30.0, 30))
        objs.append(obj(COIN_USER, xs[2], ref + 30.0))
        objs.append(obj(TRIG_TOGGLE, 300.0, ref, extra={
            K_TARGET: "30", K_ACTIVATE: "0"}))
        objs.append(obj(TRIG_TOUCH, 900.0, ref, extra={
            K_TARGET: "30", K_ACTIVATE: "1", K_DURATION: "0"}))
        kinds = ["group30_before_trigger", "group30_after_trigger", "plain"]
    elif COINGATE["variant"] == 4:
        # WHAT IS THE MOVE OFFSET'S UNIT? Three coins 150 above the player's
        # centre (out of reach: 150 > the measured 35), each pulled down by a
        # different amount. Under "1 unit = 1 px" the -120 and -180 stations land
        # at dy 30 and -30 and are credited; under 1/3 px none is; under 3 px
        # only the -60 one is. The `coingd:` line's obj y says it outright.
        for i, dv in enumerate((-60, -120, -180)):
            objs.append(_coin_in_group(xs[i], ref + 150.0, 20 + i))
            objs.append(obj(TRIG_MOVE, xs[i] - 300.0, ref, extra={
                K_TARGET: str(20 + i), K_MOVE_X: "0", K_MOVE_Y: str(dv),
                K_DURATION: "0.2"}))
        kinds = ["move_-60", "move_-120", "move_-180"]
    else:
        objs.append(_coin_in_group(xs[0], ref + 30.0, 11))
        objs.append(_coin_in_group(xs[1], ref + 30.0, 12))
        objs.append(_coin_in_group(xs[2], ref + 120.0, 13))
        objs.append(obj(TRIG_TOGGLE, 300.0, ref, extra={
            K_TARGET: "11", K_ACTIVATE: "0"}))
        objs.append(obj(TRIG_TOGGLE, 450.0, ref + 60.0, extra={
            K_TARGET: "11", K_ACTIVATE: "1"}))
        objs.append(obj(TRIG_ALPHA, 900.0, ref, extra={
            K_TARGET: "12", K_OPACITY: "0", K_DURATION: "0"}))
        objs.append(obj(TRIG_ALPHA, 1050.0, ref + 60.0, extra={
            K_TARGET: "12", K_OPACITY: "1", K_DURATION: "0"}))
        objs.append(obj(TRIG_MOVE, 1500.0, ref, extra={
            K_TARGET: "13", K_MOVE_X: "0", K_MOVE_Y: "-30",
            K_DURATION: "0.5"}))
        kinds = ["toggle_off_then_on", "alpha_0_then_1", "moved_into_reach"]
    for x0, kind in zip(xs, kinds):
        UNITS.append({"x0": x0 - 300.0, "x1": x0 + 300.0, "coin_x": x0,
                      "id": COIN_USER, "kind": kind,
                      "variant": COINGATE["variant"],
                      "player_y_assumed": ref})
    objs += floor_run(0, xs[-1] + 900.0)
    return header() + ";" + ";".join(objs) + ";"


def build_coingate2() -> str:
    COINGATE["variant"] = 2
    return build_coingate()


def build_coingate3() -> str:
    COINGATE["variant"] = 3
    return build_coingate()


def build_coingate4() -> str:
    COINGATE["variant"] = 4
    return build_coingate()


def build_coingate5() -> str:
    COINGATE["variant"] = 5
    return build_coingate()


def build_coingate6() -> str:
    COINGATE["variant"] = 6
    return build_coingate()


def build_coingate7() -> str:
    COINGATE["variant"] = 7
    return build_coingate()


def build_coingate8() -> str:
    COINGATE["variant"] = 8
    return build_coingate()


# ---- Coins behind something entered FIRST (route rigs, 2026-09-26) ------------
# Not calibration rigs: small levels whose coins each need a box or a key entered
# before they can be taken, some of them far before, so that what the loop does
# about a coin's prerequisite can be measured without a real level's model
# divergences or its weight in the way. The prerequisites are read by the mod's
# own census (src/solver/route.hpp); nothing here is handed to the solver.
# SYNTHETIC: every object below is placed by this file (data/rigs/route1.lvl and route2.lvl are its
# output). They are not copies or excerpts of any published level; the only thing borrowed is the
# key object's id and property set, which an official level (SubZero) uses.
KEY_OBJ = 1275          # SubZero 4002's key (uid 6166): 36=1, 51 target, 382=1, 56=1
K_TOUCH = 11            # "touch triggered" (build_coingate variant 7)


def build_route1() -> str:
    u"""Three coins on one cube floor at 1x.

      A  x=600   a plain coin on the floor line -- the control
      C  x=2400  a coin in group 11, switched OFF at the start and ON by a
                 touch-triggered Toggle at (2250, 165): a LOCAL box, one jump
                 before the coin, above the floor line (any jump reaches it, the
                 floor line passes 30 px under it)
      B  x=3250  a coin at y=255 over a platform in group 10 (blocks at y=150,
                 x=3100..3400), switched OFF at the start and ON by the KEY at
                 (1400, 185) -- 1,850 px earlier, on a raised platform (blocks
                 at y=150, x=1110..1710) reached only by a jump from a step
                 block at x=1000. The floor line passes under both raised
                 platforms (15 px clear). Without the platform at x=3250 the
                 coin is out of reach (a jump from the step at x=2990 tops out
                 about 55 px short); with it, a jump from the platform reaches it.

    Heights (world): floor top 90, a cube on it at 105; a jump rises about 65
    (the first cut assumed 72 and put C's box out of reach -- the DP dropped
    every state at the box's far edge); a step block tops at 120; the raised
    platforms are 135..165.
    """
    objs: list[str] = []
    # coins
    objs.append(obj(COIN_USER, 600.0, GROUND_TOP + 15.0))
    objs.append(_coin_in_group(2400.0, GROUND_TOP + 15.0, 11))
    objs.append(_coin_in_group(3250.0, 255.0, 12))   # the coin itself is not switched
    # C: off at the start, on by a touch box
    objs.append(obj(TRIG_TOGGLE, -29.0, 300.0, extra={K_TARGET: "11", K_ACTIVATE: "0"}))
    objs.append(obj(TRIG_TOGGLE, 2250.0, 165.0, extra={K_TARGET: "11", K_ACTIVATE: "1",
                                                      K_TOUCH: "1"}))
    # B: the platform under the coin, off at the start
    objs.append(obj(TRIG_TOGGLE, -29.0, 330.0, extra={K_TARGET: "10", K_ACTIVATE: "0"}))
    x = 3100.0
    while x <= 3400.0:
        objs.append(obj(BLOCK, x, 150.0, extra={K_GROUPS: "10"}))
        x += GRID
    objs.append(obj(BLOCK, 2990.0, GROUND_TOP + 15.0))        # the step up to it
    # B's key, on the raised platform far before, and the step up to that
    objs.append(obj(BLOCK, 1000.0, GROUND_TOP + 15.0))
    x = 1110.0
    while x <= 1710.0:
        objs.append(obj(BLOCK, x, 150.0))
        x += GRID
    objs.append(obj(KEY_OBJ, 1400.0, 185.0, extra={36: "1", K_TARGET: "10", 382: "1",
                                                  K_ACTIVATE: "1"}))
    for x0, kind in ((600.0, "plain"), (2400.0, "local_box"), (3250.0, "far_key")):
        UNITS.append({"x0": x0 - 300.0, "x1": x0 + 300.0, "coin_x": x0, "id": COIN_USER,
                      "kind": kind})
    # Floor LAST = larger uids (build_ramps' lesson).
    objs += floor_run(0, 4200.0)
    return header() + ";" + ";".join(objs) + ";"


def _raised(x0: float, x1: float, group: str | None = None) -> list[str]:
    """A raised platform (blocks centred at y=150: 135..165) the floor line passes under."""
    out, x = [], x0
    while x <= x1:
        out.append(obj(BLOCK, x, 150.0, extra={K_GROUPS: group} if group else None))
        x += GRID
    return out


def build_route2() -> str:
    u"""A CHAIN: coin B needs key K2, and K2's ledge needs key K1 -- 5,600 px of floor
    between K1 and the coin, with a local box and a plain coin on the way.

      A   x=600    plain coin, the control
      K1  x=1400   key on raised platform R1 (x=1110..1710, from the step at x=1000);
                   switches ON group 11 = the step P0 at x=3500
      K2  x=3700   key on raised platform R2 (x=3610..4210); the only way up is the
                   step P0, off from the start -- without K1 the floor line passes
                   under R2; switches ON group 10 = the platform P1 under coin B
      C   x=5200   coin in group 12, off from the start, on by a touch box at
                   (5050, 165) -- local, one jump before it
      B   x=7000   coin at y=255 over P1 (x=6850..7150, group 10, off from the
                   start); the step up to it at x=6740 is always there
    Heights as in route1. Nothing here is handed to the solver: the mod's census
    reads the chain off the objects (src/solver/route.hpp).
    """
    objs: list[str] = []
    objs.append(obj(COIN_USER, 600.0, GROUND_TOP + 15.0))
    objs.append(_coin_in_group(5200.0, GROUND_TOP + 15.0, 12))
    objs.append(_coin_in_group(7000.0, 255.0, 13))
    for g, yy in (("10", 300.0), ("11", 330.0), ("12", 360.0)):
        objs.append(obj(TRIG_TOGGLE, -29.0, yy, extra={K_TARGET: g, K_ACTIVATE: "0"}))
    # K1 and its ledge
    objs.append(obj(BLOCK, 1000.0, GROUND_TOP + 15.0))
    objs += _raised(1110.0, 1710.0)
    objs.append(obj(KEY_OBJ, 1400.0, 185.0, extra={36: "1", K_TARGET: "11", 382: "1",
                                                  K_ACTIVATE: "1"}))
    # K2, its ledge and the step only K1 brings
    objs.append(obj(BLOCK, 3500.0, GROUND_TOP + 15.0, extra={K_GROUPS: "11"}))
    objs += _raised(3610.0, 4210.0)
    objs.append(obj(KEY_OBJ, 3700.0, 185.0, extra={36: "1", K_TARGET: "10", 382: "1",
                                                  K_ACTIVATE: "1"}))
    # C's local box
    objs.append(obj(TRIG_TOGGLE, 5050.0, 165.0, extra={K_TARGET: "12", K_ACTIVATE: "1",
                                                      K_TOUCH: "1"}))
    # B: the step and the platform K2 brings
    objs.append(obj(BLOCK, 6740.0, GROUND_TOP + 15.0))
    objs += _raised(6850.0, 7150.0, "10")
    for x0, kind in ((600.0, "plain"), (5200.0, "local_box"), (7000.0, "chain_k1_k2")):
        UNITS.append({"x0": x0 - 300.0, "x1": x0 + 300.0, "coin_x": x0, "id": COIN_USER,
                      "kind": kind})
    objs += floor_run(0, 7800.0)
    return header() + ";" + ";".join(objs) + ";"


# ---- spider pad (id 3005, GameObjectType 44) --------------------------------
#
# What GD does with one (2.2081; the reading is in the commit that added this rig):
# collisionCheckObjects sends type 44 to the same block as the yellow / pink / red
# pads, GJBaseGameLayer::bumpPlayer (0x2179d0) at bumpMod 1.0, and only the player
# side tells them apart. PlayerObject::bumpPlayer (0x39f6a0), type 44: when the
# pad's facing (isFacingDown, or isFacingLeft with sideways gravity) differs from
# the player's gravity it first flips the gravity (noEffects), then runs
# spiderTestJumpInternal(false) -- the spider's own teleport to the surface on the
# other side -- and the same event and rotation set as spiderTestJump. The gate is
# canBeActivatedByPlayer: once per player per attempt unless the pad is Multi
# Activate. This rig produces those situations one at a time; the probe injects
# x / y / vy before each pad.
SPIDER_PAD = 3005
SP_PITCH = 30 * GRID          # one unit; nothing of one reaches the next
SP_CEIL_BOTTOM = GROUND_TOP + 4 * GRID   # a 120 px corridor: floor 90, ceiling 210
# Every portal goes in twice, at 105 and at 195: one copy for a player on the
# floor, one for a player under the ceiling, at either size. A single copy at
# the corridor's middle (112..187 for a 75 px portal) misses a mini player at
# rest on either surface (90..108 / 192..210) -- the first run of this rig lost
# its mini units that way.
SP_PORTAL_YS = (GROUND_TOP + 15.0, SP_CEIL_BOTTOM - 15.0)


def spiderpad_unit(x: float, mode: str, mini: bool, flip: bool, where: str,
                   rot: float, fy: bool, ceil: bool = True,
                   floor_blocks: bool = False, blocks_first: bool = False
                   ) -> tuple[list[str], float, dict]:
    """One spider pad, met with no input.

    Every unit starts by putting the player in a known state, whatever the last
    one left: normal gravity (a teleport ends upside down on the ceiling), the
    unit's mode, its size, and -- when `flip` -- the inverting gravity portal,
    after which the player rides the ceiling. The pad sits on the floor (`where`
    = "floor") or under the ceiling ("ceil"), turned by `rot` and flipped by `fy`.
    `ceil=False` leaves the corridor open above the pad: no surface for the
    teleport to find.

    Where the teleport lands, and on which tick, may depend on what it lands on
    and on where that object comes in the collision pass the pad fires from:
    `floor_blocks` lays blocks flush with the world ground (top 90) under the
    pad's stretch, and `blocks_first` writes the unit's blocks ahead of the pad
    in the level string instead of after it.
    """
    objs: list[str] = []
    for py in SP_PORTAL_YS:
        objs.append(obj(GRAV_NORM, x, py))
        objs.append(obj(MODE_PORTAL[mode], x + 2 * GRID, py))
        objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 4 * GRID, py))
        if flip:
            objs.append(obj(GRAV_FLIP, x + 6 * GRID, py))
    x_pad = x + 14 * GRID
    y_pad = GROUND_TOP + 5.0 if where == "floor" else SP_CEIL_BOTTOM - 5.0
    pad = [obj(SPIDER_PAD, x_pad, y_pad, rot=rot, flip_y=fy)]
    blocks: list[str] = []
    if ceil:
        cx = x
        while cx < x + SP_PITCH:
            blocks.append(obj(BLOCK, cx, SP_CEIL_BOTTOM + GRID / 2))
            cx += GRID
    if floor_blocks:
        blocks += floor_run(x_pad - 6 * GRID, x_pad + 6 * GRID)
    objs += (blocks + pad) if blocks_first else (pad + blocks)
    meta = {"x0": x, "x1": x + SP_PITCH, "mode": mode, "mini": int(mini),
            "flip": int(flip), "where": where, "rot": rot, "fy": int(fy),
            "ceil": int(ceil), "floor_blocks": int(floor_blocks),
            "blocks_first": int(blocks_first), "pad_x": x_pad, "pad_y": y_pad,
            "floor_top": GROUND_TOP, "ceil_bottom": SP_CEIL_BOTTOM,
            "t_pad": tick_at(x_pad)}
    return objs, x + SP_PITCH, meta


def build_spiderpad() -> str:
    """Spider pad rig: the facing cases with a cube, every mode, mini, and a pad
    with nothing above it (last, as it may leave the player anywhere)."""
    units = [
        # mode, mini, flip, where, rot, fy
        ("cube", False, False, "floor", 0.0, False),     # facing up, normal gravity
        ("cube", False, True, "ceil", 180.0, False),     # facing down, upside down
        ("cube", False, False, "floor", 0.0, True),      # flipY: facing down, gravity flipped first
        ("cube", False, True, "ceil", 180.0, True),      # 180 + flipY: facing up, flipped first
        ("cube", False, False, "floor", 180.0, False),   # turned 180 on the floor: facing down
        ("cube", False, False, "floor", 170.0, False),   # off the quarter turn, inside [91,269]
        ("cube", False, False, "floor", 10.0, False),    # off the quarter turn, outside it
        ("ship", False, False, "floor", 0.0, False),
        ("ball", False, False, "floor", 0.0, False),
        ("ufo", False, False, "floor", 0.0, False),
        ("wave", False, False, "floor", 0.0, False),
        ("robot", False, False, "floor", 0.0, False),
        ("spider", False, False, "floor", 0.0, False),
        ("swing", False, False, "floor", 0.0, False),
        ("cube", True, False, "floor", 0.0, False),
        ("ship", True, False, "floor", 0.0, False),
        ("cube", True, True, "ceil", 180.0, False),
    ]
    objs: list[str] = []
    x = 300.0
    for mode, mini, flip, where, rot, fy in units:
        u, x, meta = spiderpad_unit(x, mode, mini, flip, where, rot, fy)
        objs += u
        UNITS.append(meta)
    # The landing surface and its place in the collision pass: up onto a ceiling
    # written ahead of the pad; down onto a floor of blocks written after it, and
    # ahead of it.
    for mode, mini, flip, where, rot, fy, fb, first in (
            ("cube", False, False, "floor", 0.0, False, False, True),
            ("cube", False, True, "ceil", 180.0, False, True, False),
            ("cube", False, True, "ceil", 180.0, False, True, True)):
        u, x, meta = spiderpad_unit(x, mode, mini, flip, where, rot, fy,
                                    floor_blocks=fb, blocks_first=first)
        objs += u
        UNITS.append(meta)
    u, x, meta = spiderpad_unit(x, "cube", False, False, "floor", 0.0, False, ceil=False)
    objs += u
    UNITS.append(meta)
    return header() + ";" + ";".join(objs) + ";"


# --- Gravity toggle portal (id 2926, GameObjectType 42) --------------------
# Read from the binary (GJBaseGameLayer::collisionCheckObjects 0x214960, jump
# table 0x215fe0, type 42 -> 0x214dc1): the same block as the two gravity
# portals (type 3 -> 0x214c47, type 4 -> 0x214d04) -- the canBeActivatedByPlayer
# gate, the portal position kept, flipGravity, the activated mark, an event --
# except that the gravity it asks for is the opposite of the player's
# upside-down byte (+0x9bf) at the moment it fires. Nothing reads its facing.
# So two toggles touched on the same tick should cancel, and a toggle fires once
# per attempt like any portal without Multi Activate. Its hitbox is 23.75 x 75.5
# (objrects of the custom levels holding one).
GRAV_TOGGLE = 2926
GT_H = 75.5
GT_PITCH = 30 * GRID


def gravtoggle_unit(x: float, mode: str, mini: bool, flip: bool, where: str,
                    rot: float = 0.0, fy: bool = False, second: str = "",
                    reenter: bool = False) -> tuple[list[str], float, dict]:
    """One gravity toggle, met with no input.

    The preamble puts the player in a known state (normal gravity, the unit's
    mode and size, and the inverting portal when `flip`), as in the spider pad
    rig. The toggle stands on the floor (`where` = "floor") or hangs from the
    ceiling ("ceil"). `second` adds another toggle: "same" at the same place
    (both touched on one tick), "near" 6 px further on (a few ticks later), and
    "far" eight blocks on at the other surface (after the player has crossed
    the corridor). `reenter` turns the toggle on its side, low on the floor, with
    a normal-gravity portal (also on its side) above it, so the player leaves the
    toggle upward, is turned back, and falls into it again while still inside
    its x span.
    """
    objs: list[str] = []
    for py in SP_PORTAL_YS:
        objs.append(obj(GRAV_NORM, x, py))
        objs.append(obj(MODE_PORTAL[mode], x + 2 * GRID, py))
        objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 4 * GRID, py))
        if flip:
            objs.append(obj(GRAV_FLIP, x + 6 * GRID, py))
    x_t = x + 14 * GRID
    if reenter:
        # On its side the toggle is 75.5 wide and 23.75 tall: floor 90 .. 113.75.
        y_t = GROUND_TOP + 23.75 / 2
        objs.append(obj(GRAV_TOGGLE, x_t, y_t, rot=90.0))
        # The turning portal's bottom edge at 145: a cube (30) touching it has
        # its bottom at 130, clear of the toggle's top.
        objs.append(obj(GRAV_NORM, x_t, 145.0 + 12.5, rot=90.0))
    else:
        y_t = GROUND_TOP + GT_H / 2 if where == "floor" else SP_CEIL_BOTTOM - GT_H / 2
        objs.append(obj(GRAV_TOGGLE, x_t, y_t, rot=rot, flip_y=fy))
    x_2 = None
    if second == "same":
        x_2 = x_t
        objs.append(obj(GRAV_TOGGLE, x_2, y_t))
    elif second == "near":
        x_2 = x_t + 6.0
        objs.append(obj(GRAV_TOGGLE, x_2, y_t))
    elif second == "far":
        x_2 = x_t + 8 * GRID
        y_2 = SP_CEIL_BOTTOM - GT_H / 2 if where == "floor" else GROUND_TOP + GT_H / 2
        objs.append(obj(GRAV_TOGGLE, x_2, y_2))
    if mode == "wave":
        # A wave dies on the ceiling's blocks (the first run of this rig ended
        # there, t=5479), so its unit has no ceiling: a normal-gravity portal
        # high up turns it back down to the world floor.
        objs.append(obj(GRAV_NORM, x_t + 5 * GRID, 300.0))
    else:
        cx = x
        while cx < x + GT_PITCH:
            objs.append(obj(BLOCK, cx, SP_CEIL_BOTTOM + GRID / 2))
            cx += GRID
    meta = {"x0": x, "x1": x + GT_PITCH, "mode": mode, "mini": int(mini),
            "flip": int(flip), "where": where, "rot": 90.0 if reenter else rot,
            "fy": int(fy), "second": second, "reenter": int(reenter),
            "pad_x": x_t, "pad_y": y_t, "x_2": x_2,
            "floor_top": GROUND_TOP, "ceil_bottom": SP_CEIL_BOTTOM,
            "t_pad": tick_at(x_t)}
    return objs, x + GT_PITCH, meta


def build_gravtoggle() -> str:
    """Gravity toggle rig: both directions with a cube, every mode, mini, the
    facing that should not matter, two toggles at once / in quick succession /
    in a row, and a toggle entered twice."""
    units = [
        # mode, mini, flip, where, rot, fy, second, reenter
        ("cube", False, False, "floor", 0.0, False, "", False),    # normal -> upside down
        ("cube", False, True, "ceil", 0.0, False, "", False),      # upside down -> normal
        ("ship", False, False, "floor", 0.0, False, "", False),
        ("ship", False, True, "ceil", 0.0, False, "", False),
        ("ball", False, False, "floor", 0.0, False, "", False),
        ("ball", False, True, "ceil", 0.0, False, "", False),
        ("ufo", False, False, "floor", 0.0, False, "", False),
        ("wave", False, False, "floor", 0.0, False, "", False),
        ("robot", False, False, "floor", 0.0, False, "", False),
        ("spider", False, False, "floor", 0.0, False, "", False),
        ("swing", False, False, "floor", 0.0, False, "", False),
        ("cube", True, False, "floor", 0.0, False, "", False),
        ("cube", True, True, "ceil", 0.0, False, "", False),
        ("cube", False, False, "floor", 180.0, False, "", False),  # facing: read by nothing
        ("cube", False, False, "floor", 0.0, True, "", False),
        ("cube", False, False, "floor", 0.0, False, "far", False),   # two in a row
        ("cube", False, False, "floor", 0.0, False, "same", False),  # two on one tick
        ("cube", False, False, "floor", 0.0, False, "near", False),  # two, a few ticks apart
        ("cube", False, False, "floor", 0.0, False, "", True),       # entered twice
    ]
    objs: list[str] = []
    x = 300.0
    for mode, mini, flip, where, rot, fy, second, reenter in units:
        u, x, meta = gravtoggle_unit(x, mode, mini, flip, where, rot, fy, second, reenter)
        objs += u
        UNITS.append(meta)
    return header() + ";" + ";".join(objs) + ";"


# --- Teleport trigger (id 3022) --------------------------------------------
# Read from the binary: EffectGameObject::triggerObject (0x4a5f30) sends id 3022
# to GJBaseGameLayer::teleportPlayer (0x20fdb0) with no player, which then
# takes m_player1. With no linked exit it moves the player to the target
# group's object (a random one when there are several), keeps x / y under
# m_ignoreX (352) / m_ignoreY (353), adds (player - trigger) under
# m_saveOffset (351), and sets gravity by m_gravityMode (354: 1 normal,
# 2 flipped, 3 toggle). Unlike the portals it leaves no activated mark.
# The target here is a Spawn trigger with no target of its own: it holds a
# position, does not collide, and crossing it does nothing.
TELEPORT_TRIG = 3022
TP_MARK = 1268
TP_PITCH = 30 * GRID
TP_CEIL_BOTTOM = 330.0
K_SAVE_OFFSET, K_IGNORE_X, K_IGNORE_Y, K_GRAV_MODE = 351, 352, 353, 354
K_STATIC_FORCE_ON, K_STATIC_FORCE = 345, 346


def teleporttrig_unit(x: float, i: int, mode: str = "cube", mini: bool = False,
                      flip: bool = False, ty: float = 300.0, dx: float = 0.0,
                      ignx: bool = False, igny: bool = False, grav: int = 0,
                      save: bool = False, trig_y: float = 105.0, force: float = 0.0,
                      chain_ty: float | None = None) -> tuple[list[str], float, dict]:
    """One teleport trigger, met with no input, on a paved floor with no ceiling.

    The preamble puts the player in a known state (normal gravity, mode, size,
    and the inverting portal when `flip`). The trigger stands at x0 + 14 blocks
    at `trig_y` (it fires on the x crossing, so its height only matters to
    m_saveOffset); its target is `dx` further on at height `ty`. `chain_ty` adds a
    second trigger 40 px later aiming at that height, to catch the player while
    it falls from the first.
    """
    objs: list[str] = []
    for py in SP_PORTAL_YS:
        objs.append(obj(GRAV_NORM, x, py))
        objs.append(obj(MODE_PORTAL[mode], x + 2 * GRID, py))
        objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 4 * GRID, py))
        if flip:
            objs.append(obj(GRAV_FLIP, x + 6 * GRID, py))
    objs += floor_run(x, x + TP_PITCH - GRID)
    x_t = x + 14 * GRID
    g = 100 + 2 * i
    props: dict[int, str] = {K_TARGET: str(g)}
    if ignx:
        props[K_IGNORE_X] = "1"
    if igny:
        props[K_IGNORE_Y] = "1"
    if grav:
        props[K_GRAV_MODE] = str(grav)
    if save:
        props[K_SAVE_OFFSET] = "1"
    if force:
        props[K_STATIC_FORCE_ON] = "1"
        props[K_STATIC_FORCE] = f"{force:g}"
    objs.append(obj(TELEPORT_TRIG, x_t, trig_y, extra=props))
    objs.append(obj(TP_MARK, x_t + dx, ty, extra={K_GROUPS: str(g)}))
    x_2 = None
    if chain_ty is not None:
        x_2 = x_t + 40.0
        objs.append(obj(TELEPORT_TRIG, x_2, trig_y, extra={K_TARGET: str(g + 1)}))
        objs.append(obj(TP_MARK, x_2, chain_ty, extra={K_GROUPS: str(g + 1)}))
    ceil = flip or grav in (2, 3)
    if ceil:
        # An upside-down body needs something to rest under (ceiling bottom 330), and the next
        # unit's preamble portals (105 / 195) cannot reach it there: normal gravity comes back
        # at the unit's end, at three heights.
        cx = x
        while cx < x + TP_PITCH:
            objs.append(obj(BLOCK, cx, TP_CEIL_BOTTOM + GRID / 2))
            cx += GRID
        for py in (105.0, 195.0, 285.0):
            objs.append(obj(GRAV_NORM, x + TP_PITCH - 2 * GRID, py))
    meta = {"x0": x, "x1": x + TP_PITCH, "mode": mode, "mini": int(mini), "flip": int(flip),
            "ceil_bottom": TP_CEIL_BOTTOM if ceil else None,
            "pad_x": x_t, "trig_y": trig_y, "target": [x_t + dx, ty], "dx": dx,
            "ignx": int(ignx), "igny": int(igny), "grav": grav, "save": int(save),
            "force": force, "x_2": x_2, "chain_ty": chain_ty, "t_pad": tick_at(x_t)}
    return objs, x + TP_PITCH, meta


def build_tpback() -> str:
    """Teleport back rig (dp --tpback): does a passed crossing trigger fire again after a teleport
    moves the player back? A cube on a paved floor, no input. Gravity triggers at x 300 (0.5) and
    600 (2); a teleport trigger at x 900 whose target, a Spawn marker, stands at (200, 105); a gravity
    trigger at 1,500 (1). Measured 2026-10-13: GD jumps back on t=695, keeps gravityMod 2 across 300
    and 600 again, does not teleport at 900 again, and changes to 1 at x 1,500.85 -- the crossing queue
    (checkSpawnObjects 0x21a8f0) only moves forward.
    """
    objs = floor_run(0.0, 3600.0)
    objs.append(obj(GRAV_TRIG, 300.0, 165.0, extra={K_GRAV_VALUE: "0.5"}))
    objs.append(obj(GRAV_TRIG, 600.0, 165.0, extra={K_GRAV_VALUE: "2"}))
    objs.append(obj(TELEPORT_TRIG, 900.0, 165.0, extra={K_TARGET: "7"}))
    objs.append(obj(TP_MARK, 200.0, 105.0, extra={K_GROUPS: "7"}))
    objs.append(obj(GRAV_TRIG, 1500.0, 165.0, extra={K_GRAV_VALUE: "1"}))
    return header() + ";" + ";".join(objs) + ";"


def build_teleporttrig() -> str:
    """Teleport trigger rig: up into the air in every mode, sideways with and
    without ignoreX, straight up (does x snap back to the target's?), ignoreY,
    the three gravity modes, saveOffset, a static force, and a second trigger
    caught in the fall."""
    units = [
        dict(),                                   # cube, straight up to 300
        dict(dx=60.0),                            # sideways, x not kept
        dict(dx=60.0, ignx=True),                 # sideways, x kept
        dict(igny=True),                          # y kept: only the x part, which is 0
        dict(flip=True, grav=1, ty=150.0),        # upside down -> forced normal
        dict(grav=2, ty=150.0),                   # forced upside down
        dict(grav=3, ty=150.0),                   # toggle
        dict(save=True, trig_y=45.0),             # + (player - trigger) = +60 in y
        dict(force=10.0),                         # static force 10
        dict(chain_ty=200.0),                     # caught again while falling
        dict(mode="ship"), dict(mode="ball"), dict(mode="ufo"), dict(mode="wave"),
        dict(mode="robot"), dict(mode="spider"), dict(mode="swing"),
        dict(mini=True),
    ]
    objs: list[str] = []
    x = 300.0
    for i, kw in enumerate(units):
        u, x, meta = teleporttrig_unit(x, i, **kw)
        objs += u
        UNITS.append(meta)
    return header() + ";" + ";".join(objs) + ";"


# --- Teleport portal velocity (2902 / 747) ---------------------------------
# Read from the binary: after the move, GJBaseGameLayer::teleportPlayer
# (0x20fdb0) sets the player's velocity from the portal's force. A redirected
# force (347; mod 350, min 348, max 349) goes to PlayerObject::redirectPlayerForce
# (0x39fc60); otherwise a static force (345, strength 346) sets vy to the force
# along a direction, or adds it with 443; a static force of 0 that does not add
# stops the player. The direction comes from the exit: (exit flipped in x ? 180 :
# 0) + (a portal-like exit ? 180 : 90) - the exit's rotation, in degrees. Each
# unit runs one 2902 (or 747) at the player's height, no input, and lands it at a
# marker, as the 3022 rig does; a `chain` unit adds a second portal that keeps x
# and y (352, 353) a little further on, met while falling, so that only its
# velocity shows.
TP_PORTAL, TP_PORTAL_OLD = 2902, 747
K_REDIRECT_ON, K_REDIRECT_MIN, K_REDIRECT_MAX, K_REDIRECT_MOD = 347, 348, 349, 350
K_FORCE_ADD, K_TP_YOFFSET, K_NO_TOUCH = 443, 54, 121


def tpportal_unit(x: float, i: int, mode: str = "cube", mini: bool = False,
                  flip: bool = False, ty: float = 200.0, kind: int = TP_PORTAL,
                  prot: float = 0.0, yoff: float = 120.0, igny: bool = False,
                  grav: int = 0, force: float | None = None, add: bool = False,
                  redirect: tuple[float, float, float] | None = None,
                  exit_kind: str = "mark", exit_rot: float = 0.0, exit_fx: bool = False,
                  two_exits: bool = False, chain: dict | None = None
                  ) -> tuple[list[str], float, dict]:
    """One teleport portal 14 blocks in, at the resting player's height, no input.

    `force` is the static force (None: off); `redirect` is (mod, min, max). The
    exit is a marker (`exit_kind` "mark", a Spawn trigger) or a No Touch 2902
    ("portal"), at (portal x, `ty`), turned `exit_rot` and flipped in x by
    `exit_fx`; `two_exits` puts a second marker 60 px above the first in the
    target group. A 747 (`kind`) uses its own orange half `yoff` above it instead.
    `chain` gives a second 2902, 60 px on, that keeps x and y: its own force /
    redirect / exit_rot, met by the player falling from the first one's exit.
    """
    objs: list[str] = []
    for py in SP_PORTAL_YS:
        objs.append(obj(GRAV_NORM, x, py))
        objs.append(obj(MODE_PORTAL[mode], x + 2 * GRID, py))
        objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 4 * GRID, py))
        if flip:
            objs.append(obj(GRAV_FLIP, x + 6 * GRID, py))
    objs += floor_run(x, x + TP_PITCH - GRID)
    x_p = x + 14 * GRID
    g = 400 + 3 * i

    def props_of(force_, add_, redirect_, igny_, ignx_, grav_, target) -> dict[int, str]:
        p: dict[int, str] = {}
        if target:
            p[K_TARGET] = str(target)
        if igny_:
            p[K_IGNORE_Y] = "1"
        if ignx_:
            p[K_IGNORE_X] = "1"
        if grav_:
            p[K_GRAV_MODE] = str(grav_)
        if force_ is not None:
            p[K_STATIC_FORCE_ON] = "1"
            p[K_STATIC_FORCE] = f"{force_:g}"
            if add_:
                p[K_FORCE_ADD] = "1"
        if redirect_ is not None:
            p[K_REDIRECT_ON] = "1"
            p[K_REDIRECT_MOD] = f"{redirect_[0]:g}"
            p[K_REDIRECT_MIN] = f"{redirect_[1]:g}"
            p[K_REDIRECT_MAX] = f"{redirect_[2]:g}"
        return p

    # A body at rest on the floor spans 90..120; under the ceiling (bottom 330), 300..330. The
    # 2902's box is 25x90.
    py_ = TP_CEIL_BOTTOM - 45.0 if flip else GROUND_TOP + 45.0
    if kind == TP_PORTAL_OLD and abs(prot) == 90.0:
        py_ = GROUND_TOP + 20.0   # turned, the box is 90x25: 97.5..122.5
    if kind == TP_PORTAL_OLD:
        p = props_of(force, add, redirect, igny, False, grav, 0)
        p[K_TP_YOFFSET] = f"{yoff:g}"
        objs.append(obj(TP_PORTAL_OLD, x_p, py_, rot=prot, extra=p))
    else:
        # x kept (352), as on lv22's: without it the body goes to the exit's x, 15 px on from
        # where the portal took it, which the model does not do (x is the search's clock)
        objs.append(obj(TP_PORTAL, x_p, py_, rot=prot,
                        extra=props_of(force, add, redirect, igny, True, grav, g)))
        if exit_kind == "portal":
            objs.append(obj(TP_PORTAL, x_p, ty, rot=exit_rot, flip_x=exit_fx,
                            extra={K_GROUPS: str(g), K_NO_TOUCH: "1"}))
        else:
            objs.append(obj(TP_MARK, x_p, ty, rot=exit_rot, flip_x=exit_fx,
                            extra={K_GROUPS: str(g)}))
        if two_exits:
            objs.append(obj(TP_MARK, x_p, ty + 60.0, extra={K_GROUPS: str(g)}))
    x_c = None
    if chain is not None:
        # 60 px on, scaled to 25x270 (90..360): the player falls through it from the exit at 200
        x_c = x_p + 60.0
        p = props_of(chain.get("force"), chain.get("add", False), chain.get("redirect"),
                     True, True, 0, g + 1)
        p[129] = "3"
        objs.append(obj(TP_PORTAL, x_c, 225.0, extra=p))
        objs.append(obj(TP_MARK, x_c, 400.0, rot=chain.get("exit_rot", 0.0),
                        extra={K_GROUPS: str(g + 1)}))
    ceil = flip or grav in (2, 3)
    if ceil:
        cx = x
        while cx < x + TP_PITCH:
            objs.append(obj(BLOCK, cx, TP_CEIL_BOTTOM + GRID / 2))
            cx += GRID
        for py in (105.0, 195.0, 285.0):
            objs.append(obj(GRAV_NORM, x + TP_PITCH - 2 * GRID, py))
    meta = {"x0": x, "x1": x + TP_PITCH, "mode": mode, "mini": int(mini), "flip": int(flip),
            "ceil_bottom": TP_CEIL_BOTTOM if ceil else None, "pad_x": x_p, "portal_y": py_,
            "kind": kind, "prot": prot, "yoff": yoff if kind == TP_PORTAL_OLD else None,
            "target": [x_p, ty], "igny": int(igny), "grav": grav, "force": force, "add": int(add),
            "redirect": list(redirect) if redirect else None, "exit_kind": exit_kind,
            "exit_rot": exit_rot, "exit_fx": int(exit_fx), "two_exits": int(two_exits),
            "chain": chain, "x_chain": x_c, "t_pad": tick_at(x_p)}
    return objs, x + TP_PITCH, meta


def build_tpportal() -> str:
    """Teleport portal velocity rig: the static force along the exit's direction (a
    marker turned or flipped, a portal exit, a 747's own half), added or at 0, with
    the gravity modes, upside down, in every mode and mini; the redirected force;
    a portal that keeps y; and a target group of two."""
    units = [
        dict(),                                                  # 0 no force
        dict(force=10.0),                                        # 1 marker 0 deg -> +10
        dict(force=10.0, exit_rot=45.0),                         # 2 -> 10 sin 45
        dict(force=10.0, exit_rot=-30.0),                        # 3 -> 10 sin 120
        dict(force=10.0, exit_fx=True),                          # 4 -> 10 sin 270
        dict(chain=dict(force=10.0, add=True)),                  # 5 added while falling
        dict(chain=dict(force=0.0)),                             # 6 force 0 while falling
        dict(force=10.0, exit_kind="portal"),                    # 7 portal exit 0 deg -> 0
        dict(force=10.0, exit_kind="portal", exit_rot=90.0),     # 8 portal exit 90 -> +10
        dict(kind=TP_PORTAL_OLD, force=10.0),                    # 9 747, its own half
        dict(kind=TP_PORTAL_OLD, prot=90.0, force=18.0, grav=1),  # 10 lv22's
        dict(force=10.0, grav=2, ty=150.0),                      # 11 forced upside down
        dict(force=10.0, flip=True, ty=150.0),                   # 12 upside down already
        dict(mode="ship", force=10.0), dict(mode="ball", force=10.0),
        dict(mode="ufo", force=10.0), dict(mode="wave", force=10.0),
        dict(mode="robot", force=10.0), dict(mode="spider", force=10.0),
        dict(mode="swing", force=10.0),
        dict(mini=True, force=10.0),                             # 20
        dict(redirect=(1.0, 0.0, 0.0)),                          # 21 on the floor
        dict(redirect=(1.0, 10.0, 0.0)),                         # 22 min 10
        dict(chain=dict(redirect=(2.0, 0.0, 0.0))),              # 23 x2 while falling
        dict(chain=dict(redirect=(1.0, 0.0, 3.0))),              # 24 max 3 while falling
        dict(chain=dict(redirect=(1.0, 0.0, 0.0), exit_rot=-45.0)),  # 25 to 135 deg
        dict(igny=True, force=10.0),                             # 26 y kept, pushed
        dict(igny=True, grav=2),                                 # 27 y kept, flipped
        dict(kind=TP_PORTAL_OLD, prot=90.0, igny=True, force=10.0),  # 28 747, y kept
        dict(two_exits=True),                                    # 29 two exits
    ]
    objs: list[str] = []
    x = 300.0
    for i, kw in enumerate(units):
        u, x, meta = tpportal_unit(x, i, **kw)
        objs += u
        UNITS.append(meta)
    return header() + ";" + ";".join(objs) + ";"


# --- Gravity trigger (id 2066) ---------------------------------------------
# Read from the binary: EffectGameObject::triggerObject (0x4a5f30, case 0x4a6e1c)
# writes the trigger's m_gravityValue (148) into the player's m_gravityMod
# (+0xb84) -- player 1, player 2 or both by m_targetPlayer1 / 2 (138 / 200), or
# the player that set it off by m_followCPP (201) -- and updateJump (0x38b900)
# multiplies every mode's gravity by it, the cube's (+0x7c8) and the flying
# modes' 0.958199 alike. This rig launches the player off a yellow pad after,
# or across, a gravity trigger and puts the gravity back at the unit's end.
GRAV_TRIG = 2066
K_GRAV_VALUE = 148
GT2_PITCH = 30 * GRID
GT2_CEIL_BOTTOM = 330.0


def gravtrig_unit(x: float, mode: str, mini: bool, value: float, midair: bool = False
                  ) -> tuple[list[str], float, dict]:
    """One gravity trigger and a yellow pad, no input, a paved floor and no ceiling.

    The trigger stands 4 blocks before the pad, or, with `midair`, 4 blocks after
    it, where the body is in the air; a second trigger at the unit's end sets the
    gravity back to 1.
    """
    objs: list[str] = []
    for py in SP_PORTAL_YS:
        objs.append(obj(GRAV_NORM, x, py))
        objs.append(obj(MODE_PORTAL[mode], x + 2 * GRID, py))
        objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 4 * GRID, py))
    objs += floor_run(x, x + GT2_PITCH - GRID)
    x_pad = x + 12 * GRID
    x_trig = x_pad + (4 * GRID if midair else -4 * GRID)
    objs.append(obj(PAD_YELLOW, x_pad, GROUND_TOP + 5.0))
    objs.append(obj(GRAV_TRIG, x_trig, 200.0, extra={K_GRAV_VALUE: f"{value:g}"}))
    x_back = x + GT2_PITCH - GRID
    objs.append(obj(GRAV_TRIG, x_back, 200.0, extra={K_GRAV_VALUE: "1"}))
    meta = {"x0": x, "x1": x + GT2_PITCH, "mode": mode, "mini": int(mini), "value": value,
            "midair": int(midair), "pad_x": x_trig, "jump_pad_x": x_pad, "back_x": x_back,
            "t_pad": tick_at(x_trig)}
    return objs, x + GT2_PITCH, meta


def build_gravtrig() -> str:
    """Gravity trigger rig: a cube at 0.5, 2 and 0.1, one switched on in the air,
    every other mode at 0.5, and a mini cube."""
    units = [
        ("cube", False, 0.5, False), ("cube", False, 2.0, False), ("cube", False, 0.5, True),
        ("ship", False, 0.5, False), ("ball", False, 0.5, False), ("ufo", False, 0.5, False),
        ("robot", False, 0.5, False), ("spider", False, 0.5, False), ("swing", False, 0.5, False),
        ("wave", False, 0.5, False), ("cube", True, 0.5, False), ("cube", False, 0.1, False),
    ]
    objs: list[str] = []
    x = 300.0
    for mode, mini, value, midair in units:
        u, x, meta = gravtrig_unit(x, mode, mini, value, midair)
        objs += u
        UNITS.append(meta)
    return header() + ";" + ";".join(objs) + ";"


def gravtrig2_unit(x: float, mode: str, value: float, hold: int
                   ) -> tuple[list[str], float, dict]:
    """A gravity trigger, then a press held `hold` ticks: what the value does to a
    press -- the ship's and robot's thrust, the UFO's and cube's impulse, the
    ball's, spider's and swing's gravity flip. The flipping modes get a ceiling
    (bottom 330) and normal gravity back at the unit's end, at three heights."""
    objs: list[str] = []
    for py in SP_PORTAL_YS:
        objs.append(obj(GRAV_NORM, x, py))
        objs.append(obj(MODE_PORTAL[mode], x + 2 * GRID, py))
        objs.append(obj(SIZE_NORM, x + 4 * GRID, py))
    objs += floor_run(x, x + GT2_PITCH - GRID)
    x_trig = x + 8 * GRID
    objs.append(obj(GRAV_TRIG, x_trig, 200.0, extra={K_GRAV_VALUE: f"{value:g}"}))
    x_press = x + 12 * GRID
    t_press = tick_at(x_press)
    PLAN.append((t_press, 1))
    PLAN.append((t_press + hold, 0))
    flips = mode in ("ball", "spider", "swing")
    if flips:
        cx = x
        while cx < x + GT2_PITCH:
            objs.append(obj(BLOCK, cx, GT2_CEIL_BOTTOM + GRID / 2))
            cx += GRID
        for py in (105.0, 195.0, 285.0):
            objs.append(obj(GRAV_NORM, x + GT2_PITCH - 3 * GRID, py))
    x_back = x + GT2_PITCH - GRID
    objs.append(obj(GRAV_TRIG, x_back, 200.0, extra={K_GRAV_VALUE: "1"}))
    meta = {"x0": x, "x1": x + GT2_PITCH, "mode": mode, "value": value, "hold": hold,
            "pad_x": x_trig, "press_x": x_press, "t_press": t_press, "back_x": x_back,
            "ceil_bottom": GT2_CEIL_BOTTOM if flips else None, "t_pad": tick_at(x_trig)}
    return objs, x + GT2_PITCH, meta


def build_gravtrig2() -> str:
    """Gravity trigger rig with presses: the ship held at 1 and at 0.5, the robot
    held, a UFO and a cube tapped, the ball, spider and swing flipped, the wave
    held."""
    units = [
        ("ship", 1.0, 60), ("ship", 0.5, 60), ("robot", 0.5, 30), ("ufo", 0.5, 3),
        ("cube", 0.5, 3), ("ball", 0.5, 3), ("spider", 0.5, 3), ("swing", 0.5, 3),
        ("wave", 0.5, 20),
    ]
    objs: list[str] = []
    x = 300.0
    for mode, value, hold in units:
        u, x, meta = gravtrig2_unit(x, mode, value, hold)
        objs += u
        UNITS.append(meta)
    return header() + ";" + ";".join(objs) + ";"


# --- Teleport orb (id 3027) ------------------------------------------------
# Read from the binary: PlayerObject::ringJump (0x398c00) sends a ring of
# GameObjectType 46 to GJBaseGameLayer::teleportPlayer (0x20fdb0) with the
# player that pressed it -- the 3022 path, but for that player and on a press --
# and skips every other ring effect. collisionCheckObjects hands type 46 to
# playerTouchedRing like any ring (0x215a42) and then reads the player's box
# again (0x215e78). Each unit puts one orb in the player's path at floor height,
# presses inside it (or holds through it), and sends the player to a Spawn
# trigger marker, as the 3022 rig does.
TELEPORT_ORB = 3027


def teleportorb_unit(x: float, i: int, mode: str = "cube", mini: bool = False,
                     flip: bool = False, ty: float = 200.0, dx: float = 0.0,
                     ignx: bool = False, igny: bool = False, grav: int = 0,
                     hold_through: bool = False, press_len: int = 3
                     ) -> tuple[list[str], float, dict]:
    """One teleport orb at floor height 14 blocks in, pressed 12 px past its
    centre's x minus the contact distance (3 ticks), or with `hold_through` held
    from 20 px before contact for 40 ticks; its target is `dx` further on at `ty`."""
    objs: list[str] = []
    for py in SP_PORTAL_YS:
        objs.append(obj(GRAV_NORM, x, py))
        objs.append(obj(MODE_PORTAL[mode], x + 2 * GRID, py))
        objs.append(obj(SIZE_MINI if mini else SIZE_NORM, x + 4 * GRID, py))
        if flip:
            objs.append(obj(GRAV_FLIP, x + 6 * GRID, py))
    objs += floor_run(x, x + TP_PITCH - GRID)
    x_o = x + 14 * GRID
    oy = TP_CEIL_BOTTOM - 15.0 if flip else GROUND_TOP + 15.0
    g = 300 + i
    props: dict[int, str] = {K_TARGET: str(g)}
    if ignx:
        props[K_IGNORE_X] = "1"
    if igny:
        props[K_IGNORE_Y] = "1"
    if grav:
        props[K_GRAV_MODE] = str(grav)
    objs.append(obj(TELEPORT_ORB, x_o, oy, extra=props))
    objs.append(obj(TP_MARK, x_o + dx, ty, extra={K_GROUPS: str(g)}))
    contact = 18.0 + (9.0 if mini else 15.0)
    if hold_through:
        tp = tick_at(x_o - contact - 20.0)
        PLAN.append((tp, 1))
        PLAN.append((tp + 40, 0))
    else:
        tp = tick_at(x_o - contact + 12.0)
        PLAN.append((tp, 1))
        PLAN.append((tp + press_len, 0))
    # Every unit has the ceiling and normal gravity back at its end: a press still held after the
    # teleport flips a ball or a spider (measured), and a body left upside down with nothing above
    # it misses every later unit's preamble.
    cx = x
    while cx < x + TP_PITCH:
        objs.append(obj(BLOCK, cx, TP_CEIL_BOTTOM + GRID / 2))
        cx += GRID
    for py in (105.0, 195.0, 285.0):
        objs.append(obj(GRAV_NORM, x + TP_PITCH - 2 * GRID, py))
    meta = {"x0": x, "x1": x + TP_PITCH, "mode": mode, "mini": int(mini), "flip": int(flip),
            "ceil_bottom": TP_CEIL_BOTTOM, "orb": [x_o, oy],
            "target": [x_o + dx, ty], "dx": dx, "ignx": int(ignx), "igny": int(igny), "grav": grav,
            "hold_through": int(hold_through), "press_len": 40 if hold_through else press_len,
            "t_press": tp, "t_pad": tick_at(x_o - contact)}
    return objs, x + TP_PITCH, meta


def build_teleportorb() -> str:
    """Teleport orb rig: up into the air from a cube, sideways with and without
    ignoreX, ignoreY, forced-flipped and toggled gravity, a press held through the
    orb, every other mode, and a mini cube."""
    # The units that move x on purpose come last: a teleport snaps x to the target's, so every
    # later unit meets its orb at another tick (press ticks come from a measured --xmap run).
    units = [
        dict(),                                   # cube, straight up to 200
        dict(igny=True),                          # y kept: only the x part, which is 0
        dict(grav=2, ty=150.0),                   # forced upside down
        dict(grav=3, ty=150.0),                   # toggle
        dict(hold_through=True),                  # held into the orb
        dict(mode="ship"), dict(mode="ball"), dict(mode="ufo"), dict(mode="wave"),
        dict(mode="robot"), dict(mode="spider"), dict(mode="swing"),
        dict(mini=True),
        dict(press_len=1),                        # released on the teleport tick
        dict(press_len=2),                        # released on the tick after it
        dict(dx=60.0, ignx=True),                 # sideways, x kept
        dict(dx=60.0),                            # sideways, x not kept
    ]
    objs: list[str] = []
    x = 300.0
    for i, kw in enumerate(units):
        u, x, meta = teleportorb_unit(x, i, **kw)
        objs += u
        UNITS.append(meta)
    return header() + ";" + ";".join(objs) + ";"


# --- Follow Player Y (id 1814) ---------------------------------------------
# Read from the binary: GJBaseGameLayer::processPlayerFollowActions (0x22ded0),
# called once a tick from processMoveActionsStep before the player moves, adds
# clamp(dt*60*speed, 0, 1) * (player 1's y + offset - the object's y) to every
# object of the target group, cut to +-dt*60*max when a max is set; with a delay
# the target is the player's y that long ago, from a 200-slot ring the update
# loop advances every 0.01 s. Each unit fires one 1814 at its start and puts a
# marker of the target group behind the trigger, where the player never touches
# it; grouptrace=1 records where the marker goes. The keys are the bindings'
# property numbers: 90 speed, 91 delay, 92 offset, 105 max speed.
FOLLOW_Y = 1814
K_FY_SPEED, K_FY_DELAY, K_FY_OFFSET, K_FY_MAX = 90, 91, 92, 105
FY_MARK = 201          # a 1x speed portal: grouptrace tracks it, and the player is at 1x
FY_PITCH = 30 * GRID
FY_PORTAL_YS = (105.0, 195.0, 285.0, 375.0)


def followy_unit(x: float, i: int, mode: str = "cube", speed: float = 1.0,
                 delay: float = 0.0, offset: int = 0, vmax: float = 0.0,
                 presses: tuple[tuple[int, int], ...] = ((4, 3), (12, 3)),
                 marks: tuple[float, ...] = (105.0,), portal: str | None = None,
                 portal_y: float = 300.0) -> tuple[list[str], float, dict]:
    """One 1814 fired on crossing, its group's markers behind it, and presses at
    (cells after the trigger, ticks held). With `portal`, a mode portal of that
    kind joins the group 16 cells ahead, starting at `portal_y`."""
    objs: list[str] = []
    for py in FY_PORTAL_YS:
        objs.append(obj(GRAV_NORM, x, py))
        objs.append(obj(MODE_PORTAL[mode], x + 2 * GRID, py))
        objs.append(obj(SIZE_NORM, x + 4 * GRID, py))
    objs += floor_run(x, x + FY_PITCH - GRID)
    x_t = x + 8 * GRID
    g = 200 + i
    # 2 s: over within the unit (480 ticks, 623 px at 1x), so each unit's trigger runs alone
    props: dict[int, str] = {K_TARGET: str(g), K_DURATION: "2", K_FY_SPEED: f"{speed:g}"}
    if delay:
        props[K_FY_DELAY] = f"{delay:g}"
    if offset:
        props[K_FY_OFFSET] = str(offset)
    if vmax:
        props[K_FY_MAX] = f"{vmax:g}"
    objs.append(obj(FOLLOW_Y, x_t, 200.0, extra=props))
    for k, my in enumerate(marks):
        objs.append(obj(FY_MARK, x_t - (2 + k) * GRID, my, extra={K_GROUPS: str(g)}))
    x_p = None
    if portal:
        x_p = x_t + 16 * GRID
        objs.append(obj(MODE_PORTAL[portal], x_p, portal_y, extra={K_GROUPS: str(g)}))
    t_trig = tick_at(x_t)
    for cells, hold in presses:
        tp = tick_at(x_t + cells * GRID)
        PLAN.append((tp, 1))
        PLAN.append((tp + hold, 0))
    meta = {"x0": x, "x1": x + FY_PITCH, "mode": mode, "group": g, "speed": speed,
            "delay": delay, "offset": offset, "vmax": vmax, "dur": 2, "trig_x": x_t,
            "marks": [[x_t - (2 + k) * GRID, my] for k, my in enumerate(marks)],
            "portal": portal, "portal_x": x_p, "portal_y": portal_y if portal else None,
            "presses": [list(p) for p in presses], "t_pad": t_trig}
    return objs, x + FY_PITCH, meta


def build_followy() -> str:
    """Follow Player Y rig: speed 1 (a quarter of the gap a tick at 240 ticks/s)
    under a jumping cube and a flying ship, speed 0.5 with an offset, a max speed,
    a delay, speed 10 (clamped to the whole gap), a cube portal that follows a
    flying ship, and two markers starting apart."""
    ship = ((2, 40), (10, 30), (16, 30))
    units = [
        dict(),
        dict(mode="ship", presses=ship),
        dict(speed=0.5, offset=30),
        dict(vmax=1.0),
        dict(delay=0.1),
        dict(speed=10.0),
        dict(mode="ship", presses=ship, portal="cube"),
        dict(marks=(300.0, 60.0)),
    ]
    objs: list[str] = []
    x = 300.0
    for i, kw in enumerate(units):
        u, x, meta = followy_unit(x, i, **kw)
        objs += u
        UNITS.append(meta)
    return header() + ";" + ";".join(objs) + ";"


# --- Gameplay rotation and the velocity-limit exemption (id 2900, property 585) -------------------
# rotateGameplay swaps the axes when the vertical/horizontal flag changes, sets vy to the travel speed
# (dx / 0.25 = 9.6 at 4x) and stores the exemption +0x952 as 1 (0x399faa) -- then as 0 again when the
# trigger has Dont Slide (585, 0x39a00d). Both are stores, so the byte the body arrived with does not
# survive either way. A ship at 4x, no input: #1 turns frame 0 -> 3 (vp := -9.6, outside the band, so
# only a latched body is left unclamped), #2 twenty ticks later turns back (vp := +9.6). One level per
# (585 on #1, 585 on #2); this is what dp's --rotboost reproduces (dptest has the same four cases).
# Measured in GD (|yvel|, the tick after each swap):
#   rotslide_00  #1 -> 9.514 (latched)  #2 -> 9.497 (latched)
#   rotslide_01  #1 -> 9.514 (latched)  #2 -> 8.000 (Dont Slide drops a latched body)
#   rotslide_10  #1 -> 6.400 (clamped)  #2 -> 9.497 (raised again)
#   rotslide_11  #1 -> 6.400 (clamped)  #2 -> 8.000
ROT_TRIG = 2900
K_MOVE_DIR, K_GROUND_DIR, K_DONT_SLIDE = 166, 167, 585
ROTSLIDE_X0 = 600.0


def build_rotslide(slide1_off: bool, slide2_off: bool) -> str:
    objs: list[str] = floor_run(0.0, ROTSLIDE_X0 - GRID)
    e1 = {K_MOVE_DIR: "4", K_GROUND_DIR: "1"}
    if slide1_off:
        e1[K_DONT_SLIDE] = "1"
    objs.append(obj(ROT_TRIG, ROTSLIDE_X0, 105.0, rot=-90.0, extra=e1))
    e2 = {K_MOVE_DIR: "2", K_GROUND_DIR: "4"}
    if slide2_off:
        e2[K_DONT_SLIDE] = "1"
    objs.append(obj(ROT_TRIG, ROTSLIDE_X0 + GRID, 153.0, extra=e2))
    # a wall of blocks 400 px on ends the run
    for i in range(60):
        objs.append(obj(1, ROTSLIDE_X0 + 400.0, GROUND_Y + GRID * i))
    UNITS.append({"x0": 0.0, "x1": ROTSLIDE_X0 + 400.0, "mode": "ship", "speed": "4x",
                  "dontslide_1": int(slide1_off), "dontslide_2": int(slide2_off),
                  "t_swap1": 251, "t_swap2": 272,
                  "gd_abs_yvel_after_1": 6.4 if slide1_off else 9.514,
                  "gd_abs_yvel_after_2": 8.0 if slide2_off else 9.497})
    return header(start_mode="ship", speed=4) + ";" + ";".join(objs) + ";"


BUILDERS = {"probe": build_probe, "slopes": build_slopes,
            "route1": build_route1, "route2": build_route2,
            "coincal": build_coincal,
            "coingate": build_coingate, "coingate2": build_coingate2,
            "coingate3": build_coingate3, "coingate4": build_coingate4,
            "coingate5": build_coingate5, "coingate6": build_coingate6,
            "coingate7": build_coingate7, "coingate8": build_coingate8,
            "crush": build_crush, "sawcal": build_sawcal,
            "sawcal_wave": lambda: build_sawcal_mode("wave"),
            "sawcal_ship": lambda: build_sawcal_mode("ship"),
            "sawcal_ball": lambda: build_sawcal_mode("ball"),
            "sawcal_cube": lambda: build_sawcal_mode("cube"),
            "sawcal_robot": lambda: build_sawcal_mode("robot"),
            "sawcal_ufo": lambda: build_sawcal_mode("ufo"),
            "sawcal_swing": lambda: build_sawcal_mode("swing"),
            "sawcal_spider": lambda: build_sawcal_mode("spider"),
            "sawcal_ball_mini": lambda: build_sawcal_mode("ball", True),
            "sawcal_wave_mini": lambda: build_sawcal_mode("wave", True),
            "sawcal_ship_mini": lambda: build_sawcal_mode("ship", True),
            "sawcal_cube_mini": lambda: build_sawcal_mode("cube", True),
            # The lethal boundary of a SPIKED ramp, which no
            # rig has ever put a player against (calib_slopeflags carries the
            # two ids but rides nothing). Both ids in every file: 366 is |m| = 1
            # and 367 is |m| = 0.5, which is what separates a vertical offset
            # from a perpendicular one.
            "portalpress": build_portalpress,
            "portalspider": build_portalspider,
            "spiderairhold": build_spiderairhold,
            "slopeup": build_slopeup,
            "slopeceil": build_slopeceil,
            "slopeflip": build_slopeflip,
            "slopeflip_1338": lambda: build_slopeflip(SLOPE1338),
            "slopeflip_nbrs": lambda: build_slopeflip(SLOPE1338, nbrs=True),
            "slopeflip_group": lambda: build_slopeflip(SLOPE1338, group=True),
            "slopespike_wave": lambda: build_slopespike_mode("wave"),
            "slopespike_ship": lambda: build_slopespike_mode("ship"),
            "slopespike_cube": lambda: build_slopespike_mode("cube"),
            "slopespike_wave_mini": lambda: build_slopespike_mode("wave", True),
            "slopespike_ship_mini": lambda: build_slopespike_mode("ship", True),
            "slopespike_ship_flip": lambda: build_slopespike_mode("ship", False, True),
            "slopespike_ship_mini_flip": lambda: build_slopespike_mode("ship", True, True),
            "slopespike_mirror_ship": lambda: build_slopespike_mirror("ship"),
            "slopespike_twin_ship": lambda: build_slopespike_twin("ship"),
            "hazrot_wave": lambda: build_hazrot("wave"),
            "hazrot_cube": lambda: build_hazrot("cube"),
            "slopespike_wave_flip": lambda: build_slopespike_mode("wave", False, True),
            "expease": build_expease,
            "cprot": build_cprot,
            "cpride": build_cpride,
            "cpriderot": build_cpriderot,
            "sawcalmv_wave": lambda: build_sawcal_moved("wave"),
            "sawcalmv_ship": lambda: build_sawcal_moved("ship"),
            "sawcalmv_ball": lambda: build_sawcal_moved("ball"),
            "sawcalmv_cube": lambda: build_sawcal_moved("cube"),
            "sawcalmv_robot": lambda: build_sawcal_moved("robot"),
            "sawcalmv_ufo": lambda: build_sawcal_moved("ufo"),
            "sawcalmv_swing": lambda: build_sawcal_moved("swing"),
            "sawcalmv_spider": lambda: build_sawcal_moved("spider"),
            "sawcalmv_ship_mini": lambda: build_sawcal_moved("ship", True),
            "sawcalmv_cube_mini": lambda: build_sawcal_moved("cube", True),
            # Generate each of these TWICE, with and without
            # --ka39; the pair is the experiment and one arm alone says
            # nothing (see the KA39_STATIONS note).
            "sawcal39_cube": lambda: _ka39_rig("cube", False, False),
            "sawcal39_spider": lambda: _ka39_rig("spider", False, False),
            "sawcal39_wave": lambda: _ka39_rig("wave", False, False),
            "sawcal39_ball": lambda: _ka39_rig("ball", False, False),
            "sawcal39_cube_mini": lambda: _ka39_rig("cube", True, False),
            "sawcal39_spider_mini": lambda: _ka39_rig("spider", True, False),
            "sawrot39_cube": lambda: _ka39_rig("cube", False, True),
            "sawrot39_spider": lambda: _ka39_rig("spider", False, True),
            # Generate each with and without the 1859s: the pair
            # is what separates the flip-grace arm from the arming arm.
            "flipwin_cube": lambda: build_flipwin("cube"),
            "flipwin_cube_armed": lambda: build_flipwin("cube", armed=True),
            "flipwin_cube_mini": lambda: build_flipwin("cube", mini=True),
            "flipwin_cube_mini_armed":
                lambda: build_flipwin("cube", mini=True, armed=True),
           "forcecal_cube": lambda: build_forcecal_mode("cube"),
           "forcedrop_cube": lambda: build_forcedrop_mode("cube"),
           "platformer": build_platformer,
           "speedcal_cube_s0": lambda: build_speedcal("cube", 0),
           "speedcal_cube_s1": lambda: build_speedcal("cube", 1),
           "speedcal_cube_s2": lambda: build_speedcal("cube", 2),
           "speedcal_cube_s3": lambda: build_speedcal("cube", 3),
           "speedcal_cube_s4": lambda: build_speedcal("cube", 4),
           "speedcal_ship_s4": lambda: build_speedcal("ship", 4),
           "speedcal_ship_s3": lambda: build_speedcal("ship", 3),
           "forcedrop_cube_mini_f10": lambda: build_forcedrop_mode("cube", True, 10),
           "forcedrop_swing_mini_f10": lambda: build_forcedrop_mode("swing", True, 10),
           "forcedrop_ball_mini_f10": lambda: build_forcedrop_mode("ball", True, 10),
           "forcedrop_ship_mini_f10": lambda: build_forcedrop_mode("ship", True, 10),
           "forcedrop_cube_f3": lambda: build_forcedrop_mode("cube", False, 3),
           "forcedrop_cube_f10": lambda: build_forcedrop_mode("cube", False, 10),
           "forcedrop_cube_f30": lambda: build_forcedrop_mode("cube", False, 30),
           "forcedrop_robot_f10": lambda: build_forcedrop_mode("robot", False, 10),
           "forcedrop_swing_f10": lambda: build_forcedrop_mode("swing", False, 10),
           "forcedrop_ship_f10": lambda: build_forcedrop_mode("ship", False, 10),
           "forcedrop_ball_f10": lambda: build_forcedrop_mode("ball", False, 10),
           "forcedrop_spider_f10": lambda: build_forcedrop_mode("spider", False, 10),
           "forcedrop_ufo_f10": lambda: build_forcedrop_mode("ufo", False, 10),
           "forcedrop_ship": lambda: build_forcedrop_mode("ship"),
           "forcedrop_ball": lambda: build_forcedrop_mode("ball"),
           "forcedrop_ufo": lambda: build_forcedrop_mode("ufo"),
           "forcedrop_wave": lambda: build_forcedrop_mode("wave"),
           "forcedrop_robot": lambda: build_forcedrop_mode("robot"),
           "forcedrop_spider": lambda: build_forcedrop_mode("spider"),
           "forcedrop_swing": lambda: build_forcedrop_mode("swing"),
           "forcecal_ship": lambda: build_forcecal_mode("ship"),
           "forcecal_ball": lambda: build_forcecal_mode("ball"),
           "forcecal_ufo": lambda: build_forcecal_mode("ufo"),
           "forcecal_wave": lambda: build_forcecal_mode("wave"),
           "forcecal_robot": lambda: build_forcecal_mode("robot"),
           "forcecal_spider": lambda: build_forcecal_mode("spider"),
           "forcecal_swing": lambda: build_forcecal_mode("swing"),
            "dualmode": build_dualmode,
            "ceilrel": build_ceilrel, "ceilrel11": build_ceilrel11,
            "ceilrel07": build_ceilrel07, "seam": build_seam,
            "seam07": build_seam07, "seam11": build_seam11,
            "ridestep": build_ridestep, "ceilhold": build_ceilhold,
            "slopeflags": build_slopeflags,
            "slopeveto": build_slopeveto,
            "slopeveto2": build_slopeveto2,
            "dropair": build_dropair, "dualport": build_dualport,
            "flyramps": build_flyramps,
            "slopevy": build_slopevy,
            "bandceil": build_bandceil,
            "portwavebig": build_portwavebig,
            "recttop": build_recttop,
            "ramps": build_ramps, "rampseam": build_rampseam,
    "rampseamdual": build_rampseamdual,
    "ceilrampdual": build_ceilrampdual, "wavein": build_wavein,
    "ridemode": build_ridemode, "ridemodedual": build_ridemodedual,
    "ridedrop": build_ridedrop,
    "rampjump": build_rampjump, "ufojump": build_ufojump,
    "ufojump_sp": lambda: build_ufojump(speed=2),
    "robotjump_sp": build_robotjump_sp,
    "ufoexit": build_ufoexit,
            "ceilramp": build_ceilramp, "portrot": build_portrot,
            "portwave": build_portwave,
            "holdjump_cube": lambda: build_holdjump("cube"),
            "holdjump_robot": lambda: build_holdjump("robot"),
            "holdjump_ball": lambda: build_holdjump("ball"),
            "holdjump_spider": lambda: build_holdjump("spider"),
            "empty": build_empty, "flat": build_flat,
            "minhdr": build_minhdr, "flat90": build_flat90,
            "flatfar": build_flatfar, "orbs": build_orbs,
            "orbair": build_orbair, "orbedge": build_orbedge,
            "orbedge2": build_orbedge2, "orbedge3": build_orbedge3,
            "slopeland": build_slopeland, "slopeland3": build_slopeland3,
            "slopeland4": build_slopeland4,
            "slopeland4ball": build_slopeland4ball,
            "slopeland4fast": build_slopeland4fast,
            "shortexit": build_shortexit, "edgeland": build_edgeland,
            "slopelandball": build_slopelandball,
            "ceilpush": build_ceilpush, "ceilpushball": build_ceilpushball,
            "ceilpush8": build_ceilpush8, "padedge": build_padedge, "padedge13": build_padedge13, "padfall": build_padfall, "padnorm": build_padnorm,
            "spiderpad": build_spiderpad, "gravtoggle": build_gravtoggle,
            "teleporttrig": build_teleporttrig, "tpback": build_tpback,
            "gravtrig": build_gravtrig, "gravtrig2": build_gravtrig2,
            "followy": build_followy, "teleportorb": build_teleportorb,
            "tpportal": build_tpportal,
            "rotslide_00": lambda: build_rotslide(False, False),
            "rotslide_01": lambda: build_rotslide(False, True),
            "rotslide_10": lambda: build_rotslide(True, False),
            "rotslide_11": lambda: build_rotslide(True, True)}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("what", choices=sorted(BUILDERS))
    ap.add_argument("--out", required=True)
    ap.add_argument("--xmap", default=None,
                    help="a measured dump.csv. Press ticks are taken from its "
                         "x(t) -- pass a dump of one run of this same rig")
    ap.add_argument("--arc", default=None,
                    help="the dump.csv of slopeland pass1. The pad arc is "
                         "measured from it to place the slopes; without it the "
                         "rig has pads only")
    ap.add_argument("--coin", default=None,
                    help="coincal only: mode,mini,scale,dy1[,dy2,dy3] -- e.g. "
                         "cube,0,0,34.5,35,35.5. At most three dy values (a GD "
                         "level holds three user coins and drops the rest)")
    ap.add_argument("--coin-rot", type=float, default=0.0,
                    help="coincal only: turn the coin. A turn that is not a "
                         "multiple of 90 makes objrects' w,h the BOUNDING BOX "
                         "of the turned square, which is what this measures")
    ap.add_argument("--coin-n", type=int, default=None,
                    help="coingate6 only: how many item-1 pickups to place "
                         "before the compare (the compare's constant is 3)")
    ap.add_argument("--coin-sxy", default=None,
                    help="coincal only: sx,sy -- per-axis scale (level-string "
                         "keys 128/129), for a coin that is not square")
    ap.add_argument("--ka39", action="store_true",
                    help="write kA39,1 (fixRadiusCollision) into the header -- "
                         "the lv22 flag world. Record it with the rig's "
                         "measurements: sawcal history is all kA39=0")
    a = ap.parse_args()
    if a.ka39:
        global KA39
        KA39 = True
    if a.coin_n is not None:
        COINGATE["n"] = a.coin_n
    COINCAL["rot"] = a.coin_rot
    if a.coin_sxy:
        sx, sy = a.coin_sxy.split(",")
        COINCAL["sx"], COINCAL["sy"] = float(sx), float(sy)
    if a.coin:
        f = a.coin.split(",")
        if len(f) < 4:
            ap.error("--coin needs mode,mini,scale and at least one dy")
        COINCAL["mode"] = f[0]
        COINCAL["mini"] = f[1] not in ("0", "", "false", "False")
        COINCAL["scale"] = float(f[2])
        COINCAL["dys"] = [float(v) for v in f[3:]]
        if len(COINCAL["dys"]) > 3:
            ap.error("at most three dy values -- GD drops the fourth coin")
    if a.xmap:
        load_xmap(Path(a.xmap))
        print(f"xmap: {len(XMAP)} ticks (ends at x={XMAP[-1][1]:.0f})")
    if a.arc:
        load_arc(Path(a.arc))
    s = BUILDERS[a.what]()
    p = Path(a.out)
    p.parent.mkdir(parents=True, exist_ok=True)
    # Write it raw (compression is left to GD's ZipUtils on the MOD side).
    p.write_text(s, encoding="utf-8", newline="")
    n = s.count(";") - 1
    print(f"{a.what}: {n} objects, {len(s)} chars -> {p}")
    if UNITS:
        up = p.with_suffix(".units.json")
        up.write_text(json.dumps(UNITS, indent=1), encoding="utf-8")
        print(f"  unit table, {len(UNITS)} entries -> {up}")
    if PLAN:
        pp = p.with_suffix(".plan.txt")
        pp.write_text("".join(f"input={t},{d}\n" for t, d in sorted(PLAN)),
                      encoding="utf-8", newline="")
        print(f"  {len(PLAN)} presses -> {pp}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())





