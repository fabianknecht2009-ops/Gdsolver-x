#pragma once
// Crash post-mortem: terminate / invalid-parameter / SEH handlers that write one last line.
#include "mod/hookdepth.hpp"

namespace p1 {

// ============================================================
// Post-mortem of hard deaths (postmortem). Geode's crash handler only covers the SEH path, and
// uncaught C++ exceptions (bad_alloc etc.) or CRT invalid parameter leave not a single line, so
// we insert a one-line write to result.txt into the dying path itself.
// std::ofstream / std::string are not used for the write — this can run in the middle of a
// bad_alloc, so no allocating tool can be used (fopen + fprintf only).
// ============================================================
namespace postmortem {

// Private bytes of the process (MB). The OOM hypothesis can only be judged by "the value at the
// moment of the crash". Resolve kernel32's K32GetProcessMemoryInfo dynamically to avoid
// linking psapi
inline int privateMB() {
#ifdef GEODE_IS_WINDOWS
    struct PMC {
        DWORD cb; DWORD PageFaultCount;
        SIZE_T PeakWorkingSetSize, WorkingSetSize;
        SIZE_T QuotaPeakPagedPoolUsage, QuotaPagedPoolUsage;
        SIZE_T QuotaPeakNonPagedPoolUsage, QuotaNonPagedPoolUsage;
        SIZE_T PagefileUsage, PeakPagefileUsage;
    };
    using Fn = BOOL(WINAPI*)(HANDLE, PMC*, DWORD);
    static Fn fn = (Fn)GetProcAddress(GetModuleHandleA("kernel32.dll"),
                                      "K32GetProcessMemoryInfo");
    if (!fn) return -1;
    PMC pmc{};
    pmc.cb = sizeof(pmc);
    if (!fn(GetCurrentProcess(), &pmc, sizeof(pmc))) return -1;
    return (int)(pmc.PagefileUsage / (1024 * 1024));
#else
    return -1;
#endif
}
// ...and the working set (MB), the same call's other field, for the memory census (cfg memcensus).
inline int workingSetMB() {
#ifdef GEODE_IS_WINDOWS
    struct PMC {
        DWORD cb; DWORD PageFaultCount;
        SIZE_T PeakWorkingSetSize, WorkingSetSize;
        SIZE_T QuotaPeakPagedPoolUsage, QuotaPagedPoolUsage;
        SIZE_T QuotaPeakNonPagedPoolUsage, QuotaNonPagedPoolUsage;
        SIZE_T PagefileUsage, PeakPagefileUsage;
    };
    using Fn = BOOL(WINAPI*)(HANDLE, PMC*, DWORD);
    static Fn fn = (Fn)GetProcAddress(GetModuleHandleA("kernel32.dll"),
                                      "K32GetProcessMemoryInfo");
    if (!fn) return -1;
    PMC pmc{};
    pmc.cb = sizeof(pmc);
    if (!fn(GetCurrentProcess(), &pmc, sizeof(pmc))) return -1;
    return (int)(pmc.WorkingSetSize / (1024 * 1024));
#else
    return -1;
#endif
}

// Emit one line to both result.txt and crash_postmortem.txt.
// result.txt is truncated at the next session start, so keep an append-only copy
inline void emit(const char* line) {
    static const char* names[2] = { "/result.txt", "/crash_postmortem.txt" };
    for (int k = 0; k < 2; ++k) {
        char path[512];
        snprintf(path, sizeof(path), "%s%s", DATA_DIR, names[k]);
        if (FILE* f = fopen(path, "a")) {
            fputs(line, f);
            fputc('\n', f);
            fflush(f);
            fclose(f);
        }
    }
}

// Early detection of heap corruption (cfg `heapcheck=<attempts>`, 0=disabled). Heap corruption
// surfaces the next time the allocator touches it (0xC0000374, instant kill, no handler runs),
// so validate every heap every N attempts and bracket the broken interval by attempt number.
// Slow, so disabled by default.
// HeapValidate can effectively do nothing on the segment heap, so also return the number of
// walked blocks so the caller can judge whether the check had any teeth
inline bool heapOk(int* heapsOut = nullptr, long long* blocksOut = nullptr) {
#ifdef GEODE_IS_WINDOWS
    HANDLE heaps[64];
    DWORD n = GetProcessHeaps(64, heaps);
    if (n > 64) n = 64;
    if (heapsOut) *heapsOut = (int)n;
    long long blocks = 0;
    bool ok = true;
    for (DWORD i = 0; i < n; ++i) {
        if (!HeapValidate(heaps[i], 0, nullptr)) { ok = false; break; }
        // HeapWalk actually traverses the blocks = evidence that the check was not a no-op
        PROCESS_HEAP_ENTRY e{};
        e.lpData = nullptr;
        while (HeapWalk(heaps[i], &e)) {
            if (++blocks > 2000000) break;   // cap (so a pathologically large heap cannot hang us)
        }
    }
    if (blocksOut) *blocksOut = blocks;
    return ok;
#else
    (void)heapsOut; (void)blocksOut;
    return true;
#endif
}

// Where the section search was when something ended the process (set by hooks_gamelayer's search:
// the step of an expansion it was in, the layer and the node). 0 = not in a search.
inline volatile int g_secPhaseDepth = -1, g_secPhaseNode = -1;
// The step is a class so that, in a test-instrument build with cfg `heapphase_testonly=<n>`, every change of step validates the heaps first (see
// heapPhaseCheck below): a heap corruption surfaces at a later free, and the step where the check first fails brackets the write that did it.
struct SecPhase {
    volatile int v = 0;
    operator int() const { return v; }
    inline SecPhase& operator=(int n);
};
inline SecPhase g_secPhase;
// ...and what each step is (the numbers the search writes into g_secPhase).
inline const char* secPhaseName(int p) {
    switch (p) {
    case 1: return "layer-start";
    case 2: return "expand";
    case 10: return "restore-world";
    case 11: return "restore-player";
    case 12: return "restore-effects";
    case 13: return "restore-state";
    case 14: return "restore-touch";
    case 15: return "restore-activation";
    case 16: return "restore-trail";
    case 20: return "step-begin";
    case 21: return "step";
    case 22: return "after-step";
    case 30: return "activation-sig";
    case 31: return "dedupe-key";
    case 40: return "capture-player";
    case 41: return "capture-effects";
    case 42: return "capture-state";
    case 43: return "capture-touch";
    case 44: return "capture-world";
    case 45: return "capture-checkpoint";
    case 50: return "cap-prune";
    case 55: return "layer-end";
    case 60: return "verify";
    case 70: return "census";
    case 80: return "release-snaps";
    case 81: return "release-effects";
    case 82: return "release-state";
    case 83: return "release-touch";
    case 84: return "release-world";
    case 85: return "release-activation";
    case 86: return "release-done";
    default: return "?";
    }
}

// cfg `heapphase_testonly=<n>` (n >= 1; test-instrument builds): validate every heap before the section search changes step, at most once every n-1 ms
// (1 = every change). The first failure is written once, with the step it was found going into and the one before. Slow on a large heap: the search
// runs several times slower, which a search with a clock in it can notice.
inline void heapPhaseCheck(int from, int to) {
#ifdef GEODE_IS_WINDOWS
    static bool failed = false;
    static ULONGLONG last = 0;
    static long long clean = 0;
    if (failed) return;
    const ULONGLONG now = GetTickCount64();
    if (now - last < (ULONGLONG)(g_heapPhaseTestOnly - 1)) return;
    HANDLE heaps[64];
    DWORD n = GetProcessHeaps(64, heaps);
    if (n > 64) n = 64;
    for (DWORD i = 0; i < n; ++i) {
        if (!HeapValidate(heaps[i], 0, nullptr)) {
            failed = true;
            char line[420];
            snprintf(line, sizeof(line),
                     "HEAPCHECK: heap %u of %u is corrupt on the way from step %d (%s) to step %d (%s), layer %d node %d, after %lld clean checks",
                     (unsigned)i, (unsigned)n, from, secPhaseName(from), to, secPhaseName(to), (int)g_secPhaseDepth, (int)g_secPhaseNode, clean);
            emit(line);
            return;
        }
    }
    ++clean;
    last = GetTickCount64();
#else
    (void)from; (void)to;
#endif
}
// cfg `phasefile_testonly=1` (test-instrument builds): the step the search is in, written over the same line of <data>/secphase.txt at every change, so a
// process the heap kills (0xC0000374 runs no handler) still says where it was.
inline void phaseFileWrite(int from, int to) {
    static FILE* f = nullptr;
    if (!f) {
        char path[512];
        snprintf(path, sizeof(path), "%s/secphase.txt", DATA_DIR);
        f = fopen(path, "wb");
        if (!f) return;
        setvbuf(f, nullptr, _IONBF, 0);
    }
    char line[96];
    const int n = snprintf(line, sizeof(line), "layer %d node %d step %d (%s) <- %d (%s)                    ", (int)g_secPhaseDepth, (int)g_secPhaseNode, to,
                           secPhaseName(to), from, secPhaseName(from));
    fseek(f, 0, SEEK_SET);
    fwrite(line, 1, (size_t)(n < 90 ? 90 : n), f);
}
inline SecPhase& SecPhase::operator=(int n) {
    if (g_heapPhaseTestOnly > 0) heapPhaseCheck(v, n);
    if (g_phaseFileTestOnly) phaseFileWrite(v, n);
    v = n;
    return *this;
}

inline void writeRaw(const char* what) {
    char depths[256];
    hookdepth::format(depths, sizeof(depths));
    char line[1024];
    snprintf(line, sizeof(line), "FATAL: %s (privateMB=%d)%s secphase=%d d=%d node=%d", what, privateMB(),
             depths, (int)g_secPhase, (int)g_secPhaseDepth, (int)g_secPhaseNode);
    emit(line);
}

inline std::terminate_handler g_prevTerminate = nullptr;

inline void onTerminate() {
    // Uncaught C++ exceptions pass through here. This is the only point where the type and
    // what() can be recorded
    char buf[512];
    const char* kind = "terminate() with no active exception";
    try {
        if (auto e = std::current_exception()) std::rethrow_exception(e);
    } catch (const std::exception& e) {
        snprintf(buf, sizeof(buf), "uncaught std::exception: %s", e.what());
        kind = buf;
    } catch (...) {
        kind = "uncaught non-std exception";
    }
    writeRaw(kind);
    if (g_prevTerminate) g_prevTerminate();   // also run Geode's handler
    std::abort();
}

#ifdef GEODE_IS_WINDOWS
inline void onInvalidParameter(const wchar_t*, const wchar_t*, const wchar_t*,
                               unsigned int, uintptr_t) {
    writeRaw("CRT invalid parameter");
}

inline LPTOP_LEVEL_EXCEPTION_FILTER g_prevFilter = nullptr;

// Record the crash site as module+offset. On a stack overflow (0xC00000FD) Geode's crash log
// produces not a single line (there is no stack left to run the handler on).
// No allocating tool can be used, so CaptureStackBackTrace + fixed buffers only
inline void writeBacktrace(const char* tag = "FATAL:") {
    void* frames[32];
    USHORT n = CaptureStackBackTrace(0, 32, frames, nullptr);
    for (USHORT i = 0; i < n; ++i) {
        HMODULE mod = nullptr;
        char name[MAX_PATH] = "?";
        char line[512];
        if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS
                | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                (LPCSTR)frames[i], &mod) && mod) {
            GetModuleFileNameA(mod, name, sizeof(name));
            const char* slash = strrchr(name, '\\');
            if (slash) memmove(name, slash + 1, strlen(slash + 1) + 1);
            snprintf(line, sizeof(line), "%s   #%02u %s+0x%llX", tag, i, name,
                (unsigned long long)((char*)frames[i] - (char*)mod));
        } else {
            snprintf(line, sizeof(line), "%s   #%02u %p (no module)", tag, i, frames[i]);
        }
        emit(line);
    }
}

// Tally the return addresses on the stack to name "what recursed".
// CaptureStackBackTrace only sees the handler's own stack, so on a stack overflow scan upward
// from the crashed thread's Rsp and count by module+offset. No allocation at all (fixed table
// of 32 entries)
inline void writeStackScan(EXCEPTION_POINTERS* ep) {
#ifdef _M_X64
    if (!ep || !ep->ContextRecord) return;
    struct Entry { HMODULE mod; unsigned long long off; unsigned count; };
    Entry tbl[32] = {};
    int used = 0;
    ULONG_PTR rsp = (ULONG_PTR)ep->ContextRecord->Rsp;
    MEMORY_BASIC_INFORMATION mbi{};
    if (!VirtualQuery((LPCVOID)rsp, &mbi, sizeof(mbi))) return;
    ULONG_PTR end = (ULONG_PTR)mbi.BaseAddress + mbi.RegionSize;
    if (end > rsp + 0x40000) end = rsp + 0x40000;   // 256KB is enough (bounds the time)
    for (ULONG_PTR p = rsp; p + 8 <= end; p += 8) {
        ULONG_PTR v = *(ULONG_PTR*)p;
        if (v < 0x10000) continue;
        HMODULE mod = nullptr;
        if (!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS
                | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCSTR)v, &mod) || !mod)
            continue;
        unsigned long long off = (unsigned long long)(v - (ULONG_PTR)mod);
        int i = 0;
        for (; i < used; ++i)
            if (tbl[i].mod == mod && tbl[i].off == off) { ++tbl[i].count; break; }
        if (i == used && used < 32) { tbl[used++] = { mod, off, 1 }; }
    }
    for (int rank = 0; rank < 8; ++rank) {
        int best = -1;
        for (int i = 0; i < used; ++i)
            if (tbl[i].count > 0 && (best < 0 || tbl[i].count > tbl[best].count)) best = i;
        if (best < 0 || tbl[best].count < 2) break;
        char name[MAX_PATH] = "?";
        GetModuleFileNameA(tbl[best].mod, name, sizeof(name));
        const char* slash = strrchr(name, '\\');
        if (slash) memmove(name, slash + 1, strlen(slash + 1) + 1);
        char line[512];
        snprintf(line, sizeof(line), "FATAL:   stack x%-6u %s+0x%llX",
            tbl[best].count, name, tbl[best].off);
        emit(line);
        tbl[best].count = 0;
    }
#else
    (void)ep;
#endif
}

// A C++ exception thrown inside a section search (g_secPhase set), seen at the throw -- the search
// catches it and gives the search up, by which time the frames that threw are gone. The first few of
// a session print where it was thrown (`secthrow:` lines, module+offset).
inline volatile LONG g_secThrows = 0;
inline LONG WINAPI onFirstChance(EXCEPTION_POINTERS* ep) {
    if (ep && ep->ExceptionRecord && ep->ExceptionRecord->ExceptionCode == 0xE06D7363 && g_secPhase != 0
        && InterlockedIncrement(&g_secThrows) <= 3) {
        char line[160];
        snprintf(line, sizeof(line), "secthrow: a C++ exception thrown in a section search at depth %d, step %d, node %d",
                 (int)g_secPhaseDepth, (int)g_secPhase, (int)g_secPhaseNode);
        emit(line);
        writeBacktrace("secthrow:");
    }
    return EXCEPTION_CONTINUE_SEARCH;
}

inline LONG WINAPI onUnhandled(EXCEPTION_POINTERS* ep) {
    char buf[256];
    snprintf(buf, sizeof(buf), "unhandled SEH 0x%08lX at %p",
        (unsigned long)ep->ExceptionRecord->ExceptionCode,
        ep->ExceptionRecord->ExceptionAddress);
    writeRaw(buf);
    writeBacktrace();
    writeStackScan(ep);
    // Do not clobber the previous occupant (Geode's crash log)
    return g_prevFilter ? g_prevFilter(ep) : EXCEPTION_CONTINUE_SEARCH;
}
#endif

inline void onNewFailed() {
    writeRaw("operator new failed (out of memory)");
    throw std::bad_alloc();
}

inline void install() {
    g_prevTerminate = std::set_terminate(&onTerminate);
    std::set_new_handler(&onNewFailed);
#ifdef GEODE_IS_WINDOWS
    _set_invalid_parameter_handler(&onInvalidParameter);
    g_prevFilter = SetUnhandledExceptionFilter(&onUnhandled);
    AddVectoredExceptionHandler(1, &onFirstChance);
#endif
}

} // namespace postmortem

}  // namespace p1
